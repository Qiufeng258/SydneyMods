/* SydneyPack (悉尼入住包) v0.1.0 — 骨架：入住状态 + 早餐事件机制 + 房间守卫接入
 * 依赖：SydneyFamily >= 1.1.0（SF.registerSceneZone / SF.registerRoomGuard / SH House 场景）
 * 状态命名空间：$SF.sydneypack（与前置 $SF 并存）
 * 台词：全部为占位（用户定稿后替换，不锚可见文本）
 */
(function () {
  "use strict";
  var root = (typeof window !== "undefined") ? window
    : (typeof globalThis !== "undefined") ? globalThis : {};
  var SF = root.SF;
  var SP = root.SydneyPack || (root.SydneyPack = {});
  var NEED = { registerRoomGuard: !!(SF && SF.registerRoomGuard), sceneZone: !!(SF && SF.registerSceneZone) };
  SP.version = "0.1.44";
  /* 暴露到 window，便于游戏内诊断（window.SP / window.__SP_VER__） */
  try { if (typeof window !== "undefined") { window.SP = SP; window.__SP_VER__ = SP.version; } } catch (e) { /* ignore */ }
  SP.compat = NEED;

  /* 测试入口（正式交付前保留；供无控制台环境验证机制） */
  SP.testResident = function (v, on) {
    var p = SP.ensure(v);
    p.resident = !!on;
    if (on) {
      if (v.templePromised !== "Sydney") v.templePromised = "Sydney"; /* 测试直置承诺 */
      p.bfRefuseDay = null; p.bfDoneDay = null;
    } else {
      p.bfRefuseDay = null; p.bfDoneDay = null;
    }
  };
  SP.testJumpTo6 = function () {
    try {
      if (typeof Time === "undefined") return false;
      var cur = Number(Time.hour) * 3600 + Number(Time.minute) * 60;
      var target = 6 * 3600;
      var delta = (target - cur + 86400) % 86400;
      if (delta > 0) Time.pass(delta);
      return true;
    } catch (e) { return false; }
  };
  SP.currentStateLabel = function (v) {
    var p = SP.ensure(v);
    return p.resident ? "<span class=\"lblue\">已入住</span>（测试）" : "<span class=\"gold\">未入住</span>（测试）";
  };

  /* ---------- 状态 ---------- */
  SP.ensure = function (v) {
    if (!v) return null;
    if (!v.SF) v.SF = {};
    var p = v.SF.sydneypack;
    if (!p) {
      p = v.SF.sydneypack = { resident: false, bfRefuseDay: null, bfDoneDay: null, bfDishKey: null, bfAfterSex: false, sofaSleepDay: null, sofaLockDay: null, bathLockDay: null, herSleepDay: null, movePhase: null, inviteDay: null, moveRet: null, sexLead: "player", homeState: null, morningRollDay: null, morningSickDay: null, testMode: false, postpartumSkip7: false, approachLock: false, eveningBathDay: null, homeCarryDay: null, homeCarryUntil: null, sydInMyBedDay: null, sydInMyBedUntilDay: null };
    } else {
      if (p.resident === undefined) p.resident = false;
      if (p.bfRefuseDay === undefined) p.bfRefuseDay = null;
      if (p.bfDoneDay === undefined) p.bfDoneDay = null;
      if (p.bfDishKey === undefined) p.bfDishKey = null;
      if (p.testMode === undefined) p.testMode = false;
      if (p.postpartumSkip7 === undefined) p.postpartumSkip7 = false;
      if (p.bfAfterSex === undefined) p.bfAfterSex = false;
      if (p.sofaSleepDay === undefined) p.sofaSleepDay = null;
      if (p.sofaLockDay === undefined) p.sofaLockDay = null;
      if (p.bathLockDay === undefined) p.bathLockDay = null;
      if (p.herSleepDay === undefined) p.herSleepDay = null;
      if (p.movePhase === undefined) p.movePhase = null;
      if (p.inviteDay === undefined) p.inviteDay = null;
      if (p.moveRet === undefined) p.moveRet = null;
      if (p.sexLead === undefined) p.sexLead = "player";
      if (p.homeState === undefined) p.homeState = null;
      if (p.morningRollDay === undefined) p.morningRollDay = null;
      if (p.morningSickDay === undefined) p.morningSickDay = null;
      if (p.approachLock === undefined) p.approachLock = false;
      if (p.eveningBathDay === undefined) p.eveningBathDay = null;
      if (p.homeCarryDay === undefined) p.homeCarryDay = null;
      if (p.homeCarryUntil === undefined) p.homeCarryUntil = null;
      if (p.sydInMyBedDay === undefined) p.sydInMyBedDay = null;
      if (p.sydInMyBedUntilDay === undefined) p.sydInMyBedUntilDay = null;
    }
    return p;
  };
  /* ---------- 晚间家庭时段：homeState 懒随机 ---------- */
  SP.homeZones = { living: "客厅", kitchen: "厨房", study: "书房", garden: "小院", herRoom: "她的房间", bathroom: "浴室", pcBed: "你的床上" };
  SP.homeActions = {
    living: {
      evening: ["正靠在沙发上看书"],
      evening2: ["正靠在沙发上看书"]
    },
    kitchen: {
      evening: ["正在泡茶", "正在收拾灶台", "正在准备明天做饭的食材"]
    },
    study: {
      evening: ["正温习功课、写着笔记", "正抄着经文", "困得趴在桌上睡着了"],
      evening2: ["正温习功课、写着笔记", "正抄着经文"]
    },
    garden: {
      evening: ["正坐着乘凉", "正在菜地边看看"]
    },
    herRoom: {
      quiet: ["正举着十字架睡前祷告", "正梳理着头发", "换了睡衣，躺在床上读圣典"]
    }
  };
  SP.homeWeights = { living: 30, kitchen: 20, study: 20, garden: 10 };
  /* 时间块（用户重划 2026-09）：evening 20-21 / evening2 21-22 / bath 22-22:30 / quiet 22:30-23 / sleep 23-6 */
  SP.homeBlock = function (t) {
    if (!t) return "none";
    var mins = Number(t.hour) * 60 + (Number(t.minute) || 0);
    if (mins >= 23 * 60 || mins < 6 * 60) return "sleep";
    if (mins >= 22 * 60 + 30) return "quiet";
    if (mins >= 22 * 60) return "bath";
    if (mins >= 21 * 60) return "evening2";
    if (mins >= 20 * 60) return "evening";
    return "none";
  };
  SP.pickW = function (pairs) {
    var total = 0;
    for (var i = 0; i < pairs.length; i++) total += pairs[i][1];
    var r = Math.random() * total;
    for (var j = 0; j < pairs.length; j++) { r -= pairs[j][1]; if (r <= 0) return pairs[j][0]; }
    return pairs[pairs.length - 1][0];
  };
  /* 下一个换房边界（分钟）：退出靠近菜单后 carry 到此时才让 homeState 重算，避免"补跳" */
  SP.nextHomeBoundary = function (v, t) {
    try {
      var p = SP.ensure(v);
      if (!p || !p.resident || !t) return null;
      var mins = Number(t.hour) * 60 + (Number(t.minute) || 0);
      var sat = Number(t.weekDay) === 7 && mins >= 7 * 60 && mins < 20 * 60;
      var preg = (SP.pregStatus(v).pregnant || SP.maternityActive(v)) && mins >= 7 * 60 && mins < 20 * 60;
      if (sat || preg) {
        var nb = (Math.floor(mins / 30) + 1) * 30;
        return (nb < 20 * 60) ? nb : null;
      }
      if (mins >= 20 * 60 && mins < 23 * 60) {
        var cands = [21 * 60, 22 * 60, 22 * 60 + 30, 23 * 60];
        for (var i = 0; i < cands.length; i++) if (cands[i] > mins) return cands[i];
      }
      return null;
    } catch (e) { return null; }
  };
  SP.homeStateFor = function (v, t) {
    var p = SP.ensure(v);
    if (!p || !p.resident || !t) return null;
    if (SP.isGone(v)) return null;
    /* 临盆（story=labour + 引擎 labour）：她全程在卧室待产，覆盖所有时段占位 */
    var stL = SP.ensurePregStory(v);
    if (stL && stL.stage === "labour" && SP.pregStatus(v).labour) {
      p.homeState = { zone: "bedroom", action: "labour", actionZh: "在卧室待产", blockKey: "labour-" + Number(t.days) };
      return p.homeState;
    }
    /* 特殊态：夜袭后她睡在你床上（持续到早上 6:00，之后她自然去厨房/走正常日程） */
    if (SP.sydInMyBedActive(v, t)) {
      p.homeState = { zone: "pcBed", action: "sleepingInMyBed", actionZh: "在你床上睡着了", blockKey: "mybed-" + Number(t.days) };
      return p.homeState;
    }
    /* 靠近悉尼陪伴期冻结（A 方案）：聊/调情期间她不换房；22 点洗澡事件由渲染监听接管 */
    if (p.approachLock && p.homeState && p.homeState.blockKey) return p.homeState;
    /* 退出后的 carry：刚越过的换房边界作废，她留在原房直到"下一个边界"才重算（不补跳） */
    if (p.homeCarryDay !== Number(t.days)) { p.homeCarryDay = null; p.homeCarryUntil = null; }
    if (p.homeCarryDay !== null && p.homeState && p.homeState.blockKey) {
      var cm = Number(t.hour) * 60 + (Number(t.minute) || 0);
      if (cm < Number(p.homeCarryUntil)) return p.homeState;
      p.homeCarryDay = null;   /* 到期：清掉 carry，下面按当前块正常重算 */
      p.homeCarryUntil = null;
    }
    var day = Number(t.days);
    var mins = Number(t.hour) * 60 + (Number(t.minute) || 0);
    /* 做爱后她去浴室洗澡（bathLockDay）：23 点前她在浴室（旧提示流程） */
    if (p.bathLockDay === day && Number(t.hour) < 23) {
      p.homeState = { zone: "bathroom", action: "shower", actionZh: "在浴室洗澡", blockKey: "bath-" + day };
      return p.homeState;
    }
    if (p.bathLockDay === day && Number(t.hour) >= 23) p.bathLockDay = null;
    /* 沙发上睡着了（看书"直接起身/再坐会"路线）：今晚整夜在客厅 */
    if (p.sofaSleepDay === day) {
      p.homeState = { zone: "living", action: "sleeping", actionZh: "在沙发上睡着了", blockKey: "sofa-" + day };
      return p.homeState;
    }
    /* 提前回房（她说"我去睡了"）：<23 她房间做睡前动作（灯亮），23 点后走 sleep（灯灭） */
    if (p.herSleepDay === day && mins < 23 * 60) {
      var hsKey = "herSleep-" + day;
      if (!(p.homeState && p.homeState.blockKey === hsKey)) {
        var hq = SP.homeActions.herRoom.quiet || [];
        var ha = hq[Math.floor(Math.random() * hq.length)] || "回房间准备休息";
        p.homeState = { zone: "herRoom", action: ha, actionZh: ha, blockKey: hsKey };
      }
      return p.homeState;
    }
    var block = SP.homeBlock(t);
    /* 早餐窗口 6:00-6:59：resident 时她在厨房做早饭（门厅黄字=厨房有人） */
    /* 周六（weekDay 7）resident：白天 7:00-20:00 全天在家。
       7:00-7:30 固定厨房收拾；7:30 起每半小时一块随机房间（客厅/厨房/书房3档/小院2-3档），占位动作=在X */
    if (p.resident && Number(t.weekDay) === 7 && mins >= 7 * 60 && mins < 20 * 60) {
      if (mins < 7 * 60 + 30) {
        p.homeState = { zone: "kitchen", action: "cleanup", actionZh: "在厨房一边哼着歌，一边收拾厨具", blockKey: "sat7-" + day };
        return p.homeState;
      }
      var slot = Math.floor((mins - 7 * 60 - 30) / 30);
      var satKey = "sat" + day + "-" + slot;
      if (!(p.homeState && p.homeState.blockKey === satKey)) {
        var tier = Number(v.SF.homeTier) || 1;
        var zp = [["living", 30], ["kitchen", 20]];
        if (tier >= 3) zp.push(["study", 20]);
        if (tier >= 2) zp.push(["garden", 10]);
        var z = SP.pickW(zp);
        var zh = SP.homeZones[z] || z;
        p.homeState = { zone: z, action: "idle", actionZh: "在" + zh, blockKey: satKey };
      }
      return p.homeState;
    }
    /* 怀孕期/产假白天（7-20）：全天在家，半小时块随机房间休息 */
    if (p.resident && (SP.pregStatus(v).pregnant || SP.maternityActive(v)) && mins >= 7 * 60 && mins < 20 * 60) {
      var slotP = Math.floor((mins - 7 * 60) / 30);
      var pregKey = "preg" + day + "-" + slotP;
      if (!(p.homeState && p.homeState.blockKey === pregKey)) {
        var tierP = Number(v.SF.homeTier) || 1;
        var zpP = [["living", 35], ["kitchen", 15], ["herRoom", 20]];
        if (tierP >= 3) zpP.push(["study", 15]);
        if (tierP >= 2) zpP.push(["garden", 10]);
        var zP = SP.pickW(zpP);
        var actP = { living: "在沙发上靠着休息", kitchen: "在厨房热了点东西吃", herRoom: "在房间里躺着歇一会儿", study: "在书房看会儿书", garden: "在小院慢慢散步" };
        var aP = actP[zP] || "在家休息";
        p.homeState = { zone: zP, action: "rest", actionZh: aP, blockKey: pregKey };
      }
      return p.homeState;
    }
    if (p.resident && Number(t.hour) === 6 && mins < 7 * 60) {
      p.homeState = { zone: "kitchen", action: "cooking", actionZh: "在厨房做早饭", blockKey: "bf6-" + day };
      return p.homeState;
    }
    if (block === "none") {
      p.homeState = { zone: "away", action: "away", actionZh: "不在家", blockKey: "away-" + day };
      return p.homeState;
    }
    if (block === "sleep") {
      p.homeState = { zone: "herRoom", action: "sleeping", actionZh: "已经睡下", blockKey: "sleep-" + day };
      return p.homeState;
    }
    if (block === "bath") {
      p.homeState = { zone: "bathroom", action: "shower", actionZh: "在浴室洗澡", blockKey: "bath-" + day };
      return p.homeState;
    }
    if (block === "quiet") {
      var q = SP.homeActions.herRoom.quiet || [];
      var qa = q[Math.floor(Math.random() * q.length)] || "在房间里";
      p.homeState = { zone: "herRoom", action: qa, actionZh: qa, blockKey: "quiet-" + day };
      return p.homeState;
    }
    var key = day + "|" + block;
    if (p.homeState && p.homeState.blockKey === key && p.homeState.zone !== "herRoom") return p.homeState;
    var tier = Number(v.SF.homeTier) || 1;
    var pairs = [["living", SP.homeWeights.living]];
    if (block === "evening") {
      pairs.push(["kitchen", SP.homeWeights.kitchen]);
      if (tier >= 2) pairs.push(["garden", SP.homeWeights.garden]);
      if (tier >= 3) pairs.push(["study", SP.homeWeights.study]);
    } else { /* evening2 */
      if (tier >= 3) pairs.push(["study", SP.homeWeights.study]);
    }
    var zone = SP.pickW(pairs);
    var acts = SP.homeActions[zone] && SP.homeActions[zone][block];
    if (!acts || !acts.length) { zone = "living"; acts = SP.homeActions.living.evening || SP.homeActions.living.evening2; }
    var action = acts[Math.floor(Math.random() * acts.length)];
    p.homeState = { zone: zone, action: action, actionZh: action, blockKey: key };
    return p.homeState;
  };
  SP.isResident = function (v) { var p = SP.ensure(v); return !!(p && p.resident && !SP.isGone(v)); };

  /* 当前"女性流程"资格 = 悉尼有阴道（与性别字段解耦；男+阴道同样适用，人称暂全部"她"） */
  SP.hasVagina = function () {
    try {
      var s = (typeof C !== "undefined" && C.npc && C.npc.Sydney) ? C.npc.Sydney : null;
      return !!(s && s.vagina !== "none" && s.vagina !== undefined && s.vagina !== null);
    } catch (e) { return false; }
  };
  /* ---------- 怀孕 Phase2：自家接产/登记（孩子 location=sh_home，绕开孤儿院交接） ---------- */
  SP.sydneyBirthAvailable = function (v) {
    try {
      var p = SP.ensure(v);
      var st = SP.ensurePregStory(v);
      if (!p || !p.resident || !st) return false;
      if (st.stage !== "labour") return false;
      return SP.pregStatus(v).labour;
    } catch (e) { return false; }
  };
  /* 自家接产：调原版 endNpcPregnancy 收尾并登记；story 落 raising / nursery=true */
  SP.sydneyGiveBirth = function (v, day, loc) {
    try {
      var st = SP.ensurePregStory(v);
      if (!st || (st.stage !== "labour" && st.stage !== "conceived")) return false;
      var s = (typeof C !== "undefined" && C.npc && C.npc.Sydney) ? C.npc.Sydney : null;
      var pg = s && s.pregnancy;
      if (!pg || !pg.fetus || !pg.fetus.length) return false;
      var loc2 = loc || "sh_home";
      var preIds = [];
      for (var j = 0; j < pg.fetus.length; j++) { if (pg.fetus[j].childId) preIds.push(pg.fetus[j].childId); }
      var did = false;
      if (typeof endNpcPregnancy === "function") {
        did = !!endNpcPregnancy("Sydney", loc2, loc2);
      } else {
        pg.fetus = []; pg.timer = null; pg.timerEnd = null; pg.waterBreaking = false;
        did = true;
      }
      if (!did && pg.fetus && pg.fetus.length) return false;
      var childId = preIds.length ? preIds[0] : null;
      st.birthDay = (day !== undefined && day !== null) ? Number(day) : null;
      st.childId = childId;
      st.nursery = true;
      st.stage = "raising";
      return true;
    } catch (e) { return false; }
  };

  /* ---------- 消失线 / 缺席分档（6/7 步；d≥7 她带着孩子离开，永久，预留 returnDay 复活位） ---------- */
  /* 消失线：直接取消当前这轮舞台剧（悉尼被写进卡司的事件） */
  SP.cancelEnglishPlay = function (v) {
    try {
      if (!v) return;
      if (v.englishPlay === "ongoing") {
        v.englishPlay = "none";
        if (v.englishPlayDays !== undefined) v.englishPlayDays = 0;
        delete v.englishPlayLate;
        if (v.englishPlayRole !== undefined) delete v.englishPlayRole;
      }
    } catch (e) { /* ignore */ }
  };

  /* ---------- 神殿双人仪式全灭（v0.1.42：Sydney Temple Test / 破碎承诺赎罪链） ----------
     原版在 $templePromised is "Sydney" 时，神殿月度贞洁检查/违反誓约赎罪都会把悉尼召来
     （正文用宏/npcincr，不经过 sydneySchedule，punish 兜底管不到）。
     约定：仅**消失线（gone）**期间神殿双人仪式对悉尼不可达——gone 时从根上取消神殿承诺
     （备份到 story.promiseBackup，returnDay 复活时可还原）；孕期/产假/正常入驻仍走原版双人检查。 */
  SP.templeSydneyScenes = [
    "Sydney Temple Test", "Sydney Temple Test 2", "Sydney Temple Test Refuse", "Sydney Temple Test Admission",
    "Sydney Temple Punish Intro", "Sydney Temple Punish Intro Confession", "Sydney Temple Punish Intro Apologise",
    "Sydney Temple Punish Intro Early", "Sydney Temple Punish Intro Forget", "Sydney Temple Punish Intro Cancel",
    "Sydney Temple Punish Intro 2", "Sydney Temple Punish Intro 3", "Sydney Temple Punish Intro 4",
    "Sydney Temple Punish", "Sydney Temple Punish Repeat", "Sydney Temple Punish Hold", "Sydney Temple Punish Belt",
    "Sydney Temple Punish Hit", "Sydney Temple Punish Plead", "Sydney Temple Punish Close",
    "Sydney Temple Punish Touch", "Sydney Temple Punish End"
  ];
  /* gone 时取消与悉尼的神殿承诺（唯一保留点 = 承诺仪式 $templePromised="Sydney"） */
  SP.voidSydneyPromise = function (v) {
    try {
      if (!v || v.templePromised !== "Sydney") return false;
      var st = SP.ensurePregStory(v);
      if (st && !st.promiseBackup) st.promiseBackup = { templePromised: v.templePromised };
      v.templePromised = "";
      return true;
    } catch (e) { return false; }
  };
  /* 旧档兜底：已是 gone 但承诺还挂着（v0.1.41 及更早存档）→ 加载即清，幂等 */
  SP.ensureGoneConsistency = function (v) {
    try {
      if (!v || !SP.isGone(v)) return false;
      return SP.voidSydneyPromise(v);
    } catch (e) { return false; }
  };
  /* 点击拦截网（兜底）：仅 gone 期间，任何指向神殿双人段落的链接都改为不召唤悉尼的等价行为。
     - 双人检查三入口 → 就地降级原版单人检查（同主厅单人分支：Allow 置 $phase=2），津贴/净化流程照走，绝不"死点击"；
     - 其余双人惩罚链段落 → 回神殿大厅（防漏网，如忏悔室 Jordan 分支 3 处 $templePromised is "Sydney" 无法逐一补丁）。 */
  SP.templeSoloTarget = function (dp) {
    if (dp === "Sydney Temple Test") return "Temple Test";
    if (dp === "Sydney Temple Test Refuse") return "Temple Test Refuse";
    if (dp === "Sydney Temple Test Admission") return "Temple Test Admission";
    return null;
  };
  SP.blockTempleSydneyLinks = function () {
    try {
      if (typeof document === "undefined" || window.__sfTempleSydneyBlock) return;
      window.__sfTempleSydneyBlock = true;
      document.addEventListener("click", function (ev) {
        try {
          var V = (typeof State !== "undefined" && State.variables) ? State.variables : null;
          if (!V || !SP.isGone(V)) return;
          var el = ev && ev.target;
          while (el && el !== document) {
            if (el.tagName === "A") {
              var dp = el.getAttribute ? el.getAttribute("data-passage") : null;
              if (dp && SP.templeSydneyScenes.indexOf(dp) >= 0) {
                if (ev.preventDefault) ev.preventDefault();
                if (ev.stopPropagation) ev.stopPropagation();
                if (dp === "Sydney Temple Test") {
                  try { State.variables.phase = 2; } catch (e2) { /* ignore */ }  /* 与原版主厅单人 Allow 分支一致 */
                }
                var solo = SP.templeSoloTarget(dp);
                var go = solo || "Temple";
                if (typeof Engine !== "undefined" && Engine.play) Engine.play(go);
                return;
              }
              break;
            }
            el = el.parentNode;
          }
        } catch (e) { /* ignore */ }
      }, true);
    } catch (e) { /* ignore */ }
  };
  SP.isGone = function (v) {
    try {
      var st = SP.ensurePregStory(v);
      return !!(st && (st.stage === "gone" || st.gone === true));
    } catch (e) { return false; }
  };
  SP.goneDisappear = function (v, day) {
    try {
      var st = SP.ensurePregStory(v);
      if (!st || st.stage === "gone" || st.gone === true) return false;
      var did = SP.sydneyGiveBirth(v, day, "sh_home");
      st.gone = true;
      st.goneDay = (day !== undefined && day !== null) ? Number(day) : null;
      st.leftWithChild = true;
      st.goneChildId = st.childId;
      st.labourDay = null;
      st.stage = "gone";
      if (st.childId && v && v.children && v.children[st.childId]) v.children[st.childId].takenBySydney = true;
      SP.cancelEnglishPlay(v);
      SP.voidSydneyPromise(v);
      return !!did;
    } catch (e) { return false; }
  };
  /* 引擎超期自动分娩后的消失兜底（防孩子落孤儿院/状态错乱）：直接标记她已带孩子离开 */
  SP.goneAutoRecover = function (v, day) {
    try {
      var st = SP.ensurePregStory(v);
      if (!st || st.stage === "gone" || st.gone === true) return false;
      var cid = st.childId;
      if (!cid && v && v.children) {
        for (var k in v.children) {
          var ch = v.children[k];
          if (ch && ch.mother === "Sydney" && ch.father === "pc") { cid = k; break; }
        }
      }
      if (cid) {
        st.childId = cid;
        if (v && v.children && v.children[cid]) v.children[cid].takenBySydney = true;
      }
      st.gone = true;
      st.goneDay = (day !== undefined && day !== null) ? Number(day) : null;
      st.leftWithChild = !!cid;
      st.goneChildId = cid;
      st.labourDay = null;
      st.stage = "gone";
      SP.cancelEnglishPlay(v);
      SP.voidSydneyPromise(v);
      return true;
    } catch (e) { return false; }
  };
  /* 缺席分档（按临盆首日起天数 d）：same=当天 / miss=d1 / f1=d2-3 / f2=d4-5 / f3=d6 / gone=d>=7 */
  SP.absenceTier = function (v, t) {
    try {
      var st = SP.ensurePregStory(v);
      if (!st || st.stage !== "labour" || SP.isGone(v)) return null;
      if (st.labourDay === null || !t) return "same";
      var d = Number(t.days) - Number(st.labourDay);
      if (d <= 0) return "same";
      /* 只有真的离开过家（awayDay >= labourDay）才算"逾期/缺席"；在家睡过头不算 */
      if (st.awayDay === null || Number(st.awayDay) < Number(st.labourDay)) return "same";
      if (d === 1) return "miss";
      if (d <= 3) return "f1";
      if (d <= 5) return "f2";
      if (d === 6) return "f3";
      return "gone";
    } catch (e) { return null; }
  };
  /* ---------- 怀孕机制（Phase1：纯线开启 + 故事层状态机；文本钩子后补） ---------- */
  SP.ensurePregStory = function (v) {
    try {
      if (!v) return null;
      if (v.sydneyPregStory === undefined) {
        v.sydneyPregStory = { stage: "none", awareAt: null, revealDay: null, birthDay: null, childId: null, nursery: false, routeP: false, promiseHome: false, routeC: false, labourDay: null, missedBirth: false, missedBirthCount: 0, gone: false, goneDay: null, leftWithChild: false, goneChildId: null, returnDay: null, awayDay: null, postpartumDay: null, maternityUntil: null };
      } else {
        var st = v.sydneyPregStory;
        if (st.stage === undefined) st.stage = "none";
        if (st.awareAt === undefined) st.awareAt = null;
        if (st.revealDay === undefined) st.revealDay = null;
        if (st.birthDay === undefined) st.birthDay = null;
        if (st.childId === undefined) st.childId = null;
        if (st.nursery === undefined) st.nursery = false;
        if (st.routeP === undefined) st.routeP = false;
        if (st.promiseHome === undefined) st.promiseHome = false;
        if (st.routeC === undefined) st.routeC = false;
        if (st.labourDay === undefined) st.labourDay = null;
        if (st.missedBirth === undefined) st.missedBirth = false;
        if (st.missedBirthCount === undefined) st.missedBirthCount = 0;
        if (st.gone === undefined) st.gone = false;
        if (st.goneDay === undefined) st.goneDay = null;
        if (st.leftWithChild === undefined) st.leftWithChild = false;
        if (st.goneChildId === undefined) st.goneChildId = null;
        if (st.returnDay === undefined) st.returnDay = null;
        if (st.awayDay === undefined) st.awayDay = null;
        if (st.postpartumDay === undefined) st.postpartumDay = null;
        if (st.maternityUntil === undefined) st.maternityUntil = null;
      }
      return v.sydneyPregStory;
    } catch (e) { return null; }
  };
  /* 纯线开启：承诺仪式完成且悉尼有阴道 → pregnancy.enabled + 放行 canBePregnant */
  SP.ensureSydneyFertile = function (v) {
    try {
      if (!v || v.templePromised !== "Sydney") return false;
      if (!SP.hasVagina()) return false;
      var s = (typeof C !== "undefined" && C.npc && C.npc.Sydney) ? C.npc.Sydney : null;
      if (!s || Number(s.init) !== 1) return false;
      if (typeof setup !== "undefined" && setup.pregnancy && setup.pregnancy.canBePregnant) {
        if (setup.pregnancy.canBePregnant.indexOf("Sydney") < 0) setup.pregnancy.canBePregnant.push("Sydney");
      }
      if (!s.pregnancy) s.pregnancy = { type: "none", timer: 0 };
      s.pregnancy.enabled = true;
      return true;
    } catch (e) { return false; }
  };
  /* 胎儿个数（出生登记前取，供双胎文本） */
  SP.pregFetusCount = function (v) {
    try {
      var s = (typeof C !== "undefined" && C.npc && C.npc.Sydney) ? C.npc.Sydney : null;
      if (!s || !s.pregnancy || !s.pregnancy.fetus) return 0;
      return Number(s.pregnancy.fetus.length) || 0;
    } catch (e) { return 0; }
  };
  /* 给孩子写入名字（命名输入用） */
  SP.nameLastChild = function (v, name) {
    try {
      var st = SP.ensurePregStory(v);
      if (!st || !st.childId || !v || !v.children || !v.children[st.childId]) return false;
      var nm = String(name || "").trim();
      if (!nm) nm = "宝宝";
      v.children[st.childId].name = nm;
      var p = SP.ensure(v);
      if (p) p.babyName = nm;
      return true;
    } catch (e) { return false; }
  };
  /* 产后休养：maternityUntil 之前她一直在家（产假）；stage 需 raising（生完） */
  SP.maternityActive = function (v) {
    try {
      var st = SP.ensurePregStory(v);
      if (!st || SP.isGone(v)) return false;
      if (st.stage !== "raising") return false;
      var T = (typeof Time !== "undefined") ? Time : null;
      if (!T) return !!st.maternityUntil;
      if (!st.maternityUntil) return false;
      return Number(T.days) <= Number(st.maternityUntil);
    } catch (e) { return false; }
  };
  /* 产后收尾（卧室设置开关）：默认事件推进 8 小时；开启"跳过 7 天"才硬跳 7 天到清晨 6 点。都登记 3 周产假 */
  SP.postpartumRest = function () {
    try {
      if (typeof Time === "undefined") return false;
      var V = (typeof State !== "undefined" && State.variables) ? State.variables : null;
      if (!V) return false;
      var st = SP.ensurePregStory(V);
      if (!st) return false;
      var p = SP.ensure(V);
      var skip7 = !!(p && p.postpartumSkip7);
      if (skip7) {
        var curMin = Number(Time.hour) * 60 + (Number(Time.minute) || 0);
        var deltaMin = 7 * 1440 + (360 - curMin);
        if (deltaMin > 0) Time.pass(deltaMin * 60);
      } else {
        Time.pass(8 * 3600);
      }
      var day = Number(Time.days);
      st.postpartumDay = day;
      st.maternityUntil = day + 21;
      return true;
    } catch (e) { return false; }
  };
  /* 只读机制层：悉尼当前孕程状态（引擎字段权威） */
  SP.pregStatus = function (v) {
    try {
      var out = { enabled: false, pregnant: false, phase: "none", progress: 0, aware: false, labour: false, story: null };
      if (!v) return out;
      out.story = SP.ensurePregStory(v);
      var s = (typeof C !== "undefined" && C.npc && C.npc.Sydney) ? C.npc.Sydney : null;
      if (!s || !s.pregnancy) return out;
      var pg = s.pregnancy;
      out.enabled = !!pg.enabled;
      if (!pg.fetus || !pg.fetus.length) return out;
      out.pregnant = true;
      var te = Number(pg.timerEnd) || 1;
      var t = Number(pg.timer) || 0;
      out.progress = Math.min(1, t / te);
      var p = out.progress;
      out.phase = p <= 1 / 3 ? "early" : p <= 2 / 3 ? "mid" : "late";
      out.aware = !!pg.npcAwareOf || !!pg.pcAwareOf;
      out.labour = !!pg.waterBreaking || t >= te;
      return out;
    } catch (e) { return { enabled: false, pregnant: false, phase: "none", progress: 0, aware: false, labour: false, story: null }; }
  };
  /* 故事层推进：只消费机制字段，不写回引擎 */
  SP.pregTick = function (v, t) {
    try {
      var st = SP.ensurePregStory(v);
      if (!st) return st;
      if (st.stage === "gone" || st.gone === true) return st;
      var stt = SP.pregStatus(v);
      /* raising 状态下引擎又怀孕（含 birthDay 缺失的历史脏档）→ 重置本轮孕程字段，链可重跑；旧孩子记入 st.kids */
      if (stt.pregnant && st.stage === "raising") {
        if (st.childId && !(st.kids || []).includes(st.childId)) {
          if (!Array.isArray(st.kids)) st.kids = [];
          st.kids.push(st.childId);
        }
        st.stage = "none";
        st.birthDay = null;
        st.childId = null;
        st.labourDay = null;
        st.missedBirth = false;
        st.missedBirthCount = 0;
        st.gone = false;
        st.goneDay = null;
        st.leftWithChild = false;
        st.goneChildId = null;
      }
      var day = t ? Number(t.days) : null;
      if (stt.pregnant && st.stage === "none") st.stage = "conceived";
      if (stt.aware && st.awareAt === null && day !== null) st.awareAt = day;
      if (stt.labour && st.stage !== "labour" && st.stage !== "raising") st.stage = "labour";
      /* 容错：引擎已临盆但故事层误置 raising 且从未登记出生 → 回到 labour（修存档不一致） */
      if (stt.labour && st.stage === "raising" && st.birthDay === null) st.stage = "labour";
      /* 临盆首日登记 labourDay（缺席分档计时起点） */
      if (st.stage === "labour" && st.labourDay === null && day !== null) st.labourDay = day;
      /* d >= 7 且仍未接产 → 消失线：她独自分娩后带着孩子离开（永久，预留 returnDay 复活位） */
      if (st.stage === "labour" && st.labourDay !== null && day !== null && (day - st.labourDay) >= 7) {
        SP.goneDisappear(v, day);
        return st;
      }
      /* 兜底：引擎超期自动分娩（未走自家接产）→ 已临盆过且 d>=7 → 消失线；否则标记在外出生 */
      if (st.stage !== "none" && st.stage !== "raising" && st.stage !== "gone" && !stt.pregnant && st.birthDay === null) {
        if (st.labourDay !== null && day !== null && (day - st.labourDay) >= 7) {
          SP.goneAutoRecover(v, day);
        } else {
          st.stage = "raising";
          st.nursery = false;
        }
      }
      return st;
    } catch (e) { return null; }
  };
  /* ---------- 路线 P：未同居报喜（文案终稿见 sydney_pack_preg_announce_design.md v0.5） ---------- */
  SP.PREG_TELL_SCENES = { "Temple Sydney": "temple", "Canteen": "canteen", "School Library": "library", "Library Rental Counter": "library" };
  /* 未同居 + 怀孕 + 未告知过 → 可触发报喜 */
  SP.pregTellReady = function (v) {
    try {
      var p = SP.ensure(v);
      if (!p || p.resident) return false;
      var st = SP.ensurePregStory(v);
      if (!st || st.routeP) return false;
      return SP.pregStatus(v).pregnant;
    } catch (e) { return false; }
  };
  /* 场景段 + 引擎位置命中（T.sydney_location 由原版 sydneySchedule 刷新） */
  SP.pregTellForScene = function (v, passage, loc) {
    if (!passage || !loc) return false;
    if (SP.PREG_TELL_SCENES[passage] !== loc) return false;
    return SP.pregTellReady(v);
  };
  /* 答应她：标记已告知 + 承诺给家（Sydney Walk 出「告诉悉尼房子准备好了」的开关） */
  SP.pregMarkTold = function (v) {
    var st = SP.ensurePregStory(v);
    if (!st) return false;
    st.routeP = true;
    st.promiseHome = true;
    return true;
  };
  /* ---------- 孕吐（怀孕期早晨 6-7；40% 触发一次；文案见 sydney_pack_preg_home_design.md） ---------- */
  SP.morningSickWindow = function (v, t) {
    try {
      var p = SP.ensure(v);
      if (!p || !p.resident || !t) return false;
      if (Number(t.hour) !== 6) return false;
      var stt = SP.pregStatus(v);
      if (!stt.pregnant) return false;
      return stt.phase === "early" || stt.phase === "mid";
    } catch (e) { return false; }
  };
  /* 怀孕版早餐（60% 正常早餐路径）判定：同居+怀孕+已告知（与孕吐同口径） */
  SP.pregBreakfastActive = function (v) {
    try {
      var p = SP.ensure(v);
      if (!p || !p.resident) return false;
      var stt = SP.pregStatus(v);
      if (!stt || !stt.pregnant) return false;
      var st = SP.ensurePregStory(v);
      if (!st) return false;
      return !!(st.routeP || st.routeC || stt.aware);
    } catch (e) { return false; }
  };
  SP.morningSickRoll = function (v, t, rand) {
    var p = SP.ensure(v);
    if (!p || !SP.morningSickWindow(v, t) || p.morningRollDay === Number(t.days)) return false;
    p.morningRollDay = Number(t.days);
    var sick = (rand === undefined ? Math.random() : Number(rand)) < 0.4;
    p.morningSickDay = sick ? Number(t.days) : null;
    return sick;
  };
  SP.morningSickActive = function (v, t) {
    var p = SP.ensure(v);
    return SP.morningSickWindow(v, t) && !!p && p.morningRollDay === Number(t.days) && p.morningSickDay === Number(t.days);
  };
  /* 跳到早上 7:00（孕吐事件结束；静默不写时间文字） */
  SP.jumpTo7 = function () {
    try {
      if (typeof Time === "undefined") return false;
      var cur = Number(Time.hour) * 3600 + Number(Time.minute) * 60;
      var target = 7 * 3600;
      var delta = (target - cur + 86400) % 86400;
      if (delta > 0) Time.pass(delta);
      return true;
    } catch (e) { return false; }
  };
  /* DOM 兜底 v4（隐藏不删除）：同居+怀孕时把她在校外场景的整块 display:none，
     保留图标与行结构，仅重编号；兼容加载器不应用 patch 的情况 */
  SP.SYDNEY_BLOCK_TARGETS = {
    "Temple": ["Temple Sydney Wakeup"],
    "School Library": ["Library Rental Counter", "Sydney Library Intro"],
    "Library Rental Counter": ["Library Rental Counter", "Sydney Library Intro"],
    "Canteen": []
  };
  SP._renumberPassage = function (host) {
    try {
      if (window.Links && typeof window.Links.generateLinkNumbers === "function") {
        window.Links.generateLinkNumbers(host);
      }
    } catch (e) { /* ignore */ }
    clearTimeout(SP._renumberPassage._t);
    SP._renumberPassage._t = setTimeout(function () {
      try {
        if (window.Links && typeof window.Links.generateLinkNumbers === "function") {
          window.Links.generateLinkNumbers(host);
        }
      } catch (e) { /* ignore */ }
    }, 250);
  };
  SP.hideSydneyRows = function () {
    try {
      if (typeof State === "undefined" || typeof document === "undefined") return;
      var V = State.variables;
      if (!SP.isPregHome(V)) return;
      var targets = SP.SYDNEY_BLOCK_TARGETS[State.passage];
      if (!targets || !targets.length) return;
      var host = document.querySelector("#passages .passage") || document.getElementById("passages");
      if (!host) return;
      var links = host.querySelectorAll("a[data-passage]");
      var changed = false;
      for (var i = 0; i < links.length; i++) {
        var a = links[i];
        var dp = a.getAttribute("data-passage") || "";
        var label = (a.textContent || "").trim();
        var isSydney = targets.indexOf(dp) >= 0;
        if (State.passage === "Canteen") {
          isSydney = label.indexOf("悉尼") >= 0 || label.indexOf("Sydney") >= 0;
        }
        if (!isSydney) continue;
        var box = a.parentNode;
        if (!box) continue;
        var all = [];
        for (var c = box.firstChild; c; c = c.nextSibling) all.push(c);
        var idx = all.indexOf(a);
        if (idx < 0) continue;
        var p = idx - 1;
        while (p >= 0 && !(all[p].nodeType === 1 && all[p].tagName === "A")) p--;
        var n = idx + 1;
        while (n < all.length && !(all[n].nodeType === 1 && all[n].tagName === "A")) n++;
        var nextA = n < all.length ? all[n] : null;
        /* 下一行链接自带的图标（紧贴 nextA 的 <img>/空白）要保留 */
        var hi = n;
        while (hi > idx + 1) {
          var prev = all[hi - 1];
          var isImg = prev.nodeType === 1 && prev.tagName === "IMG";
          var isWs = prev.nodeType === 3 && !(/\S/.test(prev.nodeValue || ""));
          if (!isImg && !isWs) break;
          hi--;
        }
        var lo = p >= 0 ? p + 1 : 0;
        var hiddenAny = false;
        var lastHidden = null;
        for (var k = lo; k < hi; k++) {
          if (all[k] === nextA) continue;
          if (all[k].style) { all[k].style.display = "none"; hiddenAny = true; lastHidden = all[k]; }
        }
        if (hiddenAny && nextA && lastHidden) {
          /* 隐藏段后若与下一行之间没有可见 <br>，补一个（插在下一行图标/链接前） */
          var insertPos = (hi < all.length) ? all[hi] : nextA;
          var needBr = true;
          var scan = lastHidden.nextSibling;
          while (scan && scan !== insertPos) {
            if (scan.nodeType === 1 && scan.tagName === "BR" && scan.style.display !== "none") { needBr = false; break; }
            scan = scan.nextSibling;
          }
          if (needBr && insertPos && insertPos.parentNode) {
            var br = document.createElement("br");
            insertPos.parentNode.insertBefore(br, insertPos);
          }
          changed = true;
        }
      }
      if (changed) SP._renumberPassage(host);
    } catch (e) { /* ignore */ }
  };

  /* 同居+怀孕 = 全天在家：她不应出现在校外各场景（补丁用判定） */
  SP.isPregHome = function (v) {
    try {
      if (SP.isGone(v)) return true;   /* 消失线：与孕期一样"全天不在校外"（且家里只有红字/信） */
      var p = SP.ensure(v);
      if (!p || !p.resident) return false;
      if (SP.maternityActive(v)) return true;
      return SP.pregStatus(v).pregnant;
    } catch (e) { return false; }
  };
  /* 孕态性爱文本上下文（Love Night 首屏 / Finish 分支用） */
  SP.pregSexCtx = function (v) {
    var p = SP.ensure(v);
    var stt = SP.pregStatus(v);
    var corrupt = false;
    try {
      corrupt = !!(typeof C !== "undefined" && C.npc && C.npc.Sydney && Number(C.npc.Sydney.corruption) >= 10);
    } catch (e) { /* ignore */ }
    return {
      pregnant: !!stt.pregnant,
      phase: stt.phase,
      lead: (p && p.sexLead === "npc") ? "npc" : "player",
      corrupt: corrupt
    };
  };
  /* 4 个挂点场景：进入时她本时段在此 → 直接自动触发完整报喜事件（不插行、不点靠近她；用户 2026-09 要求） */
  SP.renderPregTell = function () {
    try {
      if (typeof State === "undefined" || typeof document === "undefined") return;
      var V = State.variables;
      var loc = (typeof State.temporary !== "undefined" && State.temporary) ? State.temporary.sydney_location : null;
      var passage = State.passage || "";
      if (!SP.PREG_TELL_SCENES[passage]) return;
      if (!SP.pregTellForScene(V, passage, loc)) return;
      if (V.SF.pregAuto) return;            /* 本次会话已自动进入过（防重复/循环） */
      V.SF.pregAuto = true;
      V.SF.pregRet = passage;               /* 事件结束回原场景 */
      setTimeout(function () {
        try { if (typeof Engine !== "undefined" && Engine.play) Engine.play("SH Sydney Preg Tell"); } catch (e) { /* ignore */ }
      }, 0);
    } catch (e) { /* ignore */ }
  };

  /* 孕吐自动触发：厨房 6-7 首次进入掷骰，40% → 进 SH Sydney Morning Sickness（已告知/察觉才触发） */
  SP.renderMorningSick = function () {
    try {
      if (typeof State === "undefined" || typeof document === "undefined") return;
      if (State.passage !== "SH House Kitchen") return;
      var V = State.variables;
      var T = (typeof Time !== "undefined") ? Time : null;
      if (!T) return;
      var st = SP.ensurePregStory(V);
      var known = !!st && (st.routeP || st.routeC) || SP.pregStatus(V).aware;
      if (!known) return;
      var p = SP.ensure(V);
      if (p.morningRollDay !== Number(T.days)) SP.morningSickRoll(V, T, Math.random());
      if (!SP.morningSickActive(V, T)) return;   /* 60%：正常早餐（怀孕版早餐后续） */
      var key = State.passage + "|" + Number(T.days);
      if (SP._msNav === key) return;
      SP._msNav = key;
      setTimeout(function () {
        try { if (typeof Engine !== "undefined" && Engine.play) Engine.play("SH Sydney Morning Sickness"); } catch (e) { /* ignore */ }
      }, 0);
    } catch (e) { /* ignore */ }
  };

  /* ---------- 同居路线 C：回家报喜（悉尼在家 + 玩家从门外进家 → 自动触发完整事件） ---------- */
  SP.pregHomeTold = function (v) {
    var st = SP.ensurePregStory(v);
    if (!st) return false;
    st.routeC = true;
    return true;
  };
  SP.homeTellReady = function (v, t) {
    try {
      var p = SP.ensure(v);
      if (!p || !p.resident) return false;
      var st = SP.ensurePregStory(v);
      if (!st || st.routeC || st.routeP) return false;   /* P 线已告诉过 → 不再回家报喜 */
      if (!SP.pregStatus(v).pregnant) return false;
      var hs = SP.homeStateFor(v, t);
      if (!hs || hs.zone === "away") return false;        /* 她在家才算 */
      return true;
    } catch (e) { return false; }
  };
  SP.trackPassage = function (passage) {
    SP._prevPassage = SP._curPassage || null;
    SP._curPassage = passage;
  };
  /* 从门外（Danube Street）进 SH House Entrance → 自动触发 */
  SP.renderHomeTell = function () {
    try {
      if (typeof State === "undefined" || typeof document === "undefined") return;
      var V = State.variables;
      if (State.passage !== "SH House Entrance") return;
      if (SP._prevPassage !== "Danube Street") return;    /* 只在"从门外回来"时触发 */
      var T = (typeof Time !== "undefined") ? Time : null;
      if (!SP.homeTellReady(V, T)) return;
      SP.pregHomeTold(V);
      setTimeout(function () {
        try { if (typeof Engine !== "undefined" && Engine.play) Engine.play("SH Sydney Home Tell"); } catch (e) { /* ignore */ }
      }, 0);
    } catch (e) { /* ignore */ }
  };

  /* 邀请同居资格：未入住/未邀约 + 承诺仪式完成 + 有阴道 + 名下有房（租住或买断均可） */
  SP.canInviteMoveIn = function (v) {
    try {
      var p = SP.ensure(v);
      if (!p || p.resident || p.movePhase) return false;
      var st = SP.ensurePregStory(v);
      if (st && st.promiseHome) return false;   /* 路线 P：已答应给家 → 走「告诉悉尼房子准备好了」 */
      if (!v || v.templePromised !== "Sydney") return false;
      if (!SP.hasVagina()) return false;
      var sf = v.SF || {};
      return !!(sf.rented === true || sf.bought === true);
    } catch (e) { return false; }
  };
  /* 路线 P 告示行：已答应给家（promiseHome）+ 有房 + 未入住未邀约 → Sydney Walk 出「告诉悉尼房子准备好了」 */
  SP.canPregTellMoveIn = function (v) {
    try {
      var p = SP.ensure(v);
      if (!p || p.resident || p.movePhase) return false;
      var st = SP.ensurePregStory(v);
      if (!st || !st.promiseHome) return false;
      var sf = v.SF || {};
      return !!(sf.rented === true || sf.bought === true);
    } catch (e) { return false; }
  };
  /* 搬家就绪：已邀约，且为次日或之后（当天收拾行李，次日一起搬） */
  SP.moveReady = function (v, t) {
    try {
      var p = SP.ensure(v);
      if (!p || p.resident || p.movePhase !== "invited") return false;
      if (!t) return false;
      return Number(t.days) > Number(p.inviteDay);
    } catch (e) { return false; }
  };
  /* 入住后门厅描述替换（family 原文保留；未入住不变）。文本已由用户定稿（2026-09） */
  SP.HOME_ENTRANCE_TEXTS = [
    ["门开了，屋里有一股淡淡的木香——空荡荡的，但干净。", "门开了。玄关鞋架上多了一双鞋，屋里还留着淡淡的木香，却不再空荡——茶几上搁着读到一半的书，椅背上搭着一件叠得整齐的外套。"],
    ["（这是一栋可以住人的房子。等你有了想搬进来的人，再慢慢布置也不迟。）", "（房子不大，但终于有人等你回家了。）"],
    ["玄关不大但整洁，鞋柜旁的窗透进小院的绿意。", "玄关不大但整洁。鞋柜旁多了一双她的鞋，窗透进小院的绿意，风里带着刚浇过水的土腥味。"],
    ["（房子有了小院，夏天会很好待。）", "（小院夏天会很好待——现在，终于有两个人一起待了。）"],
    ["铁门在身后合拢，发出沉闷的声响。门厅高阔，水晶吊灯未开，但大理石地面擦得发亮。", "铁门在身后合拢，发出沉闷的声响。门厅高阔，水晶吊灯未开，大理石地面擦得发亮——鞋柜边却多了一双小码的鞋，空气里浮着淡淡的皂香。"],
    ["（大厅很大——大得足够装下一整个家，也许还有更多。）", "（大厅很大，现在终于有了要装下的家人。）"]
  ];
  SP.renderHomeEntrance = function () {
    try {
      if (typeof State === "undefined" || typeof document === "undefined") return;
      if (State.passage !== "SH House Entrance") return;
      var V = State.variables;
      if (!SP.isResident(V)) return;
      var walker = document.createTreeWalker(document.getElementById("passages"), NodeFilter.SHOW_TEXT, null);
      var node;
      while ((node = walker.nextNode())) {
        for (var i = 0; i < SP.HOME_ENTRANCE_TEXTS.length; i++) {
          var oldT = SP.HOME_ENTRANCE_TEXTS[i][0];
          if (node.nodeValue.indexOf(oldT) >= 0) {
            node.nodeValue = node.nodeValue.split(oldT).join(SP.HOME_ENTRANCE_TEXTS[i][1]);
          }
        }
      }
    } catch (e) { /* ignore */ }
  };
  /* 同居选项行（DOM 注入到原版 Sydney Walk 目的地列表尾；无引擎快捷键，走 DOM 点击） */
  SP.MOVEIN = {
    invite: { label: "悉尼，搬来和我一起住吧", passage: "SH Sydney MoveIn Invite", icon: "img/misc/icon/daydream.png" },
    ready: { label: "告诉悉尼，房子准备好了", passage: "SH Sydney Preg MoveIn", icon: "img/misc/icon/daydream.png" },
    move: { label: "一起去搬行李吧", passage: "SH Sydney Move Day", icon: "img/misc/icon/daydream.png" }
  };
  SP.renderMoveInRow = function () {
    try {
      if (typeof State === "undefined" || typeof document === "undefined") return;
      if (SP.isGone(State.variables)) return;   /* 消失线：Sydney Walk 不再出现任何入住/搬家行 */
      if (State.passage !== "Sydney Walk") return;
      var V = State.variables;
      var T = (typeof Time !== "undefined") ? Time : null;
      var kind = null;
      if (SP.moveReady(V, T)) kind = "move";              /* 已定搬家日：次日搬运行 */
      else if (SP.canPregTellMoveIn(V)) kind = "ready";   /* 路线 P：房子好了去告诉她 */
      else if (SP.canInviteMoveIn(V)) kind = "invite";
      if (!kind) return;
      if (document.getElementById("sf-movein-row")) return;
      var cfg = SP.MOVEIN[kind];
      var ref = null;
      var list = document.querySelectorAll("#passages a[data-passage]");
      for (var i = 0; i < list.length; i++) {
        var dp = list[i].getAttribute("data-passage");
        if (dp && dp.indexOf("Sydney Walk ") === 0) ref = list[i];
      }
      if (!ref) return;
      var a = document.createElement("a");
      a.className = "link-internal";
      a.id = "sf-movein-row";
      a.style.cursor = "pointer";
      a.addEventListener("click", function (ev) {
        try { if (ev.preventDefault) ev.preventDefault(); if (ev.stopPropagation) ev.stopPropagation(); } catch (e) { /* ignore */ }
        if (typeof Engine !== "undefined" && Engine.play) Engine.play(cfg.passage);
      });
      var im = document.createElement("img");
      im.className = "icon";
      im.src = cfg.icon;
      a.appendChild(im);
      a.appendChild(document.createTextNode(" " + cfg.label));
      var br1 = document.createElement("br");
      var br2 = document.createElement("br");
      var parent = ref.parentNode;
      var nxt = ref.nextSibling;
      parent.insertBefore(br1, nxt);
      parent.insertBefore(a, nxt);
      parent.insertBefore(br2, nxt);
    } catch (e) { /* ignore */ }
  };

  /* ---------- 菜谱/数值（对齐前置 eatDish 口径） ---------- */
  SP.d3Catalog = function () {
    var out = [];
    try {
      if (typeof setup === "undefined" || !setup.foodstuff) return out;
      Object.keys(setup.foodstuff).forEach(function (k) {
        var it = setup.foodstuff[k];
        var d = it && it.recipe ? Number(it.recipe.difficulty) : 0;
        if (it && it.category === "dish" && d === 3) out.push(k);
      });
    } catch (e) { /* ignore */ }
    return out;
  };
  SP.d3StockKeys = function (v) {
    var out = [];
    try {
      var cat = SP.d3Catalog();
      for (var i = 0; i < cat.length; i++) {
        if (v.foodstuff && v.foodstuff[cat[i]] && Number(v.foodstuff[cat[i]].amount) > 0) out.push(cat[i]);
      }
    } catch (e) { /* ignore */ }
    return out;
  };
  SP.pick = function (arr) { if (!arr || !arr.length) return null; return arr[Math.floor(Math.random() * arr.length)]; };

  /* 早餐窗口：入住 + 承诺纯线 + 早上 6 点 + 当天未吃过/未拒绝 */
  SP.breakfastActive = function (v, t) {
    var p = SP.ensure(v);
    if (!p.resident) return false;
    if (!(typeof C !== "undefined" && C.npc && C.npc.Sydney && C.npc.Sydney.init === 1)) return false;
    if (v.templePromised !== "Sydney") return false;
    if (!t || Number(t.hour) !== 6) return false;
    if (p.bfRefuseDay === Number(t.days)) return false;
    if (p.bfDoneDay === Number(t.days)) return false;
    if (v.statFreeze) return false;
    return true;
  };
  SP.refusedToday = function (v, t) {
    var p = SP.ensure(v);
    return p.resident && p.bfRefuseDay === Number(t.days);
  };

  /* 数值直改（绕过宏倍率、尊重 statFreeze）；full=难度3，tiny=自己吃小数值 */
  SP.applyMeal = function (v, mode) {
    var p = SP.ensure(v);
    var out = { fatigue: 0, stress: 0, trauma: 0, frozen: !!v.statFreeze };
    if (v.statFreeze) return out;
    if (mode === "tiny") { out.fatigue = 50; out.stress = 250; out.trauma = 125; }
    else { out.fatigue = 1000; out.stress = 5000; out.trauma = 2500; }
    v.tiredness = Math.max(0, (Number(v.tiredness) || 0) - out.fatigue);
    v.stress = Math.max(0, (Number(v.stress) || 0) - out.stress);
    v.trauma = Math.max(0, (Number(v.trauma) || 0) - out.trauma);
    return out;
  };
  /* 记录 6h 全局冷却（与前置同一 meals 字段）；不吃库存由调用方处理 */
  SP.markMeal = function (v, t) {
    try {
      if (typeof SF !== "undefined" && SF.logic && SF.logic.ensure) {
        var s = SF.logic.ensure(v);
        s.meals = { lastDay: Number(t.days), lastHour: Number(t.hour) };
      }
    } catch (e) { /* ignore */ }
  };
  SP.markDone = function (v, t) { var p = SP.ensure(v); p.bfDoneDay = Number(t.days); };
  SP.markRefused = function (v, t) { var p = SP.ensure(v); p.bfRefuseDay = Number(t.days); };
  SP.consumeOne = function (v, key) {
    try { if (v.foodstuff && v.foodstuff[key] && Number(v.foodstuff[key].amount) > 0) v.foodstuff[key].amount -= 1; } catch (e) { /* ignore */ }
  };

  /* ---------- 房间有人感知（v1.3 前置 API） ---------- */
  SP.presenceFn = function (v, t) {
    var p = SP.ensure(v);
    if (!p.resident) return [];
    var hs = SP.homeStateFor(v, t);
    if (!hs) return [];
    if (["living", "kitchen", "study", "garden", "bathroom"].indexOf(hs.zone) >= 0) return [{ room: hs.zone }];
    return [];
  };

  /* ---------- 房间守卫（早餐期 + 晚间） ---------- */
  function livingGuard(v, t) {
    var p = SP.ensure(v);
    if (!p.resident) return null;
    if (p.sofaLockDay === Number(t.days)) {
      return { block: true, msg: "悉尼正在沙发上睡觉，呼吸平稳，睡得很熟。最好还是不要打扰她，让她好好休息吧。" }; /* 悄悄看看她/陪睡：接口位，后补剧情 */
    }
    return null;
  }
  function bathroomGuard(v, t) {
    var p = SP.ensure(v);
    if (!p.resident) return null;
    if (p.bathLockDay === Number(t.days) && Number(t.hour) < 23) {
      var corrupt = !!(typeof C !== "undefined" && C.npc && C.npc.Sydney && Number(C.npc.Sydney.corruption) >= 10);
      var msg = corrupt
        ? "浴室里的水声断断续续的，像是开了又停。好一会儿，悉尼带着笑意的声音隔着门传来：\"<span class=\"lewd\">刚才……还没满足你吗？</span>\"水声又响了两下，她补了一句：\"<span class=\"lewd\">那晚上记得来我被窝，我会好好给你暖好床的。</span>\""
        : "浴室里传来水声和窸窸窣窣的动静，紧接着\"啪嗒\"一声像碰倒了什么。过了两秒，悉尼慌慌张张的声音隔着门传出来：\"<span class=\"gold\">……你、你别进来！我、我马上就好了！</span>\"";
      return { block: true, msg: msg };
    }
    return null;
  }
  function kitchenGuard(v, t) {
    if (!SP.isResident(v)) return null;
    if (!t || Number(t.hour) !== 6) return null;
    if (SP.refusedToday(v, t)) {
      return { block: true, msg: "<span class=\"red\">悉尼正在里面做饭，你说你不吃。</span>（7 点后厨房会开放。）" };
    }
    return null;
  }
  function diningGuard(v, t) {
    if (!SP.isResident(v)) return null;
    if (!t || Number(t.hour) !== 6) return null;
    return { block: true, msg: "<span class=\"gold\">早餐时间，悉尼在厨房忙活。</span>想吃早饭去厨房找她，或者等过了 7 点再来餐厅。" };
  }
  function registerGuards() {
    try {
      if (!(SF && SF.registerRoomGuard)) return;
      SF.registerRoomGuard("kitchen", kitchenGuard);
      SF.registerRoomGuard("dining", diningGuard);
      SF.registerRoomGuard("living", livingGuard);
      SF.registerRoomGuard("bathroom", bathroomGuard);
    } catch (e) { /* ignore */ }
  }

  /* ---------- 槽渲染（早餐/入住行）：DOM 直插 + 原生监听（无 href，纯内部链接样式） ---------- */
  function makeGo(passage, pre) {
    var a = document.createElement("a");
    a.className = "link-internal";
    a.setAttribute("data-passage", passage);
    a.style.cursor = "pointer";
    a.addEventListener("click", function (ev) {
      try { if (ev && ev.preventDefault) ev.preventDefault(); if (ev && ev.stopPropagation) ev.stopPropagation(); } catch (e) { /* ignore */ }
      try { if (pre) pre(); Engine.play(passage); } catch (e) { /* ignore */ }
    });
    return a;
  }
  function clearAppend(el, nodes) {
    if (!el) return;
    while (el.firstChild) el.removeChild(el.firstChild);
    for (var i = 0; i < nodes.length; i++) el.appendChild(nodes[i]);
    el.style.display = "";
  }

  SP.iconify = function (a) {
    try {
      if (a && SP.herRoomIcon) {
        var im = document.createElement("img");
        im.className = "icon";
        im.src = SP.herRoomIcon;
        a.insertBefore(im, a.firstChild);
      }
    } catch (e) { /* ignore */ }
    return a;
  };
  SP.letterIcon = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAMAAAAM7l6QAAADAFBMVEUAAAD9+uT689ny6c6qmG/It461qIrWyqq1o3rl17UpJBmYimoTEQ2Ke1iUg12MJiSUNjHb0belnIfj3MVyZ0uWlJDWxJq2tLNTSzV9IB11Z0YcGhNBOyuJiIrFxceopqlPRzTTvqfZ1sdsY0/Fro9PRzStZFyPhmyTWk3Dh4CAFxWfkWx5dWx+clF3cF1wbGiVZlCKgWyxeXOFfWhnXkRiXEtkVjhsXz+hh2p/HxxcVEBYUT5YUTygknKln4duYkLAkom9so/z5L87NiktKiCIe10AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABel4N2AAAA/3RSTlMA/v39/f39/v/+MPkI8/v////+/q36/v+J/+ghUP/9/2r//5D+W//G///////5q7L/rf+6rXTrzP3/jIh+2s7O//n/PSORAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACtoBaHAAABOUlEQVR42s2S1XbDMAyGK0uynaRh7so4ZmZ8/1eas63JttPe97/z+fQL3WptutoLKSe2vQ7bMQCG8eHHbCW+QBAoBGROerYiSQQCTACSBajCRXF7V7Qb+s6GGoUSRCWTCM8bXjBblV1bX1FVAHpJjU+QNbHFGmpFREu6FRqDkkSc/dghdqfDJZ7FgMLStOfp7yoA0nmoa5N5WySjiBRWOdQrHnBtHiKY2mqcSkEC0CIiSU5tfjTFlBrlvRAZd+YjM7rrderGlGlFDPL+QMZ4GvjBCJSrm9UlrBDzNB/0xs9BeVMGlvK4wbbMmLOo50gx3y39IFAvNPm18a7rauqnEgWXvu8fo8f3f2/SPerva5Y49f1tVJ7T/n+0LTvxHBNxrYRLzsqzvxVXZmjt6u66X2U/dS47SWvz9QlgsxOaJQH+ngAAAABJRU5ErkJggg==";
  /* 给任意链接加图标 */
  SP.iconifySrc = function (a, src) {
    try {
      if (!a || !src) return a;
      var im = document.createElement("img");
      im.className = "icon";
      im.src = src;
      a.insertBefore(im, a.firstChild);
    } catch (e) { /* ignore */ }
    return a;
  };
  /* 消失线：给"她留下的信/读那封信"链接统一加信图标 */
  SP.iconifyLetterLinks = function () {
    try {
      if (typeof document === "undefined" || typeof State === "undefined") return;
      if (!SP.isGone(State.variables)) return;
      if (!SP.letterIcon) return;
      var host = document.querySelector("#passages .passage") || document.getElementById("passages");
      if (!host) return;
      var links = host.querySelectorAll("a");
      for (var i = 0; i < links.length; i++) {
        var a = links[i];
        var txt = (a.textContent || "").trim();
        if (txt.indexOf("她留下的信") < 0 && txt.indexOf("读那封信") < 0) continue;
        if (a.querySelector("img")) continue;
        SP.iconifySrc(a, SP.letterIcon);
      }
    } catch (e) { /* ignore */ }
  };
  SP.herRoomIcon = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeBAMAAADJHrORAAAAJ1BMVEUAAACzjHrKysr///+PVjvGc3OsMjKxsbHDw8OEJyetra11IiJiOykoRM9jAAAAAXRSTlMAQObYZgAAAFFJREFUGNNjYBjMQACZw6SkgMJXNjZyAFLMoVAA46dBQbGxOV5+eXk5Ct/Y2BjE55gJBR0dHSA+124oWLVq1QEgnwfGP3PmDJh/BgGw8QcWAACYWUGUhKSkfQAAAABJRU5ErkJggg==";
  SP.syncGenitals = function () {
    try {
      var V = (typeof State !== "undefined" && State.variables) ? State.variables : null;
      if (!V) return;
      var i = (V.NPCNameList || []).indexOf("Sydney");
      var nm = V.NPCName && V.NPCName[i];
      if (!nm) return;
      var s = (typeof C !== "undefined" && C.npc && C.npc.Sydney) ? C.npc.Sydney : null;
      var hasP = !!(s && (Number(s.penissize) > 0 || (s.penis !== "none" && s.penis !== undefined && s.penis !== null)));
      var hasV = SP.hasVagina();
      nm.penis = hasP ? "clothed" : "none";
      nm.vagina = hasV ? "clothed" : "none";
      if (V.NPCList && V.NPCList[0]) {
        V.NPCList[0].penis = nm.penis;
        V.NPCList[0].vagina = nm.vagina;
      }
    } catch (e) { /* ignore */ }
  };
  SP.rollMood = function (v, t) {
    var love = 0;
    try { if (typeof C !== "undefined" && C.npc && C.npc.Sydney) love = Number(C.npc.Sydney.love) || 0; } catch (e) { /* ignore */ }
    var r = Math.random();
    var tired = !!t && (Number(t.hour) >= 22 || (v.daily && v.daily.sydney && v.daily.sydney.punish === 1));
    if (tired && r < 0.55) return "tired";
    if (love >= 60 && r >= 0.45) return "sweet";
    return "happy";
  };
  var HOME_TEXT = {
    livingRead: "悉尼正靠在沙发上看书，长发垂在肩侧，书页偶尔翻动着，她看着很仔细，似乎并没有发觉你来了。",
    sofaSleep: "悉尼在沙发上睡着了，呼吸平稳，睡得很沉。别吵醒她。",
    deskSleep: "悉尼趴在书桌上睡着了，呼吸平稳，睡得很沉。我们尽量别吵醒她。"
  };
  /* ---------- v0.1.44 默认"靠近悉尼"（跟随房间行 → 通用 passage；事件版替换默认行） ---------- */
  SP.chatIcon = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAMAAAAM7l6QAAAC+lBMVEX////+///+//76/////v/+/v79/v3+/f79/f39/fz9/P38/f38/fz8/Pz8/Pv7/Pz7/Pv7+/v6+/r6+vr5+vn5+fn4+fj5+Pj4+Pj3+Pf39vb29vb39fX19fX19PTy8vHw8PDu7u3q6enp5+fk5OTg3d3g3dzf3dzd3t7e3d3d29rc29vY2NjU1tbU1dXT0M7Q0dDQ0NDNzMvJycnLyMjHyMfGxsXExMTExMPCw8LCwsLyp6fBwMC/v7++wcC+v768vLy6srKtra2xqKeoqKidoqKdnp3zmJeZmZiYmJeXiIaUlZORkZGMkZCLi4uHh4eHh4bxamqBgIB+fn19fHz3Pj6LRkR3ZGNwe3t0dHRwcG9vb29sbGtra2tra2prampqampqaWlqU1P9NDPtOTntMjL8Ly/4Ly/5Li71KivyKyvwKiruKirtKiroLS7rKivrKirpKivmKivrKSrpKSnJKip2OjpzMzJrNDRmbm5pamlpaWlpaWhlaWlpaGhpaGdoaGhoaGdnZmZmZGRkZGRYZGRWXV1VXFxQV1ZQUFBQUE5JUFA/Tk5GTU1ISEg2RkZERUI5ODkvLy8vLy4uLi4tLC3vJCXhKCnnHyHpGxzgJibUJybTJibSJyfQJiXOJCTRIiO2JiatKCerISGiJSWWJieVJSSdISGVHR2UICCUIB+LHB2IHR2GHR1+GhpnIyI5Ghk2HRw4FhYyFBMuCwopKCgcHRsbGxoZGRgrBwcqBQUYGhgXFhUWFhUWFRQVFRUVFRQVFBQVFBMVExMYCAcTISAQHR0TGhkNGhoNFxYUFBMTFBITExIQEA8PEA8PEA4ODw4ODw0PDg4ODg0ODgwNDg0NDgwNDQ0NDQwNDQsNDAwNDAsKFBMHEhEMDQwMDAwMDAsLDAsLCwsLCwoKCwoKCwgLCgoLCgkKCgoKCgkKCggICggJCQkICQgICAcHCAcHBwYGBwYGBgYIBAQFBQUEBQQDAwMDAwIDAgIBAQEADg0ABQQAAAAAAAAfcIA1AAAA/nRSTlP/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////ANjZDHEAAAIySURBVHjaY/iLFzAQIf30+oP79+/duHHj+vWr129cAzJu3b/+Gi7dFd9YXVNTV1MDJIFEdXViYl1sJ0z6nTEDFmD8CSz9rs9JhVeQl5dXUBgIQCSIIySg4jLhCVD6RhRILSMTL1gPB5RgZGVgiL4BlH5cxyvIyMrKxeDa297RxmDX2+3LwMLEyirM33QTKP0ogUGAlZVVTjd814bNm/S9dm5J0pMHCggyNF4DSr+MYxVg5WVQP7Esbea0vOPr09IX3TUB6hBkqAMZ/jyelY+Vg0Ht2Mpk68AZSxfmZi66Y8LAC5K+DTI8noGPiYNB9eiqUGb3melZRdlLTkKkGx4ApR/EMfACpbV+rUhLSS0pKiyYs/a3GQM/SDdcmp1BuTJs8YJZ+cXT564uq9Vm4IZJ34hn4GdiZORmiPi8aG5O7uyFR1oZmJhALq95BJEWAEqzCWs6blw3b/6azc46ImwQ6WcwaSDgYJDpqVi+vLxfiYGHFezvOpD0xQSgv1mB8jwSDP5//kQyiIFlWQVZ61+CdMcwcDGxAo1n4mQ18vQwY2IDy7LyslY9Bko/bJaW4uXn5+dlZ2ABxYeAIARIS7e8AMf3ZENYHHMIIOLbYBI0ObzxMbe1tLDXYGDjlDS1sQIDe3Oft7DEdHbPwX07foQwiLMyTL209/ChU4dOndpzBTWlvgxiZXVIxJmQ9weIKgT/wSH9eIoig+zE3biywbmt3m5+Z3DmkrPbX718R14mwi0NAK2H5T9i3GkPAAAAAElFTkSuQmCC";
  SP.approachIntros = {
    living: [
      "你走进客厅，悉尼认出是你，眼睛顿时亮了起来。她放下书迎上来，一边说着一边吻了吻你的脸颊：\"回来啦，亲爱的？\"",
      "你在沙发边站定，悉尼拍了拍身边的位置，冲你弯了弯眼睛：\"过来坐。我总能为你腾出时间。\"",
      "你挨着悉尼坐下，她放下书，握住了你的手，指尖轻轻蹭了蹭你的掌心：\"今天怎么这么晚回来？\"",
      "你进门时悉尼正捧着书出神。她回过神，认出是你，放下书抱住你，把脸埋在你肩上，声音闷闷的：\"你回来了。\""
    ],
    kitchen: [
      "你走进厨房，悉尼转过头，认出是你，眼睛顿时亮了起来：\"回来啦，亲爱的？汤快好了，先洗手等着。\"",
      "你走近灶台，悉尼舀起一勺，吹了吹，递到你嘴边：\"尝尝咸淡？\"你尝了一口，她仰头看着你，等你说话。",
      "悉尼正忙着，见你探进半个身子，她腾出一只手，把你往身边带了带：\"过来，别站门口。\"她把火调小了些，\"今晚想吃什么？加你一个。\"",
      "悉尼擦干手转过身来，先抱住你，才松开：\"饿不饿？先给你盛一碗垫垫。\""
    ],
    study: [
      "你走进书房，悉尼认出是你，眼睛顿时亮了起来。她搁下笔，往旁边让了让，拍了拍身边的椅子：\"来，陪我写完这页。\"",
      "你挨着她坐下，悉尼把写了半页的纸往你这边推了推：\"帮我看看这个字，写得好不好？\"她问完，声音比平时轻快了些，又往你这边靠了靠。",
      "你轻轻推门进来，悉尼回过神来，看见是你，她放下笔，握了握你的手，轻轻捏了捏：\"你来得正好，我刚好写完。\"她把笔帽合上，\"陪我坐一会儿？\"",
      "悉尼正默祷，听见你的脚步，她睁开一只眼，认出是你，压低声音：\"过来。\"你坐过去，她靠着你，声音软下来，\"再等我一下，就快好了。\""
    ],
    garden: [
      "你走到小院，悉尼认出是你，弯起眼睛：\"来了，亲爱的？\"她把倒扣的杯子翻过来，倒了半杯茶推到你面前，\"茶还热着。\"",
      "悉尼蹲在花圃边，见你走近，她直起身，拍了拍手上的土，摘了一朵小雏菊，别到你耳边。她耳根有些红，却没躲开你的目光：\"好看吗？\"",
      "你挨着她在廊下坐下，悉尼往你那边靠了靠，把那碟剥好的豆子放在两人中间，自己拈了一颗，又拈起一颗递到你嘴边：\"尝尝，刚剥的。\"",
      "悉尼正望着远处出神，你走近她才发觉。她回头看见是你，拍了拍身边的位置。等你坐下，她靠过来，把脑袋搁在你肩上：\"你来了。\""
    ]
  };
  /* 文本镜像（v0.1.44 数值宏版后：正文以 sydneyPack.twee 的 SH Sydney Chat/Flirt 为准，此池保留供回归/测试参考，不再驱动渲染） */
  SP.chatTopics = [
    ["她给你一个灿烂的微笑：\"很多人仰慕着你，尤其是神殿的大家。他们把你视作希望与圣洁的象征，一个特别的存在。\"她的脸红了，\"包，包括我在内。\""],
    ["她微笑着看向你：\"不要停止前进的步伐。我知道你会是纯洁的。\""],
    ["你问她今天都做了什么。她一样样数给你听——抄了半页经文、给窗台的花浇了水、还试着做了道新菜。\"你呢？\"她说完，往你这边靠了靠，等你讲。"],
    ["你提起晚饭，问她有没有想吃的。她眼睛亮了亮：\"你做的话，什么都行。\"她低头翻着菜谱，又小声补了一句，\"上次那道番茄炖牛腩，我想再吃一回。\""],
    ["你问她最近在看什么书。她翻开膝头那本，念给你听：\"爱是恒久忍耐，又有恩慈。\"念完她先红了脸，把书页往你面前递了递，\"你看字，别看我了。\""],
    ["你问她想不想回家看看。她安静了一会儿，点了点头：\"周末我想去看看西里斯。你要一起来吗？\"她问完，抬眼看你，又很快移开。"],
    ["你问她小家伙今天乖不乖。她弯起眼睛：\"白天闹了一会儿，现在睡得可香了。你要去看看吗？\""]
  ];
  /* 调情文本镜像：7 case 正文已迁 Twee（SH Sydney Flirt），JS 池仅回归参考 */
  SP.flirtBank = [
    { label: "夸脸红", paras: ["你说她脸红的时候真是太可爱了。", "\"还，还不是你的错！就知道逗我……\"她捧住脸，咯咯直笑，\"这不公平……\""], chips: [{ t: "创伤 -1", c: "red" }] },
    { label: "荤笑话", paras: ["你给她讲了一个黄段子。", "（纯线恋爱）她的脸红了。"], chips: [{ t: "性奋 +1", c: "green" }] },
    { label: "擦唇", paras: ["她嘴角好像沾了东西。你抬手，假装替她擦掉，指尖在她唇上多停了一瞬。", "她利用这个机会在你的抚摸下放松起来。你嗯了一声作为回应，你们俩互相靠近了对方。你抱着她的肩膀，深深地亲吻她。"], chips: [{ t: "初吻", c: "gold" }, { t: "爱意 +1", c: "green" }, { t: "性奋 +1", c: "green" }] }
  ];
  SP.approachRoomMap = { "SH House Living Room": "living", "SH House Study": "study", "SH House Garden": "garden", "SH House Kitchen": "kitchen" };
  SP._pick = function (arr) { if (!arr || !arr.length) return null; return arr[Math.floor(Math.random() * arr.length)]; };
  SP._fillSlot = function (id, paras) {
    try {
      var el = document.getElementById(id);
      if (!el) return false;
      while (el.firstChild) el.removeChild(el.firstChild);
      for (var i = 0; i < paras.length; i++) {
        if (i > 0) el.appendChild(document.createElement("br")), el.appendChild(document.createElement("br"));
        var tn = document.createElement("span");
        tn.textContent = paras[i];
        el.appendChild(tn);
      }
      el.style.display = "";
      return true;
    } catch (e) { return false; }
  };
  SP.roomLabel = { living: "客厅", kitchen: "厨房", study: "书房", garden: "小院" };
  SP._chipSpan = function (chip) {
    var sp = document.createElement("span");
    try { sp.className = chip.c || ""; sp.textContent = chip.t; } catch (e) { /* ignore */ }
    return sp;
  };
  SP._appendChips = function (container, chips) {
    try {
      if (!container || !chips || !chips.length) return;
      container.appendChild(document.createTextNode(" | "));
      for (var i = 0; i < chips.length; i++) {
        if (i > 0) container.appendChild(document.createTextNode(" | "));
        container.appendChild(SP._chipSpan(chips[i]));
      }
    } catch (e) { /* ignore */ }
  };
  SP._fillExits = function (id) {
    try {
      var el = document.getElementById(id);
      if (!el) return;
      while (el.firstChild) el.removeChild(el.firstChild);
      var a = document.createElement("a");
      a.className = "link-internal";
      a.style.cursor = "pointer";
      a.setAttribute("data-passage", "SH Sydney Approach");
      a.appendChild(document.createTextNode("继续"));
      a.addEventListener("click", function (ev) {
        try { if (ev.preventDefault) ev.preventDefault(); if (ev.stopPropagation) ev.stopPropagation(); } catch (e) { /* ignore */ }
        try { if (typeof Engine !== "undefined" && Engine.play) Engine.play("SH Sydney Approach"); } catch (e2) { /* ignore */ }
      });
      el.appendChild(a);
      el.appendChild(document.createElement("br"));
      el.style.display = "";
    } catch (e) { /* ignore */ }
  };
  SP._rowIcon = function (a, src) {
    try {
      var im = document.createElement("img");
      im.className = "icon";
      im.src = src;
      a.insertBefore(im, a.firstChild);
    } catch (e) { /* ignore */ }
    return a;
  };
  SP._mkRowAnchor = function (label, src, pre) {
    try {
      var a = document.createElement("a");
      a.className = "link-internal";
      a.style.cursor = "pointer";
      a.addEventListener("click", function (ev) {
        try { if (ev.preventDefault) ev.preventDefault(); if (ev.stopPropagation) ev.stopPropagation(); } catch (e) { /* ignore */ }
        try { if (pre) pre(); } catch (e) { /* ignore */ }
        if (typeof Engine !== "undefined" && Engine.play) Engine.play(State.variables.SF.sydneypack._nav || "SH Sydney Approach");
      });
      return a;
    } catch (e) { return null; }
  };
  /* 行：进入通用 passage 前记录来源房/回退点 */
  SP._goApproach = function (room, from) {
    return function () {
      try {
        var p = SP.ensure(State.variables);
        p.approachRoom = room;
        p.approachFrom = from;
        p.approachLock = true;   /* 陪伴期冻结：离开/洗澡事件前她留在原房 */
        p._nav = "SH Sydney Approach";
      } catch (e) { /* ignore */ }
    };
  };
  SP._go = function (passage) {
    return function () {
      try { if (typeof Engine !== "undefined" && Engine.play) Engine.play(passage); } catch (e) { /* ignore */ }
    };
  };
  /* 默认"靠近悉尼"行（跟随房间）：事件版（客厅晚间 Love Night）优先，无事件时兜底 */
  SP.addDefaultApproachRow = function (room, linksId) {
    try {
      if (typeof State === "undefined" || typeof document === "undefined") return;
      var V = State.variables;
      var T = (typeof Time !== "undefined") ? Time : null;
      var lel = document.getElementById(linksId);
      if (!lel) return;
      var hs = SP.homeStateFor(V, T);
      if (!hs || hs.zone !== room) return;
      if (/睡着/.test(hs.actionZh || "") || hs.actionZh === "已经睡下") return;
      if (room === "kitchen" && SP.breakfastActive(V, T)) return;   /* 早餐事件占位 */
      var evRow = (room === "living") && (SP.homeBlock(T) === "evening" || SP.homeBlock(T) === "evening2");
      if (evRow) return;   /* 客厅晚间 = 事件版（原 Love Night 链），默认行让位 */
      var a = makeGo("SH Sydney Approach", SP._goApproach(room, State.passage));
      a.textContent = "靠近悉尼";
      SP._rowIcon(a, SP.chatIcon);
      while (lel.firstChild) lel.removeChild(lel.firstChild);
      lel.appendChild(a);
      lel.appendChild(document.createElement("br"));
      lel.appendChild(document.createElement("br"));
      lel.style.display = "";
    } catch (e) { /* ignore */ }
  };
  /* 通用 passage 渲染：进入文本（随机池） + 菜单 */
  /* 一起出门时间分流（复用原版机制）：
     每天一次（$daily.sydney.walk 由原版 Sydney Walk 置位）；
     8-18 点 → 白嫖原版 Sydney Walk；7-8 太早；18-23 太晚；23-6 进不来菜单不管 */
  SP.goOutTarget = function (v, t) {
    try {
      var V = v || ((typeof State !== "undefined" && State.variables) ? State.variables : null);
      var T = t || ((typeof Time !== "undefined") ? Time : null);
      if (!V || !T) return "SH Sydney Placeholder";
      var walked = !!(V.daily && V.daily.sydney && V.daily.sydney.walk);
      if (walked) return "SH Sydney Out Already";
      var h = Number(T.hour);
      if (h >= 8 && h < 18) return "SH Sydney Home Walk";   /* 家版目的地列表（原版 Walk 只认 school/temple 出发） */
      if (h >= 7 && h < 8) return "SH Sydney Out Too Early";
      if (h >= 18 && h < 23) return "SH Sydney Out Too Late";
      return "SH Sydney Placeholder";
    } catch (e) { return "SH Sydney Placeholder"; }
  };
  /* 原版同款门禁：当天已出过门（$daily.sydney.walk）→ 靠近菜单不再显示「一起出门」行 */
  SP.canGoOutAsk = function (v) {
    try {
      var V = v || ((typeof State !== "undefined" && State.variables) ? State.variables : null);
      if (!V) return false;
      return !(V.daily && V.daily.sydney && V.daily.sydney.walk);
    } catch (e) { return false; }
  };
  SP.renderApproach = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH Sydney Approach") return;
      var V = State.variables;
      var p = SP.ensure(V);
      /* 22:00-22:30 洗澡监听：陪伴期时间推进到 bath 块 → 触发"去洗澡"事件，菜单不再续（A 方案的收尾） */
      var T = (typeof Time !== "undefined") ? Time : null;
      if (T && p.approachLock && SP.homeBlock(T) === "bath") {
        var d = Number(T.days);
        if (p.eveningBathDay !== d) {
          p.eveningBathDay = d;
          setTimeout(function () { try { SP._playPassage("SH Sydney Evening Bath"); } catch (e) { /* ignore */ } }, 0);
        }
        return;
      }
      var room = p.approachRoom || "living";
      var pool = SP.approachIntros[room] || SP.approachIntros.living;
      var el = document.getElementById("sf-approach-intro");
      if (el) {
        while (el.firstChild) el.removeChild(el.firstChild);
        var span = document.createElement("span");
        span.textContent = SP._pick(pool);
        el.appendChild(span);
        el.style.display = "";
      }
      /* 动态插槽（行内 span）：夹在 调情 与 离开 之间，JS 只放链接本身；
         前后各一个 <br><br> 由 twee 静态给出，保证每类之间正好空一行、类内不空行 */
      var dy = document.getElementById("sf-approach-dynamic");
      if (dy) {
        while (dy.firstChild) dy.removeChild(dy.firstChild);
        var special = { living: "靠着她歇一会儿", kitchen: "搭把手", study: "看她写字", garden: "一起看花" };
        var lbl = special[room];
        if (lbl) {
          var a = SP._menuAnchor(lbl, SP.chatIcon, "SH Sydney Placeholder", (function (l) { return function () { try { SP.ensure(State.variables).placeholderLabel = l; Engine.play("SH Sydney Placeholder"); } catch (e) { /* ignore */ } }; })(lbl));
          if (a) dy.appendChild(a);
          dy.style.display = "";
        } else {
          dy.style.display = "none";
        }
      }
    } catch (e) { /* ignore */ }
  };
  SP._menuAnchor = function (label, src, target, fn) {
    try {
      var a = document.createElement("a");
      a.className = "link-internal";
      a.style.cursor = "pointer";
      a.setAttribute("data-passage", target);
      if (src) {
        var im = document.createElement("img");
        im.className = "icon";
        im.src = src;
        a.appendChild(im);
      }
      a.appendChild(document.createTextNode(label));
      a.addEventListener("click", function (ev) {
        try { if (ev.preventDefault) ev.preventDefault(); if (ev.stopPropagation) ev.stopPropagation(); } catch (e) { /* ignore */ }
        try { if (fn) fn(); } catch (e) { /* ignore */ }
      });
      return a;
    } catch (e) { return null; }
  };
  SP._renderBody = function (containerId, paras, chips) {
    try {
      var el = document.getElementById(containerId);
      if (!el) return false;
      while (el.firstChild) el.removeChild(el.firstChild);
      var last = null;
      for (var i = 0; i < paras.length; i++) {
        if (i > 0) { el.appendChild(document.createElement("br")); el.appendChild(document.createElement("br")); }
        var sp = document.createElement("span");
        sp.textContent = paras[i];
        el.appendChild(sp);
        last = sp;
      }
      if (last && chips && chips.length) SP._appendChips(last, chips);
      el.style.display = "";
      return true;
    } catch (e) { return false; }
  };
  SP.renderChat = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH Sydney Chat") return;
      var topic = SP._pick(SP.chatTopics) || [""];
      var chips = [{ t: "爱意 +1", c: "green" }, { t: "压力 -3", c: "red" }];
      try {
        if (typeof C !== "undefined" && C.npc && C.npc.Sydney && Number(C.npc.Sydney.love) >= 20) {
          chips.push({ t: "创伤 -3", c: "red" });
        }
      } catch (e) { /* ignore */ }
      SP._renderBody("sf-chat", topic, chips);
    } catch (e) { /* ignore */ }
  };
  SP.renderFlirt = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH Sydney Flirt") return;
      var c = SP._pick(SP.flirtBank);
      if (!c) return;
      SP._renderBody("sf-flirt", c.paras, c.chips || []);
    } catch (e) { /* ignore */ }
  };
  SP.renderPlaceholder = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH Sydney Placeholder") return;
      var p = SP.ensure(State.variables);
      var lbl = p.placeholderLabel || "这个选项";
      SP._renderBody("sf-placeholder", [lbl + "还没做完，先占个位。"], null);
    } catch (e) { /* ignore */ }
  };
  /* 引擎跳转：本 fork 裸 Engine 与 SugarCube.Engine 都试一遍 */
  SP._playPassage = function (name) {
    try { if (typeof Engine !== "undefined" && Engine && Engine.play) { Engine.play(name); return true; } } catch (e) { /* ignore */ }
    try { if (typeof SugarCube !== "undefined" && SugarCube.Engine && SugarCube.Engine.play) { SugarCube.Engine.play(name); return true; } } catch (e) { /* ignore */ }
    try { if (typeof window !== "undefined" && window.SugarCube && window.SugarCube.Engine && window.SugarCube.Engine.play) { window.SugarCube.Engine.play(name); return true; } } catch (e) { /* ignore */ }
    return false;
  };
  /* 兜底：自动跳转连续失败时给出可见“返回房间”链接，绝不卡死 */
  SP._showLeaveFallback = function (go) {
    try {
      if (typeof document === "undefined") return;
      var el = document.getElementById("sf-leave-fallback");
      if (!el) return;
      while (el.firstChild) el.removeChild(el.firstChild);
      var roomBack = {
        "SH House Living Room": "返回客厅", "SH House Kitchen": "返回厨房",
        "SH House Study": "返回书房", "SH House Garden": "返回小院", "SH House Entrance": "返回门厅"
      };
      var label = roomBack[go] || "返回房间";
      var a = SP._menuAnchor(label, null, go, (function (g) { return function () { try { SP._playPassage(g); } catch (e) { /* ignore */ } }; })(go));
      if (a) { el.appendChild(a); el.style.display = ""; }
    } catch (e) { /* ignore */ }
  };
  /* 洗澡/离开等收尾事件：解除陪伴期冻结 */
  SP.endApproach = function (v) {
    try {
      var p = SP.ensure(v);
      if (p) {
        p.approachLock = false;
        p.homeCarryDay = null;   /* 洗澡等自然收尾事件：直接按事件后的时间走，不需要 carry */
        p.homeCarryUntil = null;
      }
    } catch (e) { /* ignore */ }
  };
  /* 静态“离开”→ 中转页：每次进入都自动回原房（pending 跳完复位，可反复使用） */
  SP.renderApproachLeave = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH Sydney Approach Leave") return;
      var p = SP.ensure(State.variables);
      var roomPass = { living: "SH House Living Room", kitchen: "SH House Kitchen", study: "SH House Study", garden: "SH House Garden" };
      var go = p.approachFrom || roomPass[p.approachRoom] || "SH House Entrance";
      /* 离开菜单 → 解锁，但不"补跳"：她留在原房，直到下一个换房边界才按新时间重算 */
      p.approachLock = false;
      var TT = (typeof Time !== "undefined") ? Time : null;
      var nb = TT ? SP.nextHomeBoundary(State.variables, TT) : null;
      if (nb !== null && nb !== undefined) { p.homeCarryDay = Number(TT.days); p.homeCarryUntil = nb; }
      else { p.homeCarryDay = null; p.homeCarryUntil = null; }
      if (SP._leavePending) return; /* 同一次显示只排一次跳转 */
      SP._leavePending = true;
      var tries = 0;
      var attempt = function () {
        tries++;
        var ok = false;
        try { ok = SP._playPassage(go); } catch (e) { ok = false; }
        if (ok) { SP._leavePending = false; return; }
        if (tries < 2) { setTimeout(attempt, 80); return; }
        SP._leavePending = false;
        SP._showLeaveFallback(go);
      };
      setTimeout(attempt, 0);
    } catch (e) { /* ignore */ }
  };


  function homeRows(V, T) {
    var p = SP.ensure(V);
    if (!p.resident) return;
    var hs = SP.homeStateFor(V, T);
    if (!hs) return;
    var map = { "SH House Living Room": "living", "SH House Study": "study", "SH House Garden": "garden", "SH House Kitchen": "kitchen" };
    var room = map[State.passage];
    if (!room || hs.zone !== room) return;
    if (hs.actionZh === "已经睡下") return;
    function hb() { return document.createElement("br"); }
    var sleeping = /睡着/.test(hs.actionZh);
    var textId = room === "living" ? "sf-text-living" : "sf-text-" + room;
    var linksId = room === "living" ? "sf-links-living" : "sf-links-" + room;
    var tel = document.getElementById(textId);
    if (tel) {
      var span = document.createElement("span");
      span.className = "gold";
      var line;
      if (room === "living" && hs.actionZh.indexOf("看书") >= 0) line = HOME_TEXT.livingRead;
      else if (sleeping && room === "study") line = HOME_TEXT.deskSleep;
      else if (sleeping && room === "living") line = HOME_TEXT.sofaSleep;
      else line = "悉尼" + hs.actionZh + "。";
      span.textContent = line;
      /* 原版分行：通用房间黄字行尾补空行（小院槽段落自带空行，不重复补） */
      var tail = (room === "garden") ? [] : [hb(), hb()];
      clearAppend(tel, [span].concat(tail));
    }
    /* 事件版（客厅晚间 20-22 Love Night 链）优先；否则默认"靠近悉尼"（v0.1.44 跟随房间兜底） */
    var lel = document.getElementById(linksId);
    var evRow = !sleeping && room === "living" && (SP.homeBlock(T) === "evening" || SP.homeBlock(T) === "evening2");
    if (lel) {
      if (evRow) {
        var go = makeGo("SH Sydney Living Night", function () { SP.ensure(V).mood = SP.rollMood(V, T); });
        go.textContent = "靠近悉尼";
        SP._rowIcon(go, "img/misc/icon/actions/hug.png");
        clearAppend(lel, [go, hb(), hb()]);
      } else {
        SP.addDefaultApproachRow(room, linksId);
      }
    }
  }
  function herRoomRows(V, T) {
    var p = SP.ensure(V);
    if (!p.resident) return;
    if (State.passage !== "SH House Bedroom") return;
    var c = document.getElementById("sf-slot-bedroom");
    if (!c) return;
    var go = makeGo("SH Sydney Room Door", null);
    go.textContent = "悉尼的房间";
    SP.iconify(go);
    /* 原版分行：家人槽组尾补空行；槽前空行由 .twee 提供；后续 NPC 行在此组内单 <br> 追加 */
    function hb() { return document.createElement("br"); }
    clearAppend(c, [go, hb(), hb()]);
  }
  /* ---------- 6/7：临盆入口 / 消失线门厅红字 / 育儿室槽位（机制层；段落见 sydneyPack.twee） ---------- */
  function mkNavLink(passage, label) {
    try {
      var a = document.createElement("a");
      a.className = "link-internal";
      a.style.cursor = "pointer";
      a.addEventListener("click", function (ev) {
        try { if (ev.preventDefault) ev.preventDefault(); if (ev.stopPropagation) ev.stopPropagation(); } catch (e) { /* ignore */ }
        if (typeof Engine !== "undefined" && Engine.play) Engine.play(passage);
      });
      a.appendChild(document.createTextNode(label));
      return a;
    } catch (e) { return null; }
  }
  /* 临盆入口：在家场景且 labour 中、未接产 → 按缺席分档路由到产程/缺席段落 */
  SP.renderLabour = function () {
    try {
      if (typeof State === "undefined" || !State.variables) return;
      var V = State.variables;
      var T = (typeof Time !== "undefined") ? Time : null;
      if (!T) return;
      var homePass = { "SH House Entrance": 1, "SH House Bedroom": 1, "SH House Bed": 1, "SH Sydney Room Door": 1, "SH House Nursery": 1 };
      if (!homePass[State.passage]) return;
      var st = SP.ensurePregStory(V);
      if (!st || st.stage !== "labour" || SP.isGone(V)) return;
      if (!SP.pregStatus(V).labour) return;
      var p = SP.ensure(V);
      if (!p || !p.resident) return;
      var tier = SP.absenceTier(V, T);
      if (!tier || tier === "gone") return;
      /* 当天临盆也自动进入（白天/夜晚/睡觉页都不用手点） */
      var key = State.passage + "|" + Number(T.days) + "|" + tier;
      if (SP._labourNav === key) return;
      SP._labourNav = key;
      var target = tier === "same" ? "SH Sydney Preg Labour"
        : tier === "miss" ? "SH Sydney Preg Missed"
        : tier === "f1" ? "SH Sydney Preg Forgotten1"
        : tier === "f2" ? "SH Sydney Preg Forgotten2"
        : "SH Sydney Preg Forgotten3";
      (function (tgt) {
        setTimeout(function () {
          try { if (typeof Engine !== "undefined" && Engine.play) Engine.play(tgt); } catch (e) { /* ignore */ }
        }, 0);
      })(target);
    } catch (e) { /* ignore */ }
  };
  /* 门厅顶部提示锚点（#sf-house-presence 之后 = 房间列表上方；回退到家人槽） */
  SP.hallHintAnchor = function () {
    try {
      if (typeof document === "undefined") return null;
      return document.getElementById("sf-house-presence") || document.getElementById("sf-slot-entrance");
    } catch (e) { return null; }
  };
  /* 家里是否有育儿室（SF 房态） */
  SP.hasNursery = function (v) {
    try {
      if (typeof SF === "undefined" || !SF.logic || !SF.logic.hasNursery) return false;
      if (!v || !v.SF) return false;
      return !!SF.logic.hasNursery(v, Number(v.SF.homeTier) || 1);
    } catch (e) { return false; }
  };
  /* 无育儿室兜底：孩子出生后放在悉尼房间的摇篮（房间内先只给黄字提示） */
  SP.babyInSydneyRoom = function (v) {
    try {
      var st = SP.ensurePregStory(v);
      if (!st || st.stage !== "raising") return false;
      if (SP.isGone(v)) return false;
      if (SP.hasNursery(v)) return false;
      if (!st.childId || !v || !v.children || !v.children[st.childId]) return false;
      if (v.children[st.childId].takenBySydney) return false;
      return true;
    } catch (e) { return false; }
  };
  /* 在锚点后插入一行（锚点后追加，保持换行） */
  SP.hallHintLine = function (anchor, nodes) {
    try {
      if (!anchor || !anchor.parentNode) return;
      var par = anchor.parentNode;
      var ref = anchor.nextSibling;
      for (var i = 0; i < nodes.length; i++) par.insertBefore(nodes[i], ref);
    } catch (e) { /* ignore */ }
  };
  /* 记录"她临盆期间玩家是否在外面"（逾期档前置条件；在家睡过头不算缺席） */
  SP.trackLabourAway = function () {
    try {
      if (typeof State === "undefined" || !State.variables) return;
      var V = State.variables;
      var st = SP.ensurePregStory(V);
      if (!st || st.stage !== "labour" || SP.isGone(V)) return;
      var T = (typeof Time !== "undefined") ? Time : null;
      if (!T) return;
      if (V.location !== "home") st.awayDay = Number(T.days);
    } catch (e) { /* ignore */ }
  };
  /* 夜晚窗口（21:00-5:59）：她叫醒你/自动触发；白天只给提示行 */
  SP.isLabourNight = function (t) {
    try { if (!t) return false; var h = Number(t.hour); return h >= 21 || h < 6; } catch (e) { return false; }
  };

  /* 卧室设置：产后推进开关（默认 8 小时；开启=跳过 7 天） */
  SP.renderSettingsRow = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH House Settings") return;
      if (document.getElementById("sf-postpartum-skip-row")) return;
      var V = State.variables;
      var p = SP.ensure(V);
      var ref = document.querySelector("#passages a[data-passage=\"SH House Bedroom\"]");
      if (!ref) return;
      var p0 = SP.ensure(V);
      var row0 = document.createElement("div");
      row0.id = "sf-testmode-row";
      var lab0 = document.createElement("span");
      lab0.className = "gold";
      lab0.textContent = "测试模式：";
      var tgl0 = document.createElement("a");
      tgl0.className = "link-internal";
      tgl0.style.cursor = "pointer";
      tgl0.textContent = p0 && p0.testMode ? "[开]" : "[关（默认）]";
      tgl0.addEventListener("click", function () {
        try {
          var pp = SP.ensure(State.variables);
          pp.testMode = !pp.testMode;
          if (typeof Engine !== "undefined" && Engine.play) Engine.play("SH House Settings");
        } catch (e) { /* ignore */ }
      });
      row0.appendChild(lab0);
      row0.appendChild(document.createTextNode(" "));
      row0.appendChild(tgl0);
      row0.appendChild(document.createElement("br"));
      ref.parentNode.insertBefore(row0, ref);
      var wrap = document.createElement("div");
      wrap.id = "sf-postpartum-skip-row";
      var lab = document.createElement("span");
      lab.className = "gold";
      lab.textContent = "产后休息：";
      var tgl = document.createElement("a");
      tgl.className = "link-internal";
      tgl.style.cursor = "pointer";
      tgl.textContent = p && p.postpartumSkip7 ? "[跳过 7 天：开]" : "[跳过 7 天：关（默认：事件推进 8 小时）]";
      tgl.addEventListener("click", function () {
        try {
          var p2 = SP.ensure(State.variables);
          p2.postpartumSkip7 = !p2.postpartumSkip7;
          if (typeof Engine !== "undefined" && Engine.play) Engine.play("SH House Settings");
        } catch (e) { /* ignore */ }
      });
      wrap.appendChild(lab);
      wrap.appendChild(document.createTextNode(" "));
      wrap.appendChild(tgl);
      wrap.appendChild(document.createElement("br"));
      ref.parentNode.insertBefore(wrap, ref);
    } catch (e) { /* ignore */ }
  };
  /* 临产预兆（未破水、progress >= 85%）：门厅黄字提示，另起一行放提示下方 */
  SP.renderDueSoonHint = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH House Entrance") return;
      var V = State.variables;
      var st = SP.ensurePregStory(V);
      if (!st || SP.isGone(V)) return;
      if (st.stage === "labour" || st.stage === "raising") return;
      if (!SP.isResident(V)) return;
      var stt = SP.pregStatus(V);
      if (!stt || !stt.pregnant || stt.labour) return;
      if (stt.progress < 0.85) return;
      var c = SP.hallHintAnchor();
      if (!c) return;
      var s = document.createElement("span");
      s.className = "gold";
      s.textContent = "她快到预产期了，最近总轻轻揉着肚子……";
      var br1 = document.createElement("br");
      SP.hallHintLine(c, [s, br1]);
      if (!SP.hasNursery(V)) {
        var s2 = document.createElement("span");
        s2.className = "gold";
        s2.textContent = "家里还没有育儿室……要不要把空房改成育儿室？";
        var br2 = document.createElement("br");
        SP.hallHintLine(c, [s2, br2]);
      }
    } catch (e) { /* ignore */ }
  };
  /* 消失线：门厅提示区红字「悉尼走了。」+ 信入口（正常家人行由 isResident=false 自动消失） */
  SP.renderGoneHall = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH House Entrance") return;
      if (!SP.isGone(State.variables)) return;
      var c = SP.hallHintAnchor();
      if (!c) return;
      var s = document.createElement("span");
      s.className = "red";
      s.textContent = "悉尼走了。";
      var brA = document.createElement("br");
      SP.hallHintLine(c, [s, brA]);
    } catch (e) { /* ignore */ }
  };
  /* 取名输入框（DOM 注入，手机友好）：SH Sydney Preg Birth Named */
  SP.renderNameBox = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH Sydney Preg Birth Named") return;
      var box = document.getElementById("sf-name-box");
      if (!box) return;
      if (box.hasChildNodes()) return;
      var inp = document.createElement("input");
      inp.type = "text";
      inp.maxLength = 20;
      inp.placeholder = "给宝宝取个名字…（默认：宝宝）";
      inp.style.width = "14em";
      var btn = document.createElement("a");
      btn.className = "link-internal";
      btn.style.cursor = "pointer";
      btn.textContent = "确定";
      btn.addEventListener("click", function () {
        try {
          var nm = (inp.value || "").trim();
          if (!nm) nm = "宝宝";
          SP.nameLastChild(State.variables, nm);
          if (typeof Engine !== "undefined" && Engine.play) Engine.play("SH Sydney Preg Birth Named Done");
        } catch (e) { /* ignore */ }
      });
      box.appendChild(inp);
      box.appendChild(document.createTextNode(" "));
      box.appendChild(btn);
      box.style.display = "";
    } catch (e) { /* ignore */ }
  };
  /* ---------- 育儿室 v0.1.43：孩子列表 + 单个孩子页 + 无育儿室门厅提示 ---------- */
  /* 代词：f/h→她，m→他（用户 2026-09-06 定） */
  SP.childPronoun = function (kid) {
    try { return kid && kid.gender === "m" ? "他" : "她"; } catch (e) { return "她"; }
  };
  /* 中文数字（一张/两张…；>10 回落阿拉伯数字） */
  SP.cnNum = function (n) {
    var d = ["零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十"];
    n = Number(n) || 0;
    return (n >= 0 && n <= 10) ? d[n] : String(n);
  };
  /* 住在自家（sh_home）的孩子 = 悉尼所生、未被带走、在育儿室/悉尼房间 */
  SP.homeKids = function (v) {
    var out = [];
    try {
      if (!v || !v.children) return out;
      Object.keys(v.children).forEach(function (k) {
        var c = v.children[k];
        if (!c) return;
        if (c.mother !== "Sydney") return;
        if (c.takenBySydney) return;
        if (c.location !== "sh_home") return;
        out.push(c);
      });
    } catch (e) { /* ignore */ }
    return out;
  };
  /* 育儿室描述：靠墙摆着 N 张婴儿床（0/1 张时保留 SF 原空房句，2+ 才换数词） */
  SP.nurseryDescText = function (n) {
    n = Number(n) || 0;
    var beds = (n === 1 || n === 0) ? "一" : n === 2 ? "两" : SP.cnNum(n);   /* 量词"张"在句内自带：一张/两张/三张… */
    return "房间不大，被收拾得干干净净。靠墙摆着" + beds + "张婴儿床，床围是浅色的；角落里的玩具箱还没拆封，空气里浮着一点木蜡的气味。这间屋子在等着谁住进来。";
  };
  /* 单孩子图标 = 复刻原版 <<childrenicon>> human 分支 DOM（红模板 + skin filter + 叠层） */
  SP.childIconDom = function (kid) {
    var wrap = document.createElement("span");
    try {
      if (!kid || typeof document === "undefined") return wrap;
      var f = kid.features || {};
      var base = "img/misc/icon/children/humans/";
      function im(src) {
        var i = document.createElement("img");
        i.className = "icon";
        i.src = base + src;
        return i;
      }
      wrap.className = "icon-container";
      if (f.skinColour && window.setup && setup.colours && setup.colours.getSkinCSSFilter) {
        var sk = document.createElement("span");
        sk.setAttribute("style", "filter: " + setup.colours.getSkinCSSFilter(f.skinColour));
        sk.appendChild(im("body.png"));
        wrap.appendChild(sk);
      } else {
        wrap.appendChild(im("body.png"));
      }
      if (f.divineTransform) wrap.appendChild(im("tf-" + f.divineTransform + ".png"));
      if (f.beastTransform) {
        var bs = document.createElement("span");
        bs.className = "hair-" + (f.hairColour || "");
        var bi = document.createElement("span");
        bi.className = "colour-hair";
        bi.appendChild(im("tf-" + f.beastTransform + ".png"));
        bs.appendChild(bi);
        wrap.appendChild(bs);
      }
      wrap.appendChild(im("diaper.png"));
      var hs = document.createElement("span");
      hs.className = "hair-" + (f.hairColour || "");
      var hi = document.createElement("span");
      hi.className = "colour-hair";
      hi.appendChild(im("hair.png"));
      hs.appendChild(hi);
      wrap.appendChild(hs);
      var eyeCls = f.eyeColour || "hazel";
      if (typeof State !== "undefined" && State.variables && State.variables.eyeselect) {
        eyeCls = String(eyeCls).replace("pc", State.variables.eyeselect);
      }
      eyeCls = String(eyeCls).replace(/ /g, "-");
      var es = document.createElement("span");
      es.className = "eye-" + eyeCls;
      es.appendChild(im("eyes.png"));
      wrap.appendChild(es);
    } catch (e) { /* ignore */ }
    return wrap;
  };
  /* 悉尼睡着判定：她房间睡下 / 睡在你床上 / 沙发睡着等（夜版育儿室守卫用） */
  SP._sydneyAsleep = function (v, t) {
    try {
      var hs = SP.homeStateFor(v, t);
      if (!hs) return false;
      if (hs.zone === "pcBed") return true;
      return /睡/.test(hs.actionZh || hs.action || "");
    } catch (e) { return false; }
  };
  /* 单个孩子页入口行（图标 + 名字），点击记录 nurseryChild 后进 SH Sydney Child Page；夜间守卫由调用方传 night */
  SP.nurseryKidRow = function (kid, night) {
    var a = document.createElement("a");
    try {
      a.className = "link-internal";
      a.style.cursor = "pointer";
      a.appendChild(SP.childIconDom(kid));
      a.appendChild(document.createTextNode(" " + (kid.name || "宝宝")));
      (function (cid, kd) {
        a.addEventListener("click", function (ev) {
          try {
            if (ev && ev.preventDefault) ev.preventDefault();
            if (ev && ev.stopPropagation) ev.stopPropagation();
            var p = SP.ensure((typeof State !== "undefined" && State.variables) ? State.variables : null);
            if (!p) return;
            if (night) {
              var who = SP.childPronoun(kd && kd.gender);
              p.nurseryGuardMsg = "悉尼已经把" + who + "哄睡着了，" + who + "现在睡得很香，为了小宝宝的成长，还是不要去打扰了。";
              if (typeof Engine !== "undefined" && Engine.play) Engine.play("SH House Nursery");
              return;
            }
            p.nurseryChild = cid;
            if (typeof Engine !== "undefined" && Engine.play) Engine.play("SH Sydney Child Page");
          } catch (e2) { /* ignore */ }
        });
      })(kid.childId, kid);
    } catch (e) { /* ignore */ }
    return a;
  };
  /* 无育儿室但已有孩子 → 门厅提示区自立一行黄字 */
  SP.renderNoNurseryHint = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH House Entrance") return;
      var V = State.variables;
      if (!SP.babyInSydneyRoom(V)) return;
      var c = SP.hallHintAnchor();
      if (!c) return;
      var s = document.createElement("span");
      s.className = "gold";
      s.textContent = "你的小孩现在暂时住在悉尼的房间里面，你应该尽快去中介处改造空房间为育儿室。";
      var brA = document.createElement("br");
      SP.hallHintLine(c, [s, brA]);
    } catch (e) { /* ignore */ }
  };
  /* 孩子页守卫：所选孩子已不存在/被带走 → 弹回育儿室（防旧链接死页） */
  SP.CHILD_PAGE_SET = ["SH Sydney Child Page", "SH Sydney Child Hold", "SH Sydney Child Feed", "SH Sydney Child Sleep", "SH Sydney Child Watch"];
  SP.guardChildPages = function () {
    try {
      if (typeof State === "undefined" || !State.variables) return;
      if (SP.CHILD_PAGE_SET.indexOf(State.passage) < 0) return;
      var V = State.variables;
      var p = SP.ensure(V);
      var cid = p && p.nurseryChild;
      var ok = cid && V.children && V.children[cid] && !V.children[cid].takenBySydney;
      if (ok) return;
      var key = "childguard|" + State.passage;
      if (SP._childGuard === key) return;
      SP._childGuard = key;
      setTimeout(function () {
        try { if (typeof Engine !== "undefined" && Engine.play) Engine.play("SH House Nursery"); } catch (e2) { /* ignore */ }
      }, 0);
    } catch (e) { /* ignore */ }
  };
  /* 育儿室槽位（v0.1.43）：描述动态化 + 小家伙(们)醒了 + 孩子列表行（图标+名字，点入单个孩子页）；消失线 → 空/纸条文本 */
  SP.renderNursery = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH House Nursery") return;
      var V = State.variables;
      var tc = document.getElementById("sf-text-nursery");
      var lc = document.getElementById("sf-links-nursery");
      var st = SP.ensurePregStory(V);
      if (!st) return;
      function clearHide(el) { if (el) { while (el.firstChild) el.removeChild(el.firstChild); el.style.display = "none"; } }
      if (SP.isGone(V)) {
        if (tc) {
          var t0 = document.createTextNode("育儿室里，摇篮还在，小毯子叠得整齐。孩子的东西被带走了一部分，剩下的小衣服她洗好叠好，放在柜子里。摇篮边压着一张小小的纸条，字迹有些抖：\u201c……她睡着的样子，很像你。\u201d");
          while (tc.firstChild) tc.removeChild(tc.firstChild);
          tc.appendChild(t0);
          tc.style.display = "";
        }
        clearHide(lc);
        return;
      }
      var kids = SP.homeKids(V);
      if (!kids.length) { clearHide(tc); clearHide(lc); return; }
      var T = (typeof Time !== "undefined") ? Time : null;
      var night = SP._sydneyAsleep(V, T);   /* 夜版：悉尼睡觉时（含睡她房间/睡你床上） */
      var p2 = SP.ensure(V);
      var guardMsg = (p2 && p2.nurseryGuardMsg) || null;
      if (p2) p2.nurseryGuardMsg = null;
      /* 描述动态化：把 SF 空房描述段落换成「N 张婴儿床」版 */
      try {
        var walker = document.createTreeWalker(document.getElementById("passages"), NodeFilter.SHOW_TEXT, null);
        var node;
        while ((node = walker.nextNode())) {
          if (node.nodeValue.indexOf("靠墙摆着一张婴儿床") >= 0) {
            node.nodeValue = SP.nurseryDescText(kids.length);
            break;
          }
        }
      } catch (e2) { /* ignore */ }
      if (tc) {
        var wake = night
          ? (kids.length > 1 ? "小家伙们已经睡觉了，都很乖，没有闹腾。" : "小家伙已经睡觉了，都很乖，没有闹腾。")
          : (kids.length > 1 ? "小家伙们醒了，正睁着圆溜溜的眼睛，好奇地看着你。" : "小家伙醒了，正睁着圆溜溜的眼睛，好奇地看着你。");
        while (tc.firstChild) tc.removeChild(tc.firstChild);
        tc.appendChild(document.createTextNode(wake));
        if (guardMsg) {
          var b1 = document.createElement("br"); var b2 = document.createElement("br");
          var gs = document.createElement("span");
          gs.className = "gold";
          gs.textContent = guardMsg;
          tc.appendChild(b1); tc.appendChild(b2); tc.appendChild(gs);
        }
        tc.style.display = "";
      }
      if (lc) {
        while (lc.firstChild) lc.removeChild(lc.firstChild);
        for (var i = 0; i < kids.length; i++) {
          lc.appendChild(SP.nurseryKidRow(kids[i], night));
          lc.appendChild(document.createElement("br"));
        }
        lc.style.display = "";
      }
    } catch (e) { /* ignore */ }
  };
  function renderMorning() {
    try {
      if (typeof State === "undefined" || !State.variables) return;
      var V = State.variables;
      var T = (typeof Time !== "undefined") ? Time : null;
      var br = function () { return document.createElement("br"); };
      if (State.passage === "SH House Entrance") {
        var c = document.getElementById("sf-slot-entrance");
        if (!c) return;
        var nodesE = [];
        if (SP.isResident(V) || SP.isGone(V)) {
          var dLink = makeGo("SH Sydney Room Door", null);
          dLink.textContent = "悉尼的房间";
          SP.iconify(dLink);
          nodesE.push(dLink, br()); /* 家人行；测试组开时测试行紧贴其下（单 <br>） */
        }
        /* 测试模式：卧室设置「测试模式」勾选后显示（默认隐藏） */
        var testOn = !!(SP.ensure(V).testMode);
        if (testOn) {
          var st = document.createElement("span");
          st.className = SP.isResident(V) ? "lblue" : "gold";
          st.textContent = "（测试）悉尼入住：" + (SP.isResident(V) ? "已入住" : "未入住");
          var b1 = makeGo(State.passage, function () { SP.testResident(V, !SP.isResident(V)); });
          b1.textContent = SP.isResident(V) ? "取消入住" : "设置入住（直置承诺）";
          var b2 = makeGo(State.passage, function () { SP.testJumpTo6(); });
          b2.textContent = "时间跳到早上 6 点";
          nodesE.push(st, br(), b1, br(), b2, br(), br()); /* 原版分行：slot 测试组作为独立组，组尾补空行（小院/出门前空一行） */
        } else if (nodesE.length) {
          nodesE.push(br()); /* 非测试模式：家人行是槽内唯一内容 → 组尾补空行，隔开下方空房/小院行 */
        }
        clearAppend(c, nodesE);
      } else if (State.passage === "SH House Kitchen") {
        if (SP.breakfastActive(V, T)) {
          var tc = document.getElementById("sf-text-kitchen");
          var lc = document.getElementById("sf-links-kitchen");
          if (tc) {
            var txt = document.createElement("span");
            if (SP.pregBreakfastActive(V)) {
              txt.innerHTML = "悉尼正系着围裙在灶台前慢慢忙活，听见动静回过头，先弯了弯眼睛：“<span class=\"green\">来啦？</span>”她低头看了眼锅里的火候，又补了一句：“<span class=\"green\">马上就好。你可不许偷偷吃凉的垫肚子，等会一起吃。</span>”";
            } else {
              txt.className = "gold";
              txt.textContent = "悉尼正在灶台前忙碌，听见动静回头冲你喊：“来啦？早饭等会就做好了。”";
            }
            /* 原版分行：厨房早餐黄字段尾补空行（选项组前空行） */
            clearAppend(tc, [txt, br(), br()]);
          }
          if (lc) {
            var t3 = Number(V.SF.homeTier) >= 3;
            var g1 = makeGo("SH Sydney Breakfast", function () { SP.ensure(V).bfDishKey = SP.pick(SP.d3Catalog()); });
            g1.textContent = t3 ? "在餐厅等待悉尼" : "在厨房的桌椅等待悉尼";
            var nodes = [g1, br()];
            if (SP.d3StockKeys(V).length > 0 && !(SP.isResident(V) && T && Number(T.weekDay) === 7)) {
              var g2 = makeGo("SH Sydney Eat Alone", null);
              g2.textContent = "不等悉尼了，自己吃";
              nodes.push(g2); nodes.push(br());
            }
            var g3 = makeGo("SH Sydney Refuse", null);
            g3.textContent = "告诉悉尼，我不吃";
            nodes.push(g3);
            /* 原版分行：早餐三选项组尾补空行（材料行前空行） */
            nodes.push(br(), br());
            clearAppend(lc, nodes);
          }
        }
      } else if (State.passage === "SH House Dining") {
        var p = SP.ensure(V);
        if (p.resident) {
          var dc = document.getElementById("sf-text-dining");
          if (dc) clearAppend(dc, [document.createTextNode("现在你可以和你的爱人共同享用美食了，试着去邀请她一起吃吧。")]);
        }
      }
      homeRows(V, T);
      herRoomRows(V, T);
    } catch (e) { /* ignore */ }
  }

  /* ---------- 夜袭 A：悉尼夜里来你床上（仿罗宾 lovewake；B=她房间线留位待卧室内容） ---------- */
  SP._sydneyNightRaid = function (v, t, rng) {
    try {
      var p = SP.ensure(v);
      if (!p || !p.resident || SP.isGone(v)) return null;
      if (!t) return null;
      if (SP.sydInMyBedActive(v, t)) return null;  /* 她已经在你床上睡着，不再重复夜袭 */
      var s = (typeof C !== "undefined" && C.npc && C.npc.Sydney) ? C.npc.Sydney : null;
      if (!s) return null;
      if ((Number(s.love) || 0) < 30 || (Number(s.lust) || 0) < 15) return null;
      var hr = Number(t.hour);
      /* 仿罗宾 lovewake：睡眠段醒来时刻 18 点后或 6 点前才触发（她夜里爬床） */
      if (!(hr >= 18 || hr <= 6)) return null;
      var roll = (typeof rng === "number") ? rng : Math.random() * 100;
      if (roll >= 40) return null;
      p.nightRaidQueued = Number(t.days);
      p.nightRaidDay = Number(t.days);
      return { block: true, msg: "" };
    } catch (e) { return null; }
  };
  SP.renderNightRaid = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      if (State.passage !== "SH House Wake") return;
      var V = State.variables;
      var p = SP.ensure(V);
      if (!p.nightRaidQueued || p.nightRaidQueued !== p.nightRaidDay) return;
      if (p.nightRaidDay !== Number(Time.days)) { p.nightRaidQueued = false; p.nightRaidDay = null; return; }
      var key = "nr|" + p.nightRaidDay;
      if (SP._raidNav === key) return;
      SP._raidNav = key;
      setTimeout(function () { try { SP._playPassage("SH Sydney Night Raid"); } catch (e) { /* ignore */ } }, 0);
    } catch (e) { /* ignore */ }
  };
  SP.endNightRaid = function (v) {
    try {
      var p = SP.ensure(v);
      if (p) { p.nightRaidQueued = false; p.nightRaidDay = null; }
    } catch (e) { /* ignore */ }
  };

  /* 她在你床上：从夜袭时刻到最近一次早上 6:00（之后她自然去厨房/走正常日程） */
  SP.sydInMyBedActive = function (v, t) {
    try {
      var p = SP.ensure(v);
      if (!p || p.sydInMyBedUntilDay === null || p.sydInMyBedUntilDay === undefined) return false;
      if (!t) return false;
      var mins = Number(t.hour) * 60 + (Number(t.minute) || 0);
      if (Number(t.days) < p.sydInMyBedUntilDay) return true;
      if (Number(t.days) === p.sydInMyBedUntilDay && mins < 6 * 60) return true;
      p.sydInMyBedDay = null; p.sydInMyBedUntilDay = null; return false;
    } catch (e) { return false; }
  };
  SP.setSydInMyBed = function (v) {
    try {
      var p = SP.ensure(v);
      if (!p) return;
      var T = (typeof Time !== "undefined") ? Time : null;
      if (!T) return;
      var mins = Number(T.hour) * 60 + (Number(T.minute) || 0);
      p.sydInMyBedDay = Number(T.days);
      p.sydInMyBedUntilDay = (mins < 6 * 60) ? Number(T.days) : Number(T.days) + 1;
    } catch (e) { /* ignore */ }
  };
  /* 床伴插口（通用，后续其他 NPC 可复用）：她夜袭后睡在你床上时，
     SH House Bed 顶部金色提示 + 睡眠链接改"抱着悉尼睡 N 小时"；SH House Bedroom 家人槽置顶黄字 */
  SP._bedGuestGold = "悉尼正抱着你的枕头，脸深深埋进枕头里，呼吸平稳，时不时还嘟囔几句，睡得可香了。";
  SP._bedRoomGold = "悉尼正睡在你床上，抱着你的枕头，睡得很沉。";
  SP.renderBedGuest = function () {
    try {
      if (typeof State === "undefined" || !State.variables || typeof document === "undefined") return;
      var V = State.variables;
      var p = SP.ensure(V);
      var T = (typeof Time !== "undefined") ? Time : null;
      if (!T) return;
      /* 醒来页：早上6点后她离开你床 → 清掉原版 $bedGuest（同床恢复加成只在她还在时生效） */
      if (State.passage === "SH House Wake") {
        if (!SP.sydInMyBedActive(V, T) && V.bedGuest === "Sydney") { delete V.bedGuest; }
        return;
      }
      if (!SP.sydInMyBedActive(V, T)) return;
      var host = document.querySelector("#passages .passage") || document.getElementById("passages");
      if (!host) return;
      if (State.passage === "SH House Bed") {
        V.bedGuest = "Sydney";   /* 原版同床机制：sleephour 会吃到同床恢复加成 */
        var links = host.querySelectorAll("a");
        var first = null;
        var j;
        for (j = 0; j < links.length; j++) {
          var t = (links[j].textContent || "").trim();
          if (t.indexOf("睡") >= 0 && t.indexOf("抱着悉尼睡") < 0 && t.indexOf("爬下床") < 0) {
            if (!first) first = links[j];
            links[j].textContent = t.replace("睡", "抱着悉尼睡", 1);
          }
        }
        var guestEl = document.getElementById("sf-bed-guest");
        if (guestEl) {
          guestEl.innerHTML = '<span class="gold">' + SP._bedGuestGold + '</span><br><br>';
          guestEl.style.display = "";
        } else if (first) {
          var gold = document.createElement("span");
          gold.className = "gold";
          gold.textContent = SP._bedGuestGold;
          var br1 = document.createElement("br"); var br2 = document.createElement("br");
          first.parentNode.insertBefore(gold, first);
          first.parentNode.insertBefore(br1, first);
          first.parentNode.insertBefore(br2, first);
        }
      } else if (State.passage === "SH House Bedroom") {
        var slot = document.getElementById("sf-slot-bedroom");
        if (!slot) return;
        var g = document.createElement("span");
        g.className = "gold";
        g.textContent = SP._bedRoomGold;
        var b = document.createElement("br");
        slot.insertBefore(b, slot.firstChild);
        slot.insertBefore(g, slot.firstChild);
      }
    } catch (e) { /* ignore */ }
  };

  /* ---------- 挂载 ---------- */
  try { if (typeof State !== "undefined" && State.variables) SP.ensure(State.variables); } catch (e) { /* ignore */ }
  try {
    if (typeof $ !== "undefined") {
      $(document).on(":passagedisplay", function () { try { SP.trackPassage(State.passage); } catch (e) { /* ignore */ } try { SP.renderNightRaid(); } catch (e) { /* ignore */ } try { SP.installZGuard(); } catch (e) { /* ignore */ } try { renderMorning(); } catch (e) { /* ignore */ } try { SP.renderBedGuest(); } catch (e) { /* ignore */ } try { SP.renderApproach(); } catch (e) { /* ignore */ } try { SP.renderChat(); } catch (e) { /* ignore */ } try { SP.renderFlirt(); } catch (e) { /* ignore */ } try { SP.renderPlaceholder(); } catch (e) { /* ignore */ } try { SP.renderApproachLeave(); } catch (e) { /* ignore */ } try { SP.renderMoveInRow(); } catch (e) { /* ignore */ } try { SP.renderHomeEntrance(); } catch (e) { /* ignore */ } try { SP.pregAskSceneSwap(); } catch (e) { /* ignore */ } /* DOM 兜底 hideSydneyRows 已停用（用户要求仅阻止触发） */ try { SP.renderPregTell(); } catch (e) { /* ignore */ } try { SP.renderHomeTell(); } catch (e) { /* ignore */ } try { SP.renderMorningSick(); } catch (e) { /* ignore */ } try { SP.trackLabourAway(); } catch (e) { /* ignore */ } try { SP.renderLabour(); } catch (e) { /* ignore */ } try { SP.renderDueSoonHint(); } catch (e) { /* ignore */ } try { SP.renderNameBox(); } catch (e) { /* ignore */ } try { SP.renderNursery(); } catch (e) { /* ignore */ } try { SP.guardChildPages(); } catch (e) { /* ignore */ } try { SP.renderGoneHall(); } catch (e) { /* ignore */ } try { SP.renderNoNurseryHint(); } catch (e) { /* ignore */ } try { SP.iconifyLetterLinks(); } catch (e) { /* ignore */ } try { SP.renderSettingsRow(); } catch (e) { /* ignore */ } try { SP.ensureSydneyFertile(State.variables); } catch (e) { /* ignore */ } try { SP.ensureGoneConsistency(State.variables); } catch (e) { /* ignore */ } try { SP.pregTick(State.variables, (typeof Time !== "undefined") ? Time : null); } catch (e) { /* ignore */ } });
    }
  } catch (e) { /* ignore */ }
  try { registerGuards(); } catch (e) { /* ignore */ }
  try { if (SF && SF.registerRoomPresence) SF.registerRoomPresence(SP.presenceFn); } catch (e) { /* ignore */ }
  try { if (SF && SF.registerNightEvent) SF.registerNightEvent(SP._sydneyNightRaid); } catch (e) { /* ignore */ }
  /* z-index NaN 保险（fork 渲染器 bug：cum_leftarm 等层 zfn 缺 zarms 算出 NaN 会刷报错；引擎内部兜底是 z=0，这里提前置 0 不再打日志） */
  SP.installZGuard = function () {
    try {
      var R = (typeof window !== "undefined" && window.Renderer) || (typeof Renderer !== "undefined" ? Renderer : null);
      if (!R || !R.composeLayers || window.__sfZGuard) return;
      var orig = R.composeLayers.bind(R);
      R.composeLayers = function (targetCanvas, layerSpecs, frameCount, listener) {
        try {
          if (layerSpecs && layerSpecs.length) {
            for (var i = 0; i < layerSpecs.length; i++) {
              var L = layerSpecs[i];
              if (L && L.z !== undefined && isNaN(L.z)) L.z = 0;
            }
          }
        } catch (e) { /* ignore */ }
        return orig(targetCanvas, layerSpecs, frameCount, listener);
      };
      window.__sfZGuard = true;
    } catch (e) { /* ignore */ }
  };
  try { SP.installZGuard(); } catch (e) { /* ignore */ }
  /* 洗澡块（22:00-22:30 固定洗澡时段）：浴室入口改走包内门页（敲门/一起洗/回门厅），不进自家浴室正文 */
  SP.installBathRedirect = function () {
    try {
      if (typeof document === "undefined" || window.__sfBathRedirect) return;
      window.__sfBathRedirect = true;
      document.addEventListener("click", function (ev) {
        try {
          var V = (typeof State !== "undefined" && State.variables) ? State.variables : null;
          var T = (typeof Time !== "undefined") ? Time : null;
          if (!V || !T) return;
          if (!SP.isResident(V)) return;
          var p = SP.ensure(V);
          if (p.bathLockDay === Number(T.days)) return; /* 做爱后：走原浴室锁流程 */
          if (SP.homeBlock(T) !== "bath") return;
          var el = ev && ev.target;
          while (el && el !== document) {
            if (el.tagName === "A") {
              var dp = el.getAttribute ? el.getAttribute("data-passage") : null;
              if (dp === "SH House Bathroom") {
                if (ev.preventDefault) ev.preventDefault();
                if (ev.stopPropagation) ev.stopPropagation();
                if (typeof Engine !== "undefined" && Engine.play) Engine.play("SH Sydney Bath Door");
                return;
              }
              break;
            }
            el = el.parentNode;
          }
        } catch (e) { /* ignore */ }
      }, true);
    } catch (e) { /* ignore */ }
  };
  try { SP.installBathRedirect(); } catch (e) { /* ignore */ }
  try { SP.blockTempleSydneyLinks(); } catch (e) { /* ignore */ }
  /* B-sched 引擎作息覆盖：resident 时周六全天 / 每日 <7 点与 >=20 点 → 引擎认为她在"家"
     （原版神殿/图书馆等她位置相关的互动会自然不出现；家内呈现走 homeStateFor） */
  SP.scheduleWrap = function () {
    try {
      if (typeof window === "undefined" || window.__sfSchedWrap) return;
      var orig = window.sydneySchedule;
      if (typeof orig !== "function") return;
      window.__sfSchedWrap = true;
      window.sydneySchedule = function () {
        var out;
        try { out = orig.apply(this, arguments); } catch (e) { out = undefined; }
        try {
          var T = (typeof Time !== "undefined") ? Time : null;
          var V = (typeof State !== "undefined" && State.variables) ? State.variables : null;
          if (!T || !V) return out;
          var p = SP.ensure(V);
          if (!p || !p.resident) return out;
          var mins = Number(T.hour) * 60 + (Number(T.minute) || 0);
          var sat = Number(T.weekDay) === 7;
          var preg = SP.pregStatus(V).pregnant;   /* 怀孕期全天在家（休养） */
          var home = mins < 7 * 60 || mins >= 20 * 60 || sat || preg;
          if (home && T.sydney_location) T.sydney_location = "home";
        } catch (e) { /* ignore */ }
        return out;
      };
    } catch (e) { /* ignore */ }
  };
  try { SP.scheduleWrap(); } catch (e) { /* ignore */ }
  /* 宏桥：段落里的 <<sydneySchedule>> 重注册为走 window.sydneySchedule（我们包过的那层），
     这样同居+怀孕的"全天在家"对场景判定（_sydney_location，含 late/迟到分支）全局生效 */
  try {
    if (typeof DefineMacro === "function" && !window.__sfSchedMacroBridge) {
      DefineMacro("sydneySchedule", function () {
        try { if (typeof window !== "undefined" && window.sydneySchedule) window.sydneySchedule(); } catch (e) { /* ignore */ }
      });
      window.__sfSchedMacroBridge = true;
    }
  } catch (e) { /* ignore */ }
  /* 定向静音 fork 已知噪音：Layer ... has z-index NaN（引擎内部已兜底 z=0，无功能影响） */
  SP.silenceZNaN = function () {
    try {
      if (typeof window === "undefined" || !window.console || window.__sfZSilence) return;
      var orig = window.console.error.bind(window.console);
      window.console.error = function () {
        try {
          var m = arguments && arguments[0];
          if (typeof m === "string" && m.indexOf("has z-index NaN") >= 0) return;
        } catch (e) { /* ignore */ }
        orig.apply(null, arguments);
      };
      window.__sfZSilence = true;
    } catch (e) { /* ignore */ }
  };
  try { SP.silenceZNaN(); } catch (e) { /* ignore */ }
  /* 上床/进卧室前清装饰性体液层（cum_ 与 drip_ 前缀字段仅视觉，清掉避免 cum_leftarm NaN 触发） */
  try {
    if (typeof $ !== "undefined") {
      $(document).on(":passagestart", function () {
        try {
          if (["SH House Bed", "SH House Bedroom", "SH House Wake"].indexOf(State.passage) < 0) return;
          var V = State.variables;
          Object.keys(V).forEach(function (k) { if (/^(cum_|drip_)/.test(k)) V[k] = ""; });
          if (V.NPCList) {
            for (var i = 0; i < V.NPCList.length; i++) {
              var n = V.NPCList[i];
              if (n) Object.keys(n).forEach(function (k) { if (/^(cum_|drip_)/.test(k)) n[k] = ""; });
            }
          }
        } catch (e) { /* ignore */ }
      });
    }
  } catch (e) { /* ignore */ }

  /* 自装补丁：直接用 SugarCube.Story 改写段落文本（同 patch.json5 的 from→to），
     不依赖加载器 replacePatchList；每条只在文本中存在 from 时才替换，幂等 */
  SP.SELF_PATCHES = [
    ["Temple", '<<if $templePromised is "Sydney">>', '<<if $templePromised is "Sydney" and !SydneyPack.isGone()>>'],
    ["Temple", '<<elseif C.npc.Sydney.init is 1 and C.npc.Sydney.virginity.temple isnot true and $templePromised isnot "Sydney">>', '<<elseif C.npc.Sydney.init is 1 and C.npc.Sydney.virginity.temple isnot true and $templePromised isnot "Sydney" and !SydneyPack.isGone()>>'],
    ["Temple", '<<elseif _sydney_location is "temple">>', '<<elseif _sydney_location is "temple" and !SydneyPack.isPregHome() and !(($SF.sydneypack.resident) and (Time.weekDay is 7 or Time.hour gte 20 or Time.hour lt 7))>>'],
    ["Temple", '<<if _sydney_location is "late" and Time.schoolDay>>', '<<if _sydney_location is "late" and Time.schoolDay and !SydneyPack.isPregHome()>>'],
    ["Canteen", '<<if C.npc.Sydney.init is 1 and _sydney_location is "canteen" and $exposed lte 0>>', '<<if C.npc.Sydney.init is 1 and _sydney_location is "canteen" and !SydneyPack.isPregHome() and $exposed lte 0>>'],
    ["School Library", '<<if _sydney_location is "library" and ($sydneySeen is undefined or !$sydneySeen.includes("library")) and $exposed lte 0>>', '<<if _sydney_location is "library" and ($sydneySeen is undefined or !$sydneySeen.includes("library")) and !SydneyPack.isPregHome() and $exposed lte 0>>'],
    ["School Library", '<<elseif _sydney_location isnot "library">>', '<<elseif _sydney_location isnot "library" or SydneyPack.isPregHome()>>'],
    ["School Library", '<<elseif _sydney_location is "library" and $exposed lte 0>>', '<<elseif _sydney_location is "library" and !SydneyPack.isPregHome() and $exposed lte 0>>'],
    ["Library Rental Counter", '<<switch _sydney_location>>', '<<if SydneyPack.isPregHome()>><<set _sydney_location to "home">><</if>><<switch _sydney_location>>'],
    ["Library Study", '<<if C.npc.Sydney.init is 1 and $sydneySeen.includes("library") and _sydney_location is "library">>', '<<if C.npc.Sydney.init is 1 and $sydneySeen.includes("library") and _sydney_location is "library" and !SydneyPack.isPregHome()>>']
  ];
  SP.installSelfPatches = function () {
    try {
      var StoryAPI = (typeof SugarCube !== "undefined" && SugarCube.Story) ? SugarCube.Story : null;
      if (!StoryAPI) return 0;
      var n = 0;
      for (var i = 0; i < SP.SELF_PATCHES.length; i++) {
        var e = SP.SELF_PATCHES[i];
        var p = null;
        try { p = StoryAPI.get(e[0]); } catch (e2) { p = null; }
        if (!p || !p.text) continue;
        if (p.text.indexOf(e[1]) >= 0) {
          p.text = p.text.split(e[1]).join(e[2]);
          n++;
        }
      }
      return n;
    } catch (e) { return -1; }
  };
  try { SP.installSelfPatches(); } catch (e) { /* ignore */ }

  /* 神殿"打听悉尼·她不在"页：同居+怀孕时整页换成孕期版对话（保留结尾回神殿链接；
     锚定 passage+出口链接而非文本，汉化/版本变更不影响；找不到出口则原样不动） */
  SP.PREG_ASK_PARAS = [
    "你走向一位修女打扮的匀称女人，上前拽了拽她的修女袍上装。她转过身来，对你投以温暖的微笑。",
    "“我承诺陪伴的那位呢？这个点她应该就在附近才对……”",
    "修女没等你说完，就忍不住弯起嘴角：“悉尼？她不是在你家里养着身子吗，怎么跑神殿来问我们？”",
    "她压低声音，语气带着点打趣：“这事儿神殿都知道的，她告了假，让她在好好休息，不然有你好看的。”你讪讪地摸了摸鼻子。",
    "“<span class=\"green\">多回去陪着她吧，别在这儿找了——她这会儿八成正等着你回家呢。</span>”",
    "你不好意思地向她道谢。她点了点头，回到了自己的岗位上。"
  ];
  /* 消失线：神殿"打听她"整页（修女描述她抱着孩子/拖行李箱与约旦道别） */
  SP.GONE_ASK_PARAS = [
    '你走向一位修女……她认出你后，将笑意收了起来。',
    '“……<span class="red">她走了</span>。前几天走的。”，修女仔细回想着那天的情景。',
    '那天清晨，<span class="red">她抱着孩子，另一只手拖着一只行李箱</span>，站在约旦修女面前。那孩子裹得严严实实睡得正香；悉尼把钥匙和十字架轻轻放在桌上，说要去别处安身。约旦本来想挽留，但是看见她的眼神后就不再劝说了，但是约旦还是问她去哪，她只说想找个<span class="red">让孩子安安静静长大的地方</span>。整个过程，她的声音很轻，但是却很<span class="red">平静</span>，就像这句话早就对自己说了很多遍似的。',
    '修女说她走得很<span class="red">慢</span>，像每一步都在<span class="red">等谁</span>来叫住她；最后到门口时停了一下，回头望了很久，但是什么都没说，拖着行李箱走了，而孩子一直睡得很安稳。',
    '修女垂下眼：“你是不是对她做了什么？她看起来不像是不在乎，我能感觉出来她很<span class="red">留恋</span>，但是我还感觉到了……<span class="red">失望</span>？”',
    '你听着修女的话语，瞳孔渐渐无神，久久不能回神，就这么站着。',
    '…………'
  ];
  SP.pregAskSceneSwap = function () {
    try {
      if (State.passage !== "Temple Sydney Ask") return;
      var V = State.variables;
      if (!SP.isPregHome(V)) return;
      var host = document.querySelector("#passages .passage") || document.getElementById("passages");
      if (!host) return;
      /* 找结尾回神殿链接（data-passage=Temple），保留它 */
      var exitA = null;
      var links = host.querySelectorAll("a[data-passage]");
      for (var i = 0; i < links.length; i++) {
        if (links[i].getAttribute("data-passage") === "Temple") { exitA = links[i]; break; }
      }
      if (!exitA) return;   /* 结构不符：不动原样 */
      /* 清掉除出口外的全部内容 */
      while (host.firstChild && host.firstChild !== exitA) host.removeChild(host.firstChild);
      while (host.lastChild && host.lastChild !== exitA) host.removeChild(host.lastChild);
      var src = SP.isGone(V) ? SP.GONE_ASK_PARAS : SP.PREG_ASK_PARAS;
      var frag = [];
      for (var j = 0; j < src.length; j++) frag.push(src[j]);
      var span = document.createElement("span");
      span.innerHTML = frag.join("<br><br>");
      host.insertBefore(span, exitA);
      var br = document.createElement("br");
      host.insertBefore(br, exitA);
      host.insertBefore(document.createElement("br"), exitA);
    } catch (e) { /* ignore */ }
  };

  /* 渲染期强制在家：同居+怀孕时，:passagestart 把 daily.sydney.punish 临时置 1
     （原版 sydneySchedule 看到 punish=1 直接输出 "home"），:passagedisplay 后还原。
     对段落宏原样生效（不依赖段落改写/补丁），所有校外场景统一熄灭 */
  SP._punishOrig = null;
  SP.forceHomeStart = function () {
    try {
      if (typeof State === "undefined") return;
      var V = State.variables;
      if (!SP.isPregHome(V)) return;
      if (SP.isGone(V)) SP.cancelEnglishPlay(V);   /* 消失线防御：gone 期间任何被安排的舞台剧当场取消 */
      if (!V.daily) V.daily = {};
      if (!V.daily.sydney) V.daily.sydney = {};
      if (SP._punishOrig === null) SP._punishOrig = { has: V.daily.sydney.punish !== undefined, val: V.daily.sydney.punish };
      V.daily.sydney.punish = 1;
    } catch (e) { /* ignore */ }
  };
  SP.forceHomeEnd = function () {
    try {
      if (SP._punishOrig === null) return;
      var V = (typeof State !== "undefined" && State.variables) ? State.variables : null;
      if (V && V.daily && V.daily.sydney) {
        if (SP._punishOrig.has) V.daily.sydney.punish = SP._punishOrig.val;
        else delete V.daily.sydney.punish;
      }
      SP._punishOrig = null;
    } catch (e) { /* ignore */ }
  };
  try {
    if (typeof $ !== "undefined") {
      $(document).on(":passagestart", function () { try { SP.forceHomeStart(); } catch (e) { /* ignore */ } });
      $(document).on(":passagedisplay", function () { try { SP.forceHomeEnd(); } catch (e) { /* ignore */ } });
    }
  } catch (e) { /* ignore */ }

  if (typeof module !== "undefined" && module.exports) { module.exports = { SydneyPack: SP, SF: SF }; }
})();
