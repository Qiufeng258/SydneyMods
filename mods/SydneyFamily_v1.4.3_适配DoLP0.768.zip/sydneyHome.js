/* SydneyFamily (悉尼之家) — 房产骨架（分级房源：小宅/中宅/庄园）
 * 商业街租房中介入口 + 多瑙街住宅门：运行时 DOM 注入（汉化安全，武器系统 v2.5.5 同款思路）
 * 租房范式参考 Cattery（月租、每月1号结算、欠租赶人——赶人剧情 S2 实装）。
 * 状态命名空间：$SF。档位表 config.tiers（改档/调价只动这里）。
 */
(function () {
  "use strict";
  var root = (typeof window !== "undefined") ? window
    : (typeof globalThis !== "undefined") ? globalThis : {};
  var SF = root.SF || (root.SF = {});

  SF.config = {
    maxArrears: 2,   // 连续欠租（周）次数达到即被赶走（驱逐剧情 S2b 实装）
    tiers: [
      { key: "cottage", labelZh: "独栋小宅",   rentWeekly: 40000,  buyPrice: 2000000 },  // £400/周 · 买 £20,000
      { key: "house",   labelZh: "带小院的住宅", rentWeekly: 80000,  buyPrice: 4000000 },  // £800/周 · 买 £40,000
      { key: "estate",  labelZh: "大庄园",     rentWeekly: 160000, buyPrice: 8000000 }   // £1600/周 · 买 £80,000
    ],
    /* 固定值：名下房出租每满7天结算；卖房 = 买入8折（不再改） */
    rentalPay: [40000, 80000, 100000],   // £400 / £800 / £1000
    sellPrice: [1600000, 3200000, 6400000] // £16,000 / £32,000 / £64,000
  };
  /* 书店书目：raw 技能（0-1000，AMC2 可 2000）；school 也直接推 raw（作弊器一致）；
     tier 1/2/3 = 前/中/后篇；var 支持 combatExtended.brawling 这类子路径 */
  SF.books = [
    { key: "skulduggery", cat: "core", title: "锁与谎言的入门课", var: "skulduggery", amc: "skulduggery" },
    { key: "dancing", cat: "core", title: "舞步：姿态与节拍", var: "danceskill", amc: "dancing" },
    { key: "swimming", cat: "core", title: "水性：从换气到踩水", var: "swimmingskill", amc: "swimming" },
    { key: "athletics", cat: "core", title: "体能十二讲", var: "athletics", amc: "athletics" },
    { key: "nursing", cat: "core", title: "包扎与急救常识", var: "tending", amc: "tending" },
    { key: "housekeeping", cat: "core", title: "家务速成手册", var: "housekeeping", amc: "housekeeping" },
    { key: "brawling", cat: "core", title: "街巷格斗基础", var: "combatExtended.brawling", amc: "brawling" },
    { key: "footwork", cat: "core", title: "脚步：闪避与走位", var: "combatExtended.footwork", amc: "footwork" },
    { key: "striking", cat: "core", title: "拳路要领", var: "combatExtended.striking", amc: "striking" },
    { key: "kicking", cat: "core", title: "踢击的力与巧", var: "combatExtended.kicking", amc: "kicking" },
    { key: "science", cat: "school", title: "科学：万物为什么", var: "science", amc: "science" },
    { key: "maths", cat: "school", title: "代数与几何初步", var: "maths", amc: "maths" },
    { key: "english", cat: "school", title: "修辞与写作基础", var: "english", amc: "english" },
    { key: "history", cat: "school", title: "旧城编年史", var: "history", amc: "history" },
    { key: "seduction", cat: "sex", title: "魅惑的艺术", var: "seductionskill", amc: "seductionskill" },
    { key: "oral", cat: "sex", title: "舌尖上的舞蹈", var: "oralskill", amc: "oralskill" },
    { key: "chest", cat: "sex", title: "各种胸部的100种用法", var: "chestskill", amc: "chestskill" },
    { key: "bottom", cat: "sex", title: "屁股的渴望", var: "bottomskill", amc: "bottomskill" },
    { key: "vaginal", cat: "sex", title: "小穴的秘密", var: "vaginalskill", amc: "vaginalskill" },
    { key: "thigh", cat: "sex", title: "你真的用对你的腿了吗？", var: "thighskill", amc: "thighskill" },
    { key: "hand", cat: "sex", title: "天下第一手的成长历程", var: "handskill", amc: "handskill" },
    { key: "anal", cat: "sex", title: "前列腺的渴望", var: "analskill", amc: "analskill" },
    { key: "feet", cat: "sex", title: "脚的100种用法", var: "feetskill", amc: "feetskill" }
  ];
  SF.bookCatZh = { core: "核心技能", school: "学校", sex: "性技能" };
  SF.rentTiers = { 1: { rent: 40000, buy: 200000 }, 2: { rent: 80000, buy: 400000 }, 3: { rent: 120000, buy: 600000 } };
  SF.bookGains = { raw: [10, 15, 20], arousal: [1200, 2400, 4000] };
  SF.passages = {
    agency: "SH Estate Agency",
    bookstore: "SH Bookstore",
    houseEntrance: "SH House Entrance"
  };
  /* 图标：游戏本体 0.768 img/misc/icon/ 同名资源，base64 内嵌兜底（武器系统同款做法） */
  SF.icons = {
    agency: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAMAAAAM7l6QAAAAZlBMVEUAAAC/a9aRW4WKS5wQChc2JEtjEmNLlqh+ytyLWouibKI5jqIpZnR61ev/wHHolCuAMCYgEDQ1FV3Lizg0DDRdOl1LMissLi45doU1X7Q6IzqoPj6cYJyRQJGAKyuROzt0KXQKGiOJP0fzAAAAAXRSTlMAQObYZgAAARhJREFUKM+l0+1ygyAQBdCIyoJBwBAkaZqmef+X7F38rDXTH1ncHfWMsjDD4fBuFEIUhShyKURZipKLKEeu6oqvquYy1PxmZEmkNLKR8niUUhtDnHJmBVbgo1IEJuKcWam24eQbMIFpy22rJcoet8ykpbXWMRvO1dfUKAJZ771zzoDNwl13QtfM1rsQAro/dd3EZ14UWY/B7H3ICzu/4BDywhbmdTNxa8PXaG1mtMbsXI3A3Mxm5qqeQscY54d66lzrHgOWEDFqnTD0as/7S0/A65UopQ9Kl/RrUzPrCKUYt3y79apX4E/EyPf7wuov08xfj13+Xs09MO3OnTv/h+kl558zD9uy4SdimHthfrc6Cs9NvH22OH4AgjMgHo/iWeEAAAAASUVORK5CYII=",
    home1: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAMAAAAM7l6QAAAAP1BMVEUAAAA/IRNEIRBJJRRMKRhTLBlSLilaMStpNCpwPDJsQhdxRRlUUVFcWlp6dnWDf37HwS3NxzO+jl3FjFLAi1V31MUGAAAAFXRSTlMA//////////////////////////9QsPovAAABUklEQVQokVVTCWLDMAgLrSug67F0/f9bh4Sdbk7iGAuJw8lm57OdjbfZsIvmua7FNtwd7nMew/+OsRm3IyOCthmdMjJpgmx4ypXzsLnQLLgWrR4QO6Zy4bYZiGamNszEPcxNtjzQcLR6Ljimei52x466ml0wpv2B82BHsxEQHP/gdsdix2E2DHYl2YgVO7XxXuJzVIlDptrwfjG1C0Am6cUvOFuqbogtOp/cd7P9OxRYz8pcVwF28djDn8/Hs+se1erDwW3w9bjf7rfHbMshHr6OpDrQJo9EZehWYb1mfhLPVZfagmWSPrbTp25XU1fdDfd560wEI5eFWJ+DLFRC7Bpo9hmRXVmCHiB7IORJu8zthPh8yhQP9NK7blYWAdbCT9HRTedLsdHSEixxhfFOgOJ/BtkzNPDqI+m0Oj7FW8r951XwZf5w+vtOfDhq5+t6HadfSN0WjEmlizEAAAAASUVORK5CYII=",
    home2: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeBAMAAADJHrORAAAAJFBMVEUAAADk4MjFv56YkWySYU96UEHV8+Ow3cShmnOexa99qZFPPzkRl9pwAAAAAXRSTlMAQObYZgAAAKdJREFUGNN90bsRgzAMBmDYAJgg2E3aIG9gaQMJDnpGoKfMAozACNkv4g4/uOT4u8+SfH4Uxf/UV5bmceHL2Cqv2qZr00JjAaBrszIidqaKdoLioxtLag4DpQGasWc4G7S9V89xAFy/4DB7CPNuUC/+mbzheOdRveXecbrzpN7vrOfPLYwkuUn4k5lZKBkcoSCH+5S1YzV5s8bnOpIZjySf+7zX33/8AuiZO5ms+sTpAAAAAElFTkSuQmCC",
    estate: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAMAAAAM7l6QAAAALVBMVEUAAAAAAAALCwsaGhopKSlOTk5eXl5tbW16enqJiYmXl5eampqnp6e2trbFxcUgCcS9AAAAD3RSTlMA///////////////////ljZ6mAAAApUlEQVQokY2OARbDEBBEhxFsmvT+x61FW1GhM+8x9lsLWOjZ+Uxuzo+ZccrMOOLMmNIDbiocaK8AHdIntNzLuc/sJR6pwbrKqen96YrDHnZS15JqCCWhxBFWBGaNsAq5NsbavcT8zm7mpMAfDPSY+113Qh2+dCtmuO9O1y/48vOMheKt9VJsbQ25RllizztM/wcWjnGausRxizRmi8XG1LAZw7S9AMDnFu9NoVwfAAAAAElFTkSuQmCC"
  };

  function monthKey(t) {
    return String(Number(t.year) * 12 + Number(t.month || 0));
  }
  function ensure(v) {
    if (!v.SF) v.SF = {};
    var s = v.SF;
    if (s.rented === undefined) s.rented = false;
    if (s.homeTier === undefined || s.homeTier < 1 || s.homeTier > SF.config.tiers.length) s.homeTier = 1;
    if (s.arrears === undefined) s.arrears = 0;
    if (s.evicted === undefined) s.evicted = false;
    if (s.bought === undefined) s.bought = false;
    if (s.owned === undefined) s.owned = s.bought && s.homeTier ? [s.homeTier] : [];
    if (s.liveMode === undefined) s.liveMode = s.bought ? "owned" : "rented";
    if (s.rentals === undefined) s.rentals = {};
    if (s.lastRentalTickDay === undefined) s.lastRentalTickDay = null;
    if (s.meals === undefined) s.meals = { lastDay: null, lastHour: null };
    if (s.eatResult === undefined) s.eatResult = null;
    if (s.eatKey === undefined) s.eatKey = null;
    if (s.eatForce === undefined) s.eatForce = 0;
    if (s.nightDoneDay === undefined) s.nightDoneDay = null;
    if (s.nightMsg === undefined) s.nightMsg = null;
    if (s.books === undefined) s.books = { own: [], rent: {} };
    if (s.shopMsg === undefined) s.shopMsg = null;
    if (s.studyMsg === undefined) s.studyMsg = null;
    if (s.studyKey === undefined) s.studyKey = null;
    if (s.studyTier === undefined) s.studyTier = null;
    if (s.studyFatigue === undefined) s.studyFatigue = 80;
    if (s.bailey === undefined) {
      s.bailey = { skippedWeeks: 0, lastSkipDay: null, homeSkip: 0 };
    } else {
      if (s.bailey.skippedWeeks === undefined) s.bailey.skippedWeeks = 0;
      if (s.bailey.lastSkipDay === undefined) s.bailey.lastSkipDay = null;
      if (s.bailey.homeSkip === undefined) s.bailey.homeSkip = 0;
    }
    if (s.lockDoor === undefined) s.lockDoor = 0;
    if (s.lockWindow === undefined) s.lockWindow = 0;
    if (s.events === undefined) {
      s.events = {
        preset: "isolate",
        bailey: 1,        // 贝利接口（我们家版，可用）
        robinNight: 0,    // Robin 同床/夜访（家化后生效）
        kylar: 0,         // Kylar 爬窗/礼物线（家化后生效）
        robinVisit: 0,    // Robin 创伤探访/便条（家化后生效）
        christmas: 0,     // 圣诞拜访/圣诞魅影（家化后生效）
        wraithMirror: 0,  // 镜像系诡异/魅影（家化后生效）
        nightmares: 0     // 睡眠噩梦/魅影（家化后生效）
      };
    } else {
      var ev = s.events;
      if (ev.preset === undefined) ev.preset = "isolate";
      if (ev.bailey === undefined) ev.bailey = 1;
      if (ev.robinNight === undefined) ev.robinNight = 0;
      if (ev.kylar === undefined) ev.kylar = 0;
      if (ev.robinVisit === undefined) ev.robinVisit = 0;
      if (ev.christmas === undefined) ev.christmas = 0;
      if (ev.wraithMirror === undefined) ev.wraithMirror = 0;
      if (ev.nightmares === undefined) ev.nightmares = 0;
    }
    return s;
  }
  function tierCfg(s) {
    var idx = (s && Number(s.homeTier)) || 1;
    return SF.config.tiers[idx - 1] || SF.config.tiers[0];
  }

  SF.logic = {
    ensure: ensure,
    monthKey: monthKey,
    tierCfg: tierCfg,
    canSignTier: function (v, tier) {
      var s = ensure(v);
      var cfg = SF.config.tiers[(Number(tier) || 1) - 1] || SF.config.tiers[0];
      return !s.rented && Number(v.money) >= cfg.rentWeekly;
    },
    buyPriceTier: function (tier) {
      var cfg = SF.config.tiers[(Number(tier) || 1) - 1] || SF.config.tiers[0];
      return Number(cfg.buyPrice) || 0;
    },
    canBuyTier: function (v, tier) {
      var s = ensure(v);
      return !(s.owned || []).includes(Number(tier)) && Number(v.money) >= SF.logic.buyPriceTier(tier);
    },
    sellPriceTier: function (tier) {
      var c = SF.config.sellPrice[(Number(tier) || 1) - 1];
      return typeof c === "number" ? c : 0;
    },
    rentalPayPence: function (tier) {
      var c = SF.config.rentalPay[(Number(tier) || 1) - 1];
      return typeof c === "number" ? c : 0;
    },
    rec: function (v, tier) {
      var s = ensure(v);
      return (s.rentals || {})[tier] || null;
    },
    rActive: function (v, tier) {
      var r = SF.logic.rec(v, tier);
      return r !== null && r.cancelDay === undefined;
    },
    rCancelling: function (v, tier) {
      var r = SF.logic.rec(v, tier);
      return r !== null && r.cancelDay !== undefined;
    },
    rBusy: function (v, tier) {
      return SF.logic.rActive(v, tier) || SF.logic.rCancelling(v, tier);
    },
    /* 行内状态文字（出租中/撤租手续中），供自家段落显示 */
    stateLabel: function (v, tier, days) {
      if (SF.logic.rActive(v, tier)) {
        var pay = SF.logic.rentalPayPence(tier) / 100;
        return " — <span class=\"lblue\">出租中（每7天 £" + pay + "）</span>";
      }
      if (SF.logic.rCancelling(v, tier)) {
        var left = SF.logic.cancelDaysLeft(v, tier, days);
        return " — <span class=\"red\">正在进行撤租手续（剩 " + left + " 天）</span>";
      }
      return "";
    },
    /* 餐厅吃饭：6 小时全局冷却（跨天按小时算） */
    mealLeft: function (v, days, hours) {
      var s = ensure(v);
      var m = s.meals || {};
      if (m.lastDay === null || m.lastHour === null || m.lastDay === undefined) return 0;
      var el = (Number(days) - m.lastDay) * 24 + (Number(hours) - m.lastHour);
      return Math.max(0, 6 - el);
    },
    mealCooldownText: function (v, days, hours) {
      var left = SF.logic.mealLeft(v, days, hours);
      if (left <= 0) return "";
      var h = Math.floor(left);
      var min = Math.round((left - h) * 60);
      if (min === 60) { h += 1; min = 0; }
      return "你刚吃过不久，肚子还饱着。距离下次好好吃一顿还有 " + h + " 小时 " + min + " 分钟。（现在吃也可以，但不会恢复体力/压力/创伤）";
    },
    /* 正常吃：字面数值直减（绕过原版 ×80 宏），并记冷却；效果按难度 1/2/3 */
    eatDish: function (v, key, days, hours) {
      var s = ensure(v);
      var item = typeof setup !== "undefined" && setup.foodstuff ? setup.foodstuff[key] : null;
      if (!item || item.category !== "dish") { s.eatResult = { status: "none" }; return; }
      var stock = v.foodstuff && v.foodstuff[key] ? (Number(v.foodstuff[key].amount) || 0) : 0;
      if (stock <= 0) { s.eatResult = { status: "empty" }; return; }
      var left = SF.logic.mealLeft(v, days, hours);
      if (left > 0) { s.eatResult = { status: "cooling", left: left }; return; }
      v.foodstuff[key].amount = stock - 1;
      var d = item.recipe && item.recipe.difficulty ? Number(item.recipe.difficulty) : 1;
      if (d < 1) d = 1; if (d > 3) d = 3;
      var f = d === 1 ? 200 : d === 2 ? 400 : 1000;
      var st = d === 1 ? 1000 : d === 2 ? 2000 : 5000;
      var tr = d === 1 ? 500 : d === 2 ? 1000 : 2500;
      v.tiredness = Math.max(0, (Number(v.tiredness) || 0) - f);
      v.stress = Math.max(0, (Number(v.stress) || 0) - st);
      v.trauma = Math.max(0, (Number(v.trauma) || 0) - tr);
      s.meals = { lastDay: Number(days), lastHour: Number(hours) };
      s.eatResult = { status: "ok", name: item.name, level: d, fatigue: f, stress: st, trauma: tr };
    },
    /* 冷却期硬吃：扣 1 份，无恢复 */
    forceEat: function (v, key) {
      var s = ensure(v);
      var stock = v.foodstuff && v.foodstuff[key] ? (Number(v.foodstuff[key].amount) || 0) : 0;
      if (stock > 0) v.foodstuff[key].amount = stock - 1;
      s.eatResult = { status: "wasted" };
    },
    /* ============ 书店 / 书房 ============ */
    bookByKey: function (key) {
      for (var i = 0; i < SF.books.length; i++) { if (SF.books[i].key === key) return SF.books[i]; }
      return null;
    },
    tierZh: function (t) { return t === 1 ? "前篇" : t === 2 ? "中篇" : "后篇"; },
    bookState: function (v, key, tier, days) {
      var s = ensure(v);
      var oid = key + "|" + tier;
      if ((s.books.own || []).indexOf(oid) >= 0) return "owned";
      var r = (s.books.rent || {})[oid];
      if (r && Number(r) >= Number(days)) return "rented";
      return "none";
    },
    bookRentDaysLeft: function (v, key, tier, days) {
      var s = ensure(v);
      var r = (s.books.rent || {})[key + "|" + tier];
      if (!r) return 0;
      return Math.max(0, Number(r) - Number(days));
    },
    cleanupBooks: function (v, days) {
      var s = ensure(v);
      var rent = s.books.rent || {};
      Object.keys(rent).forEach(function (oid) { if (Number(rent[oid]) < Number(days)) delete rent[oid]; });
    },
    /* 租书：7 天；同篇已拥有/已租则拒绝 */
    rentBook: function (v, key, tier, days) {
      var s = ensure(v);
      var st = SF.logic.bookState(v, key, tier, days);
      if (st === "owned") { s.shopMsg = "这本你已经买断了。"; return; }
      if (st === "rented") { s.shopMsg = "这本正在租期内。"; return; }
      var price = SF.rentTiers[tier] ? SF.rentTiers[tier].rent : 0;
      if (Number(v.money) < price) { s.shopMsg = "钱不够租这本书。"; return; }
      v.money = Number(v.money) - price;
      s.books.rent[key + "|" + tier] = Number(days) + 7;
      s.shopMsg = "租到了「" + (SF.logic.bookByKey(key) ? SF.logic.bookByKey(key).title : key) + "·" + SF.logic.tierZh(tier) + "」，7 天后自动归还。";
    },
    /* 买断：贵；若正租着该篇则转永久 */
    buyBook: function (v, key, tier) {
      var s = ensure(v);
      if ((s.books.own || []).indexOf(key + "|" + tier) >= 0) { s.shopMsg = "这本你已经有了。"; return; }
      var price = SF.rentTiers[tier] ? SF.rentTiers[tier].buy : 0;
      if (Number(v.money) < price) { s.shopMsg = "钱不够买断这本书。"; return; }
      v.money = Number(v.money) - price;
      s.books.own.push(key + "|" + tier);
      delete (s.books.rent || {})[key + "|" + tier];
      s.shopMsg = "买断了「" + (SF.logic.bookByKey(key) ? SF.logic.bookByKey(key).title : key) + "·" + SF.logic.tierZh(tier) + "」，永久拥有。";
    },
    /* 读技能路径（支持 combatExtended.brawling） */
    skillGet: function (v, path) {
      var p = String(path).split(".");
      var o = v;
      for (var i = 0; i < p.length; i++) { if (o === null || o === undefined) return 0; o = o[p[i]]; }
      return o === null || o === undefined ? 0 : Number(o);
    },
    skillSet: function (v, path, val) {
      var p = String(path).split(".");
      var o = v;
      for (var i = 0; i < p.length - 1; i++) { if (!o[p[i]]) o[p[i]] = {}; o = o[p[i]]; }
      o[p[p.length - 1]] = val;
    },
    /* 学习：0:30。负面 疲劳+50/压力-10（字面、绕过宏倍率）；statFreeze 则全免；
       满级仍可学（事件钩子），但不再加任何正数值 */
    learnStudy: function (v, key, tier, days, hour) {
      var s = ensure(v);
      var bk = SF.logic.bookByKey(key);
      if (!bk) { s.studyMsg = { status: "none" }; return; }
      if (v.statFreeze) { s.studyMsg = { status: "frozen", title: bk.title, tier: tier }; return; }
      /* 负面恒有（学习本身）；疲劳量可在卧室设置调整，默认 80 */
      var fat = Number(s.studyFatigue) || 80;
      v.tiredness = Math.max(0, (Number(v.tiredness) || 0) + fat);
      v.stress = Math.max(0, (Number(v.stress) || 0) - 10);
      var cur = SF.logic.skillGet(v, bk.var);
      var amc = v.AMCTraits && v.AMCTraits[bk.amc] ? Number(v.AMCTraits[bk.amc]) : 1;
      var cap = 1000 * amc;
      var rawGain = SF.bookGains.raw[tier - 1] || 0;
      var arousalGain = bk.cat === "sex" ? (SF.bookGains.arousal[tier - 1] || 0) : 0;
      var applied = false;
      if (cur < cap) {
        var add = rawGain;
        if (cur >= 1000) add = Math.max(1, Math.floor(add / 2)); /* AMC 1000+ 减半（原版规则） */
        SF.logic.skillSet(v, bk.var, Math.min(cap, cur + add));
        applied = true;
      }
      if (arousalGain > 0 && !v.statFreeze) {
        var amax = Number(v.arousalmax) || 10000;
        v.arousal = Math.min(amax, (Number(v.arousal) || 0) + arousalGain);
      }
      s.studyMsg = { status: "ok", title: bk.title, tier: tier, gained: applied, cat: bk.cat, raw: rawGain, arousal: arousalGain, fatigue: fat, cur: Math.min(cap, SF.logic.skillGet(v, bk.var)) };
    },
    clearShopMsg: function (v) { var s = ensure(v); s.shopMsg = null; s.studyMsg = null; },
    /* 用餐时长按难度：1级 0:20 / 2级 0:40 / 3级 1:00 */
    eatMinutes: function (key) {
      var d = 3;
      try { if (typeof setup !== "undefined" && setup.foodstuff && setup.foodstuff[key] && setup.foodstuff[key].recipe) d = Number(setup.foodstuff[key].recipe.difficulty) || 3; } catch (e) {}
      if (d < 1) d = 1; if (d > 3) d = 3;
      return [20, 40, 60][d - 1];
    },
    minutesLabel: function (mins) {
      var h = Math.floor(Number(mins) / 60);
      var m = Number(mins) % 60;
      return h + ":" + String(m).padStart(2, "0");
    },
    /* 出租：下一天起算；随时可撤，未满当前7天周期则该周期不给钱 */
    rentOut: function (v, tier, days) {
      var s = ensure(v);
      tier = Number(tier);
      if (!(s.owned || []).includes(tier)) return "not-owned";
      if (Number(s.homeTier) === tier) return "current";
      if (SF.logic.rec(v, tier)) return "exists";
      s.rentals[tier] = { since: Number(days) };
      return "ok";
    },
    cancelRental: function (v, tier, days) {
      var r = SF.logic.rec(v, tier);
      if (!r || r.cancelDay !== undefined) return "no";
      r.cancelDay = Number(days);
      return "ok";
    },
    cancelDaysLeft: function (v, tier, days) {
      var r = SF.logic.rec(v, tier);
      if (!r || r.cancelDay === undefined) return 0;
      return Math.max(0, 7 - (Number(days) - r.cancelDay));
    },
    sellTier: function (v, tier) {
      var s = ensure(v);
      tier = Number(tier);
      if (!(s.owned || []).includes(tier)) return "not-owned";
      if (Number(s.homeTier) === tier) return "current";
      if (SF.logic.rec(v, tier)) return "rented-out";
      v.money = Number(v.money) + SF.logic.sellPriceTier(tier);
      s.owned = s.owned.filter(function (x) { return x !== tier; });
      if (s.rooms) delete s.rooms[String(tier)];   // 卖掉的房子：房间状态一并清零（再买回=全新空房）
      if (s.owned.length === 0) s.bought = false;
      return "ok";
    },
    settleRentals: function (v, t) {
      var s = ensure(v);
      if (!s.rented || s.evicted) return;
      if (s.lastRentalTickDay === Number(t.days)) return;
      s.lastRentalTickDay = Number(t.days);
      var keys = Object.keys(s.rentals);
      for (var i = 0; i < keys.length; i++) {
        var k = keys[i];
        var rec = s.rentals[k];
        if (!rec) continue;
        if (rec.cancelDay !== undefined) {
          if (Number(t.days) - rec.cancelDay >= 7) delete s.rentals[k];
        } else {
          var occStart = rec.since + 1; /* 下一天起算 */
          var el = Number(t.days) - occStart;
          if (el >= 7 && (el % 7) === 0) {
            v.money = Number(v.money) + SF.logic.rentalPayPence(k);
          }
        }
      }
    },
    /* 周租：每周日（Time.weekDay===1）清算一次；买断后不再扣。v=State.variables, t=Time */
    tick: function (v, t) {
      var s = ensure(v);
      SF.logic.cleanupBooks(v, t.days);
      if (!s.rented || s.evicted) return;
      SF.logic.settleRentals(v, t);
      /* 名下有房且当前住自有房 → 不扣租；租住在别处（liveMode rented）才按当前档扣 */
      if (s.bought && s.liveMode !== "rented") return;
      if (Number(t.weekDay) !== 1) return;         // 周日才结算
      if (s.rentPaidDay === Number(t.days)) return; // 本周已结算
      s.rentPaidDay = Number(t.days);
      var cfg = tierCfg(s);
      if (Number(v.money) >= cfg.rentWeekly) {
        v.money = Number(v.money) - cfg.rentWeekly;
        s.arrears = 0;
      } else {
        s.arrears = (Number(s.arrears) || 0) + 1;
        if (s.arrears >= SF.config.maxArrears) {
          if ((s.owned || []).length > 0) {
            /* 名下有房 → 不驱逐，自动搬回名下第一套 */
            s.liveMode = "owned";
            s.homeTier = s.owned[0];
            s.arrears = 0;
          } else {
            s.evicted = true;
            s.rented = false;
            s.rooms = {};   // 被赶走：租的这套房及其改造房间清零
          }
        }
      }
    },
    /* 换房：升级补差价（新-旧），降级免费；当月已交租金不退，次月按新档扣 */
    currentTier: function (v) {
      return ensure(v).homeTier;
    },
    applyPreset: function (v, preset) {
      var s = ensure(v);
      var rows = {
        isolate:    { bailey: 1, robinNight: 0, kylar: 0, robinVisit: 0, christmas: 0, wraithMirror: 0, nightmares: 0 },
        recommended:{ bailey: 1, robinNight: 1, kylar: 0, robinVisit: 1, christmas: 0, wraithMirror: 0, nightmares: 0 },
        inherit:    { bailey: 1, robinNight: 1, kylar: 1, robinVisit: 1, christmas: 1, wraithMirror: 1, nightmares: 1 }
      };
      var p = rows[preset] ? preset : "isolate";
      s.events.preset = p;
      Object.keys(rows[p]).forEach(function (k) { s.events[k] = rows[p][k]; });
      return p;
    },
    switchCost: function (v, newTier) {
      var s = ensure(v);
      var cur = SF.config.tiers[s.homeTier - 1] || SF.config.tiers[0];
      var nxt = SF.config.tiers[(Number(newTier) || 1) - 1] || SF.config.tiers[0];
      var diff = nxt.rentWeekly - cur.rentWeekly;
      return diff > 0 ? diff : 0;
    },
    canSwitch: function (v, newTier) {
      var s = ensure(v);
      var n = Number(newTier) || 1;
      if (!s.rented || s.evicted || s.bought) return false;
      if (n < 1 || n > SF.config.tiers.length) return false;
      if (n === s.homeTier) return true; // 同档=无操作
      return Number(v.money) >= SF.logic.switchCost(v, n);
    }
  };

  /* ================= 育儿室/房间改造系统（v1.4.0） =================
   * 门厅家人槽后/小院前渲染空房/房间行；中介「改造房间」服务当前入住这套。
   * 房间归属：跟着档位房产走（V.SF.rooms[档位]）；卖房/驱逐清档，换房搬家不丢。
   * 规则：每套房产第一间改造必须改成育儿室；之后其余空房才能改其它类型（现只有健身房占位）。
   */
  SF.config.roomCapacity = { 1: 1, 2: 2, 3: 3 };          // 小宅/带院住宅/庄园 空房配额
  SF.config.renovateCost = { nursery: 100000, gym: 0 };   // 便士：育儿室 £1000（即时）；健身房=占位暂免费；其它类型定价后加
  SF.roomTypeZh = { empty: "空房间", nursery: "育儿室", gym: "健身房" };
  /* 行图标（内嵌 base64 随 mod 走）。nursery/gym 已内嵌 30×30 压缩图；empty/nursery/gym 均已内嵌 30×30 索引色图 */
  SF.roomIcons = {
    empty: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAMAAAAM7l6QAAAA/1BMVEUAAACMSCpyOSamVy5RKCF5RSmYUi7/AABMKCkkDhwiDRq1YzVhLRtPJh05GiH/f3///wAuFBz///9VAABsMR5AHiGAPyXCajjKcz4SBx3EdUHOg0hgLCJdMiZIJilBHiF/Pz8JAh8oEyEnER6vlVS/dEEYCB0YCB0bChtzSh61iTFZQTBTMCxAHiQ8ICY2GCE6GyEjDh0/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBBvcPAAAAQHRSTlMA/fj9+/v+AcXM/f38/K4CAfsBA/2u/f3+Vv79/P2w5AQ0kdH9/Zquyv39+9jWjObdtgQAAAAAAAAAAAAAAAAAmrO39AAAAT1JREFUeNqdk+lygzAMhL2ypaRxTEOTkLu5et/t+z9cZXDacEx/dJkBhm90rYUxqoVjaojdwlT6MpmVuqBXZsYV7+23HIY1Bcr3Kdpcmus5BXemHHJhej+47wn2VxgANTwjgCZEepvoawemjcDZwLJhaWLLTLL0ztLslhgDaWNNr9gicCu5JtXmUGLXxt5BMf+N8R98lbC2JoSiGyO6aYfOBdQHq7BY772F98KUN6PXWrkS3TyFvCO5LkGka350TWxjbVLXgu6JQwcuZKWeT+YrbnQ+qqKrwaTlecTP0fOI27aM0onZotO1UToxRFPRiUvP6Sz6qJ9rmEJQUynkJX44wy+inetA0CMBCwaM/in5zrwtvS5YucJpkWUmh/SX7My1VgWKk+mIrtFnwmNzcB/HbDrNosrH/ev2/S7Cb24hE0iDdIkrAAAAAElFTkSuQmCC",
    nursery: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAMAAAAM7l6QAAAA/1BMVEXl49YbDxliMyqQbFTioF2YWzhrV1ZQKymdn6Ofh26sz+6Xs9AuEB10STTv0ZhjY2PFe0ZXcJzKs4xNKif2x3tiUUlgT0n//wCqVVVqRjVjEA5EN0NVAFWEXkj/fwD/f39dXRktChD//3//qlWqqqqYYjo+NkBcRj8AAACQVzeyd0jJhkyTaEkFARHQlFW4h1Tw59HsyYnTqHD///9/Pz9vZ3CrbEG0mG61tLKYYjrQ5+7ptnBwg6c/Pz9ZVmvLmmQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD8ZW05AAAAQHRSTlP9Vd3x/fPtn/3x/fyU4f4C/Pj8cv6hcwEDoxNqA7MCAgQbAgMDsYJpAPj7/Pcs+vn8/vwBBPz99f3v/f39BP398ggwawAAAbtJREFUeNp9k+d2GjEQhdW3L7t0cOzYqWpbYQvF7Pu/VaQkxiQG5ofO0fl0NVczI8DvBvhnNxrdxOvRPfXGLhDeVGeQw3EN+esHbK+d1USjnMLlyzW1F+eSJLsI/slygUd87kWVhpgIrDqTffufGk8FSVZSuwEiFcs4/2TOvJ7VDkZS4r4E5Sksqu4H59/e1Vv+cyiawEBQuuHOXIBNhocHvviL5/mhcoGJ2D0JR9B4PIPVYN9o8JrDQuSx24Pe7csxi2iUx7oVL2/WskKf5HTcHGOTwE93DsKFjPgF9phWwb53fT8IjqirlRTZuSxYNxgzAHz/eHQ9VhGZU2QLZPHXzWMxMJ3u9/vAOxWiI6zJqWPLY/GWO/JwkCdjPS0qjJXCg6IT2xxgW/notaiben4JUoYPrSAqVztoa/cbR4cchXpw/f1RN0QYrKg413yR0UQI5GgvSEVTC6qkktFs/d5QB4UZz77LLme1EEoJKpX1djGKnzmf4Glda7mbQJGgbHFWL5+ezfrFHNBEhHAlW5R9HORnPmcSrWRiXn1lzjeckbaV1MmufgMTIbIu+dMN/ObyBl7yy0kH97/gLyodeaNu2LlzAAAAAElFTkSuQmCC",
    gym: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAMAAAAM7l6QAAAA/1BMVEXSYBagYCggFidaV2KhoaovFSwlFCXikSybNBEhKENzTCQiFSZMJxtsCwuQb1sA/wAAEmNda4NHRla7vMO/w8kqK0HFoVv///8AAAAWFy8zNEkrJTZUVmcFAQlHRlZmZ3QKAhIbIjoJAhIrGiiGhpIMCCQMAxgwFRtwJxksK0FAOUp3HRFXVlh1d4M5QlkUBRpQGBcqJjh8fH9hXWsnChUAAFURCiQRCiQ/Pz9UOChJJCcCAjauiVRiNhgRAxVrOSsAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADg+/AWAAAAQHRSTlP8/Nz0/Aaf/Pzt92r3B/kBBP6X//x7/QEA+/v8/DX8/FD8bPz996z9/f34/QT8/IX4kgL9+gO0mAr7/AT889P9lNqyYQAAAZtJREFUeNqdk9dy4zAMRUlJVnHbJNsIgEXFkiw77o57+f+/Cidr2clsNpksX4iZMxckgAsmPjzsq/jxQ/z7fXWjcQla0SBK31PfCTEXvu71zPmo3mKVtuKXG5F6EoOmuuEnEQ9cKW3KxxYCoEbOnM1NnR7J9Iy2ijjfNsnFLXN/is0Fx3gIspGUjpq50uMZErFpfFE/iRXKQxOlJuN5ntunBLLQF506eZuTy0gijrx7NxsSOMthev1a3A22yHbjilDPCihBy8Hp7opdr8uADROgtRKNAhZGjp267rl4kLwPwx1SbqlIFwadIzniW/12EbbBGEntlh2IMxqXwUGiX+P5fgWDkc6bbGkr1xL4LwlA6tqWzknKymG227OJxiwwCfFsXeON8KVO2vze+/F9oSPOxjln/cJ2hP1xgK8xKcOdNnYcUcijZuCZ+DaxtEKC6fTkIyKEZyhZ11WvBgoVAYAVrCuYnpM8tLlf4RgI8tiWLbJk2U8ScNQbt6jJ5MVTYkVQZpCrfxm5AGeS/uW1/f4adj5Zg8Z/b8lX8DOjFVngwLiKgwAAAABJRU5ErkJggg=="
  };

  SF.logic.roomCapacity = function (tier) {
    var c = SF.config.roomCapacity[Number(tier)];
    return typeof c === "number" ? c : 0;
  };
  SF.logic.roomTypeZh = function (t) { return SF.roomTypeZh[t] || SF.roomTypeZh.empty; };
  /* 惰性按「现有房产 + 当前入住档」补齐房间数组；卖掉的档位不重建（卖房时已 delete 清零） */
  SF.logic.ensureRooms = function (v) {
    var s = SF.logic.ensure(v);
    if (!s.rooms || typeof s.rooms !== "object") s.rooms = {};
    var need = {};
    var owned = s.owned || [];
    for (var i = 0; i < owned.length; i++) need[String(owned[i])] = 1;
    if (s.rented && !s.evicted) need[String(Number(s.homeTier) || 1)] = 1; // 当前入住这套
    for (var t = 1; t <= 3; t++) {
      var key = String(t);
      if (!need[key]) continue;
      var arr = s.rooms[key];
      if (!Array.isArray(arr)) { arr = []; s.rooms[key] = arr; }
      while (arr.length < SF.logic.roomCapacity(t)) arr.push({ type: "empty" });
      for (var j = 0; j < arr.length; j++) {
        if (!arr[j] || (arr[j].type !== "nursery" && arr[j].type !== "gym")) arr[j] = { type: "empty" };
      }
    }
    return s.rooms;
  };
  SF.logic.roomsOf = function (v, tier) { return SF.logic.ensureRooms(v)[String(Number(tier) || 1)] || []; };
  SF.logic.roomType = function (v, tier, idx) {
    var slot = SF.logic.roomsOf(v, tier)[Number(idx)];
    return slot ? slot.type : null;
  };
  SF.logic.hasNursery = function (v, tier) {
    var arr = SF.logic.roomsOf(v, tier);
    for (var i = 0; i < arr.length; i++) if (arr[i].type === "nursery") return true;
    return false;
  };
  SF.logic.hasRenovated = function (v, tier) {
    var arr = SF.logic.roomsOf(v, tier);
    for (var i = 0; i < arr.length; i++) if (arr[i].type !== "empty") return true;
    return false;
  };
  SF.logic.canRenovate = function (v, tier, idx, type) {
    tier = Number(tier); idx = Number(idx);
    var arr = SF.logic.roomsOf(v, tier);
    if (idx < 0 || idx >= arr.length) return { ok: false, code: "bad-idx" };
    if (type !== "nursery" && type !== "gym") return { ok: false, code: "bad-type" };
    if (arr[idx].type !== "empty") return { ok: false, code: "not-empty" };
    if (type === "nursery" && SF.logic.hasRenovated(v, tier)) return { ok: false, code: "first-nursery" };
    if (type === "gym" && !SF.logic.hasNursery(v, tier)) return { ok: false, code: "order" };
    var cost = SF.config.renovateCost[type];
    if (typeof cost !== "number" || Number(v.money) < cost) return { ok: false, code: "insufficient" };
    return { ok: true };
  };
  SF.logic.renovateRoom = function (v, tier, idx, type) {
    var chk = SF.logic.canRenovate(v, tier, idx, type);
    if (!chk.ok) return chk;
    v.money = Number(v.money) - SF.config.renovateCost[type];
    SF.logic.roomsOf(v, tier)[Number(idx)].type = type;
    return { ok: true, code: "ok", type: type };
  };
  SF.logic.roomPound = function (pence) { return "£" + (Math.round(Number(pence)) / 100); };

  /* ---------- 运行时入口注入（渲染后；不改原文、不挤汉化位置） ---------- */
  function passageEl() {
    try {
      return document.getElementById("passage")
        || document.querySelector("#passages .passage")
        || document.querySelector(".passage");
    } catch (e) { return null; }
  }
  function isZh(el) {
    try {
      if (el) {
        var t = el.textContent || "";
        if (t.indexOf("购物中心") !== -1 || t.indexOf("商业街") !== -1
          || t.indexOf("森林") !== -1 || t.indexOf("多瑙") !== -1) return true;
      }
      var lm = window.modSC2DataManager && window.modSC2DataManager.getLanguageManager
        && window.modSC2DataManager.getLanguageManager();
      return !!(lm && lm.mainLanguage === "zh");
    } catch (e) { return false; }
  }
  function iconEl(dataUri) {
    try {
      var img = document.createElement("img");
      img.className = "icon";
      img.src = dataUri;
      return img;
    } catch (e) { return null; }
  }
  function makeLink(target, label, onClick) {
    var span = document.createElement("span");
    var a = null;
    if (typeof createInternalLink === "function") {
      try { a = createInternalLink(null, target, label, onClick || null); } catch (e) { a = null; }
    }
    if (!a) {
      a = document.createElement("a");
      a.setAttribute("data-passage", target);
      a.className = "link-internal";
      a.textContent = label;
      if (typeof $ !== "undefined") {
        try { $(a).click(function (ev) { ev.preventDefault(); Engine.play(target); }); } catch (e) { /* ignore */ }
      }
    }
    span.appendChild(a);
    return span;
  }
  function renumber(el) {
    try {
      if (window.Links && typeof window.Links.generateLinkNumbers === "function") {
        window.Links.generateLinkNumbers(el);
      }
    } catch (e) { /* ignore */ }
    clearTimeout(renumber._t);
    renumber._t = setTimeout(function () {
      try {
        if (window.Links && typeof window.Links.generateLinkNumbers === "function") {
          window.Links.generateLinkNumbers(el);
        }
      } catch (e) { /* ignore */ }
    }, 250);
  }
  function insertEntryBefore(anchor, entry) {
    var parent = anchor.parentNode;
    var ref = anchor.previousElementSibling;
    var before = (ref && ref.tagName === "IMG") ? ref : anchor;
    parent.insertBefore(entry, before);
    parent.insertBefore(document.createElement("br"), before);
  }
  function passSeconds(sec) { try { Time.pass(sec); } catch (e) { /* ignore */ } }

  /* 商业街 → 房产中介（常驻） */
  function ensureHighStreetEntry(el) {
    if (!el) return;
    if (el.querySelector('a[data-passage="SH Estate Agency"]')) return;
    var office = el.querySelector('a[data-passage="Office Lobby"], a[data-passage="Office New Location"]');
    var shop = el.querySelector('a[data-passage="Shopping Centre"], a[data-passage="Shopping Centre Sneak"]');
    if (!office && !shop) return;
    var label = isZh(el) ? "房产中介 (0:02)" : "Estate Agent (0:02)";
    var entry = makeLink(SF.passages.agency, label, function () {
      var V = State.variables;
      ensure(V).returnTo = V.passage;
      passSeconds(120);
    });
    var ic = iconEl(SF.icons.agency);
    if (ic) entry.insertBefore(ic, entry.firstChild);
    if (office) insertEntryBefore(office, entry);
    else insertEntryBefore(shop, entry);
    renumber(el);
  }

  /* 商业街 → 书店（与中介同款内置图标，后续可换书店专属图） */
  function ensureBookstoreEntry(el) {
    if (!el) return;
    if (el.querySelector('a[data-passage="SH Bookstore"]')) return;
    var ag = el.querySelector('a[data-passage="SH Estate Agency"]');
    if (!ag) return;
    var label = isZh(el) ? "书店 (0:02)" : "Bookstore (0:02)";
    var entry = makeLink(SF.passages.bookstore, label, function () {
      var V = State.variables;
      ensure(V).returnTo = V.passage;
      passSeconds(120);
    });
    var ic = iconEl(SF.icons.agency); /* TODO: 换成书店专属图标 */
    if (ic) entry.insertBefore(ic, entry.firstChild);
    var p = ag.parentNode;
    var br1 = document.createElement('br');
    p.insertBefore(br1, ag.nextSibling);
    p.insertBefore(entry, br1.nextSibling);
    renumber(el);
  }

  /* 多瑙街 → 家门（签约后出现；按档位给不同标签与图标；被赶走则消失） */
  function ensureDanubeDoor(el) {
    if (!el) return;
    var v = (typeof State !== "undefined" && State.variables) ? State.variables : {};
    var s = ensure(v);
    if (!s.rented || s.evicted) return;
    if (el.querySelector('a[data-passage="SH House Entrance"]')) return;
    var forest = el.querySelector('a[data-passage="Forest"]');
    var knock = el.querySelector('a[data-passage="Danube House Knock"]');
    var anchor = forest || knock;
    if (!anchor) return;
    var estate = Number(s.homeTier) >= 3;
    var label = isZh(el)
      ? (estate ? "你的庄园 (0:01)" : "你的家 (0:01)")
      : (estate ? "Your Estate (0:01)" : "Your Home (0:01)");
    var entry = makeLink(SF.passages.houseEntrance, label, function () {
      var V = State.variables;
      ensure(V).returnTo = V.passage;
      passSeconds(60);
    });
    var ic = iconEl(estate ? SF.icons.estate : (Number(s.homeTier) === 2 ? SF.icons.home2 : SF.icons.home1));
    if (ic) entry.insertBefore(ic, entry.firstChild);
    insertEntryBefore(anchor, entry);
    renumber(el);
  }

  /* 裸身快捷回家：住宅区/多姆斯街/狼街（神殿街）暴露时，有房则给「跑回多瑙街的家」 */
  function ensureHomeEscapeEntry(el) {
    if (!el) return;
    if (el.querySelector('a.sf-home-escape')) return;
    var v = (typeof State !== "undefined" && State.variables) ? State.variables : {};
    var s = ensure(v);
    if (!s.rented || s.evicted) return;
    if (!(Number(v.exposed) >= 1)) return;
    var anchor = el.querySelector('a[data-passage]');
    if (!anchor) return;
    var estate = Number(s.homeTier) >= 3;
    var label = isZh(el) ? "跑回多瑙街的家 (0:05)" : "Run home to Danube Street (0:05)";
    var entry = makeLink("Danube Street", label, function () {
      var V = State.variables;
      ensure(V).returnTo = V.passage;
      passSeconds(300);
    });
    entry.classList.add("sf-home-escape");
    var ic = iconEl(estate ? SF.icons.estate : (Number(s.homeTier) === 2 ? SF.icons.home2 : SF.icons.home1));
    if (ic) entry.insertBefore(ic, entry.firstChild);
    insertEntryBefore(anchor, entry);
    renumber(el);
  }

  try { if (typeof State !== "undefined" && State.variables) ensure(State.variables); } catch (e) { /* ignore */ }
  try { if (typeof setup !== "undefined") setup.SFlogic = SF.logic; } catch (e) { /* ignore */ }

  try {
    if (typeof $ !== "undefined") {
      $(document).on(":passagestart", function () {
                        SF.ensureFurnHooks(); SF.ensureFurniture(State.variables); SF.logic.tick(State.variables, Time);
      });
      $(document).on(":passagedisplay", function () {
        try {
          if (State.passage === "High Street") { ensureHighStreetEntry(passageEl()); ensureBookstoreEntry(passageEl()); }
          else if (State.passage === "Danube Street") ensureDanubeDoor(passageEl());
          else if (["Domus Street", "Wolf Street", "Residential Alleyways"].indexOf(State.passage) >= 0) ensureHomeEscapeEntry(passageEl());
        } catch (e) { /* ignore */ }
      });
    }
  } catch (e) { /* ignore */ }


/* 厨房：全食材放行（允许用所有 setup.foodstuff 食材；材料仍要玩家自己获取） */
SF.kitchenSupplyAll = function () {
    // 无任何免费食材：所有材料都要玩家自己获取（超市/市场/森林/菜园等）
    try {
        if (typeof setup !== "undefined" && setup.foodstuff && typeof T !== "undefined") {
            var all = Object.keys(setup.foodstuff);
            T.ingredientsSupplied = [];
            // exceptions = 允许用于烹饪的全部条目（仅放行，不提供，不无限）
            T.ingredientsExceptions = all.slice();
        }
    } catch (e) { /* ignore */ }
};




/* ================= S2b 自家家具区（sydney_home） ================= */
SF.ensureFurnHooks = function () {
    try {
        if (typeof Furniture === "undefined" || !Furniture.get || SF._furnWrapped) return;
        var orig = Furniture.get.bind(Furniture);
        Furniture.get = function (category, location) {
            if (location === "sydney_home") {
                try {
                    var V = State.variables;
                    var area = V.furniture && V.furniture.sydney_home;
                    var owned = area ? area[category] : null;
                    var def = (setup.furniture && typeof setup.furniture.get === "function")
                        ? setup.furniture.get(owned && owned.id ? owned.id : category) : null;
                    if (owned && def) {
                        var out = {};
                        for (var k in def) out[k] = def[k];
                        for (var k2 in owned) out[k2] = owned[k2];
                        return out;
                    }
                    return owned || def || null;
                } catch (e) { return null; }
            }
            return orig(category, location);
        };
        SF._furnWrapped = true;
    } catch (e) { /* ignore */ }
};
SF.ensureFurniture = function (v) {
    try {
        if (!v.furniture) return;
        if (!v.furniture.sydney_home) {
            v.furniture.sydney_home = {
                bed: { id: "bed" },
                desk: { id: "desk" },
                chair: { id: "chair" }
            };
        }
    } catch (e) { /* ignore */ }
};
SF.furn = function (cat) {
    try { return Furniture.get(cat, "sydney_home"); } catch (e) { return null; }
};


  /* 房间守卫 API（v1.1）：角色包加载时注册 SF.registerRoomGuard(scene, fn)；
     前置房间段落首行放 <<if SF.runRoomGuard("xxx")>><<goto "SH Guarded">><</if>>；
     fn(V, Time) 返回 {block:true, msg:html} 则拦下并转 SH Guarded */
  SF.roomGuards = {};
  SF.registerRoomGuard = function (scene, fn) {
    if (!SF.roomGuards[scene]) SF.roomGuards[scene] = [];
    if (typeof fn === "function") SF.roomGuards[scene].push(fn);
    return SF;
  };
  SF.runRoomGuard = function (scene) {
    try {
      var V = (typeof State !== "undefined" && State.variables) ? State.variables : {};
      SF.logic.ensure(V);
      V.SF.guardMsg = null; /* 每次先清，防残留 */
      var list = SF.roomGuards[scene] || [];
      for (var i = 0; i < list.length; i++) {
        var r = list[i](V, (typeof Time !== "undefined") ? Time : null);
        if (r && r.block) {
          V.SF.guardMsg = r.msg || "";
          return true;
        }
      }
    } catch (e) { /* ignore */ }
    return false;
  };

  /* 房间"有人"感知（v1.3）：角色包 SF.registerRoomPresence(fn)；fn(V,Time) 返回 [{room}]；
     门厅 sf-house-presence 渲染黄色"X似乎有人"（同房多人合并为一行） */
  SF.roomZh = { living: "客厅", dining: "餐厅", study: "书房", bedroom: "卧室", bathroom: "浴室", kitchen: "厨房", garden: "小院" };
  SF.presenceSources = [];
  SF.registerRoomPresence = function (fn) { if (typeof fn === "function") SF.presenceSources.push(fn); return SF; };
  SF.collectPresence = function (v, t) {
    var rows = [];
    try {
      for (var i = 0; i < SF.presenceSources.length; i++) {
        var r = SF.presenceSources[i](v, t);
        if (r && r.length) for (var j = 0; j < r.length; j++) { if (r[j] && r[j].room) rows.push(String(r[j].room)); }
      }
    } catch (e) { /* ignore */ }
    var uniq = [];
    rows.forEach(function (x) { if (uniq.indexOf(x) < 0) uniq.push(x); });
    return uniq;
  };
  SF.renderPresence = function () {
    try {
      var el = document.getElementById("sf-house-presence");
      if (!el) return;
      var V = (typeof State !== "undefined" && State.variables) ? State.variables : {};
      var rooms = SF.collectPresence(V, (typeof Time !== "undefined") ? Time : null);
      if (!rooms.length) { el.style.display = "none"; el.innerHTML = ""; return; }
      el.innerHTML = rooms.map(function (r) { return '<span class="gold">' + (SF.roomZh[r] || r) + '似乎有人</span>'; }).join("<br>") + "<br>";
      el.style.display = "";
    } catch (e) { /* ignore */ }
  };
  /* 睡眠夜袭事件（v1.3）：角色包 SF.registerNightEvent(fn)；自家 SH House Wake 调用 runNightEvents；
     fn(V,Time) 返回 {block:true,msg:html} 则当夜生效一次 */
  SF.nightEvents = [];
  SF.registerNightEvent = function (fn) { if (typeof fn === "function") SF.nightEvents.push(fn); return SF; };
  SF.runNightEvents = function () {
    try {
      var V = (typeof State !== "undefined" && State.variables) ? State.variables : {};
      SF.logic.ensure(V);
      if (V.SF.nightDoneDay === Number(Time.days)) return false;
      for (var i = 0; i < SF.nightEvents.length; i++) {
        var r = SF.nightEvents[i](V, (typeof Time !== "undefined") ? Time : null);
        if (r && r.block) { V.SF.nightMsg = r.msg || ""; V.SF.nightDoneDay = Number(Time.days); return true; }
      }
    } catch (e) { /* ignore */ }
    return false;
  };

  /* 家人房间插槽注册接口：角色包在加载时调用 SF.registerSlotRow(scene, html)，
     scene = "entrance" | "bedroom"；页面渲染后自动填入对应空容器 */
  SF.slotRows = {};
  SF.slotZones = {};
  SF.slotNamed = {};
  /* 通用：SF.registerSlotRow(scene, html) → 默认位（同场景唯一容器 sf-slot-<scene>） */
  SF.registerSlotRow = function (scene, html) {
    (SF.slotRows[scene] = SF.slotRows[scene] || []).push(String(html));
  };
  /* 分区：SF.registerSceneZone(scene, "text"|"links", html) */
  SF.registerSceneZone = function (scene, zone, html) {
    SF.slotZones[scene] = SF.slotZones[scene] || {};
    (SF.slotZones[scene][zone] = SF.slotZones[scene][zone] || []).push(String(html));
  };
  /* 命名槽：SF.registerSceneSlot(scene, slotName, html) → 容器 id = sf-slot-<scene>-<slotName> */
  SF.registerSceneSlot = function (scene, slotName, html) {
    SF.slotNamed[scene] = SF.slotNamed[scene] || {};
    (SF.slotNamed[scene][slotName] = SF.slotNamed[scene][slotName] || []).push(String(html));
  };
  SF.fillZone = function (zoneId, rows) {
    if (!rows || !rows.length) return;
    var el = document.getElementById(zoneId);
    if (!el) return;
    el.innerHTML = rows.join("<br>");
    el.style.display = "";
  };
  /* 原版分行（v1.3.7）：sf-text/sf-links/sf-slot 容器不再自带 margin 空行，留白由包内容显式补 <br><br> */
  SF._slotStyleInjected = false;
  SF.ensureSlotStyle = function () {
    if (SF._slotStyleInjected) return;
    try {
      if (typeof document === "undefined" || !document.head) return;
      var st = document.createElement("style");
      st.textContent = "#passages #sf-house-presence{margin:0;}"; /* sf-text/sf-links/sf-slot 无 margin：留白走内容 <br><br> */
      document.head.appendChild(st);
      SF._slotStyleInjected = true;
    } catch (e) { /* ignore */ }
  };
  SF.renderSlots = function () {
    try {
      var map = { "SH House Entrance": "entrance", "SH House Bedroom": "bedroom", "SH House Garden": "garden", "SH House Living Room": "living", "SH House Dining": "dining", "SH House Study": "study", "SH House Bathroom": "bathroom", "SH House Kitchen": "kitchen", "SH House Nursery": "nursery" };
      var key = map[State.passage];
      if (!key) return;
      SF.fillZone("sf-slot-" + key, SF.slotRows[key] || []);
      var z = SF.slotZones[key] || {};
      SF.fillZone("sf-text-" + key, z.text);
      SF.fillZone("sf-links-" + key, z.links);
      var named = SF.slotNamed[key] || {};
      Object.keys(named).forEach(function (n) {
        SF.fillZone("sf-slot-" + key + "-" + n, named[n]);
      });
    } catch (e) { /* ignore */ }
  };
  try { SF.ensureSlotStyle(); } catch (e) { /* ignore */ }
  try {
    if (typeof $ !== "undefined") {
      $(document).on(":passagedisplay", function () { try { SF.ensureSlotStyle(); } catch (e) { /* ignore */ } try { SF.renderSlots(); } catch (e) { /* ignore */ } try { SF.renderPresence(); } catch (e) { /* ignore */ } try { SF.renderRoomRows(); } catch (e) { /* ignore */ } try { SF.renderRenovate(); } catch (e) { /* ignore */ } });
    }
  } catch (e) { /* ignore */ }

  /* 房间行/改造页 DOM 渲染（沿用家人槽方案：渲染完→读状态→DOM 直插，无引擎快捷键编号） */
  function sfRoomGo(passage, icon, label, pre) {
    var a = document.createElement("a");
    a.className = "link-internal";
    a.setAttribute("data-passage", passage);
    a.style.cursor = "pointer";
    a.addEventListener("click", function (ev) {
      try { if (ev && ev.preventDefault) ev.preventDefault(); if (ev && ev.stopPropagation) ev.stopPropagation(); } catch (e) { /* ignore */ }
      try { if (pre) pre(); Engine.play(passage); } catch (e) { /* ignore */ }
    });
    if (icon) {
      var im = document.createElement("img");
      im.className = "icon";
      im.src = icon;
      a.appendChild(im);
      a.appendChild(document.createTextNode(" "));
    }
    a.appendChild(document.createTextNode(label));
    return a;
  }
  /* 门厅房间行：空房/育儿室/健身房（家人槽后/小院前容器 sf-slot-entrance-rooms） */
  SF.renderRoomRows = function () {
    try {
      if (typeof State === "undefined" || typeof document === "undefined") return;
      var el = document.getElementById("sf-slot-entrance-rooms");
      if (!el) return;
      var V = State.variables;
      var s = SF.logic.ensure(V);
      if (State.passage !== "SH House Entrance" || !s.rented || s.evicted) { el.innerHTML = ""; el.style.display = "none"; return; }
      var arr = SF.logic.roomsOf(V, s.homeTier);
      var rows = [];
      for (var i = 0; i < arr.length; i++) {
        var type = arr[i].type;
        var zh = SF.logic.roomTypeZh(type);
        if (type === "nursery") {
          rows.push(sfRoomGo("SH House Nursery", SF.roomIcons.nursery, zh, null));
        } else {
          rows.push(sfRoomGo("SH House Room Stub", SF.roomIcons[type] || null, zh, (function (t2) {
            return function () { try { State.variables.SF.roomMsg = t2; } catch (e) { /* ignore */ } };
          })(type)));
        }
      }
      if (!rows.length) { el.innerHTML = ""; el.style.display = "none"; return; }
      el.innerHTML = "";
      for (var r = 0; r < rows.length; r++) {
        if (r > 0) el.appendChild(document.createElement("br"));
        el.appendChild(rows[r]);
      }
      el.appendChild(document.createElement("br"));  // 组尾补空行（对齐家人槽行尾惯例）
      el.appendChild(document.createElement("br"));
      el.style.display = "";
    } catch (e) { /* ignore */ }
  };
  /* 中介改造页：当前入住这套的每间房 + 可行动作（行内即时反馈） */
  SF.renovateDo = function (V, tier, idx, type) {
    try {
      var res = SF.logic.renovateRoom(V, tier, idx, type);
      var ok = !!res.ok;
      var text;
      if (ok) text = "改造完成。「" + SF.logic.roomTypeZh(type) + "」已经收拾好，回多瑙街看看吧。";
      else if (res.code === "insufficient") text = "钱不够。改造「" + SF.logic.roomTypeZh(type) + "」需要 " + SF.logic.roomPound(SF.config.renovateCost[type]) + "。";
      else text = "（房间状态不允许这样改造。）";
      V.SF.renovMsg = { ok: ok, text: text };
      /* 导航交给调用处的 sfRoomGo（Engine.play），这里只改状态防重复跳转 */
    } catch (e) { /* ignore */ }
  };
  SF.renderRenovate = function () {
    try {
      if (typeof State === "undefined" || typeof document === "undefined") return;
      if (State.passage !== "SH Room Renovate") return;
      var el = document.getElementById("sf-renovate-rows");
      if (!el) return;
      var V = State.variables;
      var s = SF.logic.ensure(V);
      var msg = V.SF.renovMsg || null;
      V.SF.renovMsg = null;
      var nodes = [];
      if (msg && msg.text) {
        var sp = document.createElement("span");
        sp.className = msg.ok ? "green" : "red";
        sp.textContent = msg.text;
        nodes.push(sp);
        nodes.push(document.createElement("br"));
        nodes.push(document.createElement("br"));
      }
      if (!s.rented || s.evicted) { el.innerHTML = ""; el.style.display = "none"; return; }
      var tier = Number(s.homeTier) || 1;
      var arr = SF.logic.roomsOf(V, tier);
      var first = !SF.logic.hasRenovated(V, tier);
      var hasNurs = SF.logic.hasNursery(V, tier);
      for (var i = 0; i < arr.length; i++) {
        var type = arr[i].type;
        var zh = SF.logic.roomTypeZh(type);
        var line = document.createElement("span");
        line.textContent = "第" + (i + 1) + "间：" + zh;
        nodes.push(line);
        if (type === "empty") {
          nodes.push(document.createElement("br"));
          if (first) {
            nodes.push(sfRoomGo("SH Room Renovate", null, "改造成育儿室（" + SF.logic.roomPound(SF.config.renovateCost.nursery) + "）", (function (idx) {
              return function () { SF.renovateDo(V, tier, idx, "nursery"); };
            })(i)));
          } else if (hasNurs) {
            nodes.push(sfRoomGo("SH Room Renovate", null, "改造成健身房（占位）", (function (idx) {
              return function () { SF.renovateDo(V, tier, idx, "gym"); };
            })(i)));
          }
        }
        if (i < arr.length - 1) { nodes.push(document.createElement("br")); nodes.push(document.createElement("br")); }
      }
      el.innerHTML = "";
      for (var n = 0; n < nodes.length; n++) el.appendChild(nodes[n]);
      el.style.display = "";
    } catch (e) { /* ignore */ }
  };

  if (typeof module !== "undefined" && module.exports) { module.exports = { SF: SF }; }

/* ============ 书店 UI 助手 ============ */
SF.logic.booksByCat = function (cat) { return SF.books.filter(function (b) { return b.cat === cat; }); };
SF.logic.bookCatZh = function (cat) { return SF.bookCatZh[cat] || cat; };
SF.logic.fmtPence = function (pence) {
  var pounds = Math.round(Number(pence) / 100);
  return "£" + String(pounds).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
};
SF.logic.rowStatus = function (v, key, tier, days) {
  var s = ensure(v);
  if ((s.books.own || []).indexOf(key + "|" + tier) >= 0) return "<span class=\"gold\">已买断</span>";
  var r = (s.books.rent || {})[key + "|" + tier];
  if (r && Number(r) >= Number(days)) return "<span class=\"lblue\">租借中·剩 " + (Number(r) - Number(days)) + " 天</span>";
  return "";
};

SF.logic.tiersList = function () { return [1, 2, 3]; };
SF.logic.rentPence = function (tier) { return (SF.rentTiers[tier] && SF.rentTiers[tier].rent) || 0; };
SF.logic.buyPence = function (tier) { return (SF.rentTiers[tier] && SF.rentTiers[tier].buy) || 0; };
SF.logic.rentBuyLabel = function (tier) {
  return "租 " + SF.logic.fmtPence(SF.logic.rentPence(tier)) + " / 买 " + SF.logic.fmtPence(SF.logic.buyPence(tier));
};

SF.logic.bookCats = function () { return ["core", "school", "sex"]; };
SF.logic.anyLearnable = function (v, cat, days) {
  var list = SF.logic.booksByCat(cat);
  for (var i = 0; i < list.length; i++) {
    var bk = list[i];
    for (var t = 1; t <= 3; t++) { if (SF.logic.bookState(v, bk.key, t, days) !== "none") return true; }
  }
  return false;
};


SF.logic.bookSkillZh = { skulduggery: '诡术', dancing: '舞蹈', swimming: '游泳', athletics: '运动', nursing: '护理', housekeeping: '家务', brawling: '搏斗', footwork: '步法', striking: '打击', kicking: '踢击', science: '科学', maths: '数学', english: '语文', history: '历史', seduction: '魅惑', oral: '口腔', chest: '胸部', bottom: '臀部', vaginal: '阴道', thigh: '大腿', hand: '手部', anal: '肛门', feet: '足部' };
SF.logic.skillZh = function (key) { return SF.logic.bookSkillZh[key] || key; };
SF.logic.bookListByTab = function (tab) {
  var out = [];
  var cats = tab === 'all' ? ['core', 'school', 'sex'] : [tab];
  for (var c = 0; c < cats.length; c++) {
    var list = SF.logic.booksByCat(cats[c]);
    for (var i = 0; i < list.length; i++) out.push(list[i]);
  }
  return out;
};
SF.logic.min = function (a, b) { return Math.min(Number(a), Number(b)); };
SF.logic.gardenFirstVisit = function (v) {
  var s = ensure(v);
  if (s.gardenFertGiven) return;
  if (!v.fertiliser) v.fertiliser = { current: 0, used: 0 };
  v.fertiliser.current = (Number(v.fertiliser.current) || 0) + 3;
  s.gardenFertGiven = true;
};

})();
